# Project state — Checkpoint 03

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Existing Dusk/Dusklight identities are not reused, preserving separate Xbox/Windows LocalState.

## Completed

- Fresh package identity/display name and exact user-supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- Randomizer-era UWP link dependencies: TracyClient, yaml-cpp, base64pp.
- UWP static-library mode and entry-point compatibility patches.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Windows runner, MSVC setup, Ninja, freetype and zstd dependency setup proven working in GitHub Actions.
- Checkpoint 02 pre-assembly verifier bug fixed and proven by Run 2 reaching source assembly.
- Checkpoint 03 explicitly resolves the one pinned superproject submodule conflict (`extern/aurora`) while preserving the newer randomizer Aurora revision and fail-fast behavior for every unexpected conflict.
- Checkpoint 03 manual workflow deterministically selects the highest checkpoint number.

## Run 2 result

The build reached the first real assembly attempt and stopped at Git's non-trivial `extern/aurora` submodule conflict during the merge of the pinned UWP reference. No compiler failure has occurred yet.

## Local validation for Checkpoint 03

- Kit static verifier passes.
- Python source compiles.
- The exact Git submodule conflict-resolution algorithm was validated with a synthetic divergent-submodule merge: stage-2 ours revision identified, checked out, staged, merge completed, and final gitlink preserved.

## Not yet certified

The project has not yet passed:

- full pinned source assembly on the Windows runner;
- UWP Aurora cherry-pick on that assembled tree;
- CMake configure;
- static-feed compilation;
- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Use Checkpoint 03 plus its `github-manual/build-xbox.yml`, rerun the GitHub Action, and use the next exact failed step/log as the source of truth.
