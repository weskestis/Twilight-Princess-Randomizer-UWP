#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_ORIGINAL_SHA256 = "521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff"
EXPECTED_ASSETS = {
    "LockScreenLogo.scale-200.png": (48, 48),
    "Square44x44Logo.targetsize-24_altform-unplated.png": (24, 24),
    "Square44x44Logo.scale-200.png": (88, 88),
    "Square150x150Logo.scale-200.png": (300, 300),
    "StoreLogo.png": (50, 50),
    "SplashScreen.scale-200.png": (1240, 600),
    "Wide310x150Logo.scale-200.png": (620, 300),
    "Square310x310Logo.scale-200.png": (620, 620),
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()[:24]
    if len(data) != 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise SystemExit(f"Not a valid PNG: {path}")
    return struct.unpack(">II", data[16:24])


def verify_kit() -> None:
    identity = json.loads((ROOT / "APP_IDENTITY.json").read_text(encoding="utf-8"))
    expected = {
        "package_identity": "TwilightPrincessRandomizer",
        "display_name": "Twilight Princess Randomizer",
        "publisher": "CN=TwilightPrincessRandomizer",
        "version": "1.4.1.627",
        "randomizer_commit": "07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e",
        "uwp_commit": "48d193dfebe4b20b4984af1d27d0e99f6b6722a7",
    }
    for key, value in expected.items():
        if identity.get(key) != value:
            raise SystemExit(f"APP_IDENTITY.json mismatch: {key}={identity.get(key)!r}, expected {value!r}")

    original = ROOT / "branding" / "Twilight-Princess-Randomizer-original.jpg"
    if sha256(original) != EXPECTED_ORIGINAL_SHA256:
        raise SystemExit("Original uploaded branding image hash changed")

    for name, dims in EXPECTED_ASSETS.items():
        p = ROOT / "branding" / "Assets" / name
        if not p.exists():
            raise SystemExit(f"Missing branding asset: {name}")
        if png_size(p) != dims:
            raise SystemExit(f"Wrong asset dimensions for {name}: {png_size(p)} != {dims}")

    assembler = (ROOT / "scripts" / "assemble_port.py").read_text(encoding="utf-8")
    for marker in (
        'PACKAGE_NAME = "TwilightPrincessRandomizer"',
        'DISPLAY_NAME = "Twilight Princess Randomizer"',
        'TARGET_NAME = "TwilightPrincessRandomizer"',
        'TPR_YAML_CPP_LIB',
        'TPR_BASE64PP_LIB',
        'TPR_TRACY_LIB',
        'Wide310x150Logo.scale-200.png',
        'Square310x310Logo.scale-200.png',
        'set(unmerged) != {"extern/aurora"}',
        'git", "rev-parse", ":2:extern/aurora"',
    ):
        if marker not in assembler:
            raise SystemExit(f"Assembler missing marker: {marker}")


def verify_assembled(root: Path) -> None:
    required = [
        "platforms/uwp/CMakeLists.txt",
        "platforms/uwp/Package.appxmanifest",
        "src/dusk/randomizer/generator/randomizer.cpp",
        "src/dusk/ui/rando_config.cpp",
        "src/dusk/ui/file_browser.cpp",
    ]
    missing = [p for p in required if not (root / p).exists()]
    if missing:
        raise SystemExit("Assembled source missing: " + ", ".join(missing))

    manifest = (root / "platforms/uwp/Package.appxmanifest").read_text(encoding="utf-8-sig")
    for marker in (
        'Name="TwilightPrincessRandomizer"',
        'Publisher="CN=TwilightPrincessRandomizer"',
        'Version="1.4.1.627"',
        'Twilight Princess Randomizer',
        'Wide310x150Logo',
    ):
        if marker not in manifest:
            raise SystemExit(f"Manifest missing: {marker}")

    cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")
    for marker in ("DUSK_UWP", "add_library(dusklight STATIC", "_UWP"):
        if marker not in cmake:
            raise SystemExit(f"Top-level CMake missing: {marker}")

    wrapper = (root / "platforms/uwp/CMakeLists.txt").read_text(encoding="utf-8")
    for marker in ("project(TwilightPrincessRandomizer", "TPR_YAML_CPP_LIB", "TPR_BASE64PP_LIB", "TPR_TRACY_LIB"):
        if marker not in wrapper:
            raise SystemExit(f"UWP wrapper missing: {marker}")

    for name, dims in EXPECTED_ASSETS.items():
        p = root / "platforms/uwp/Assets" / name
        if not p.exists() or png_size(p) != dims:
            raise SystemExit(f"Assembled branding asset invalid: {name}")


if __name__ == "__main__":
    verify_kit()
    if len(sys.argv) > 1:
        candidate = Path(sys.argv[1]).resolve()
        # The checkpoint kit itself is not an assembled Dusklight source tree.
        # This guard makes the verifier tolerant of workflows that pass TPR_KIT
        # while still validating a real assembled source path when supplied.
        if candidate != ROOT.resolve():
            verify_assembled(candidate)
    print("Twilight Princess Randomizer UWP static checks passed.")
