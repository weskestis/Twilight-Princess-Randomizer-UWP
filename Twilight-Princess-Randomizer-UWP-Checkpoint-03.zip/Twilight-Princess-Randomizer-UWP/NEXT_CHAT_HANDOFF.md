# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 03

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 03**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-03.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Goal

Produce a real Xbox Dev Mode installable **separate app**:

- Display name: **Twilight Princess Randomizer**
- Package identity: `TwilightPrincessRandomizer`
- Must install alongside existing Dusklight UWP and keep separate LocalState.
- Preserve the user's exact supplied Twilight Princess HD artwork.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Run 2 reached the real assembly step. The UWP superproject merge failed only because Git could not auto-resolve the divergent `extern/aurora` submodule gitlink. This was not a CMake/compiler failure.

Checkpoint 03 fixes this explicitly and narrowly:

- only `extern/aurora` may remain unmerged;
- the stage-2/ours gitlink must equal the expected randomizer Aurora base;
- that revision is staged to finish the superproject merge;
- any other conflict aborts;
- the existing dedicated SternXD Aurora UWP cherry-pick then runs.

The same resolution sequence passed a local synthetic divergent-submodule test.

## Manual GitHub workflow

Use `github-manual/build-xbox.yml` as `.github/workflows/build-xbox.yml` in the user's private repo. It now selects the numerically highest checkpoint ZIP so old checkpoint ZIPs can remain in the repository.

The connected GitHub reader still cannot read the user's private repo, so manual Android paste/upload remains the current bridge.

## Immediate next action

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-03.zip` to repository root.
2. Replace `.github/workflows/build-xbox.yml` with Checkpoint 03's full manual workflow.
3. Run `Xbox UWP x64`.
4. Inspect the next exact failure or successful artifact.

## Remaining gates

1. Full source assembly
2. Assembled-source verification
3. Randomizer static-feed CMake configure
4. Static-feed compile
5. UWP wrapper configure
6. Certificate creation
7. UWP link/package
8. Artifact upload
9. Xbox Dev Mode install
10. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation

Fix one real failure at a time. Preserve pinning and fail-fast behavior.
