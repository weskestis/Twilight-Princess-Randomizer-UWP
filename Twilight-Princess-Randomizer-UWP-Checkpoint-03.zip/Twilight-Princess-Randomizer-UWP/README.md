# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the newest located Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.627`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

This identity is intentionally different from both the old `Dusk` UWP package and SternXD's newer `Dusklight` UWP package. Windows/Xbox therefore gives this app its own package family and its own LocalState. Installing it does not update or overwrite the existing Dusklight app.

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- Development label at that commit: `v1.4.1-627`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The assembler keeps the randomizer's newer Aurora base and forward-ports only the UWP compatibility patch. It does not downgrade the randomizer core to the old UWP fork.

## Xbox-specific work in this project

The build creates a new UWP target instead of patching an installed Dusklight binary. It carries forward the proven UWP file browser/data-folder layer, uses `/MD` CRT linkage, adds the randomizer's later `yaml-cpp`, `base64pp`, and Tracy libraries to the final UWP link, disables desktop updater/Discord/code-mod services for Xbox, and packages the UWP resources through the existing Xbox-compatible wrapper.

## App artwork

`branding/Twilight-Princess-Randomizer-original.jpg` is the exact image supplied for this custom app. Its SHA-256 is:

`521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff`

The generated UWP assets preserve the full picture. They resize it to each required canvas and add padding when the canvas is not 16:9; they do not crop Link or Wolf Link out of the artwork. A wide Xbox tile asset is included in addition to the standard UWP square icons and splash image.

## Build from Android

The real UWP/MSVC link has to run on Windows. This repository includes `.github/workflows/build.yml` so a GitHub-hosted Windows runner can do it without a PC. Run the workflow named **Build Twilight Princess Randomizer UWP** and download the resulting Xbox artifact.

The workflow also creates a sideload certificate whose subject matches the new package identity and includes the public `.cer` with the Xbox package. The private `.pfx` is deleted before artifacts are uploaded.

## Status

GitHub Actions has now reached the real pinned-source assembly gate. Checkpoint 03 fixes the one observed non-trivial `extern/aurora` submodule gitlink conflict by explicitly preserving the randomizer Aurora base before applying the dedicated SternXD UWP Aurora patch. No CMake/compiler failure has occurred yet. The remaining gates are full assembly, Windows UWP compilation/link/package, and Xbox runtime testing.
