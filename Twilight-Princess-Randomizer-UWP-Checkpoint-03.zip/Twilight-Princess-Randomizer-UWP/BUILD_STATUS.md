# GitHub Actions build status — Checkpoint 03

## Repository

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

The connected GitHub reader still returns 404 for this private repository in the current setup, so the user continues to paste workflow changes from Android and return screenshots/logs.

## Run 1 — Checkpoint 01 workflow bug

Passed checkout, checkpoint extraction, MSVC setup, Ninja/vcpkg dependencies.

Failed before assembly because the manual workflow incorrectly passed the checkpoint kit itself as an assembled-source argument to `verify_static.py`.

Fixed in Checkpoint 02 by using:

```powershell
python "$env:TPR_KIT\scripts\verify_static.py"
```

## Run 2 — first real source assembly attempt

Run reached `Assemble pinned randomizer plus UWP source`.

The pinned randomizer source and pinned SternXD UWP source fetched correctly and Git began the intended merge. The only unresolved merge path shown by Git was:

```text
CONFLICT (submodule): Merge conflict in extern/aurora
```

Git then exited the merge with status 1. No CMake configure or compiler step had started yet.

### Root cause

`git merge -X ours` resolves ordinary content conflicts but does not resolve a non-trivial submodule gitlink conflict. This is expected Git behavior for the two pinned Aurora revisions.

The assembler already had the intended Aurora policy immediately after this merge: keep the randomizer Aurora base `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`, then apply SternXD's UWP Aurora patch `aaf5b8b092ff547a33a9d199dd2c52572bff6682`. It simply did not explicitly resolve the superproject gitlink conflict first.

## Checkpoint 03 fix

`scripts/assemble_port.py` now:

1. attempts the same pinned UWP merge;
2. if the merge returns nonzero, enumerates unmerged paths;
3. accepts **only** `extern/aurora` as the known conflict;
4. reads the merge index's stage-2 (randomizer/ours) Aurora gitlink and asserts it is exactly `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`;
5. checks the Aurora worktree out to that exact revision;
6. stages the gitlink and completes the merge commit;
7. fails hard if any other conflict exists;
8. continues with the existing dedicated SternXD Aurora UWP cherry-pick.

The conflict-resolution sequence was reproduced in a local synthetic Git repository containing a divergent submodule merge and passed end-to-end.

The manual workflow is also hardened to choose the numerically highest `Checkpoint-XX.zip`, rather than relying on checkout file timestamps.

## Next gate

Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-03.zip` to the repository root, update `.github/workflows/build-xbox.yml` to the Checkpoint 03 manual workflow, and rerun `Xbox UWP x64`.

The next meaningful gate is whether assembly gets past the superproject merge and the dedicated Aurora UWP cherry-pick. Do not call this compiled until the later CMake/build steps actually run.
