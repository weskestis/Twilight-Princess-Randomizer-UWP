# GitHub Actions build status — Checkpoint 06

## Repository

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Prior resolved gates

- Checkpoint 02: corrected pre-assembly verifier invocation.
- Checkpoint 03: resolved the superproject `extern/aurora` gitlink conflict while preserving the randomizer Aurora base.
- Checkpoint 04: forward-ported the two real Aurora UWP content conflicts (`lib/input.cpp`, `lib/webgpu/gpu.cpp`) onto the newer randomizer Aurora structures.
- Checkpoint 05: guarded `aurora_install_runtime_dlls` for non-UWP builds, allowing top-level static-feed configure to complete.

## Run 5 — static-feed build reached real compilation

Checkpoint 05 passed:

1. source assembly;
2. Aurora UWP forward-port;
3. assembled-source verification;
4. randomizer static-feed CMake configure.

The workflow entered **Build randomizer static feed** and reached approximately:

```text
[388/2209]
```

before a nested CMake project configure failed during an MSVC linker compiler test:

```text
LINK : fatal error LNK1104: cannot open file
'CMakeFiles\\cmTC_839a6.dir/intermediate.manifest'

ninja: build stopped: subcommand failed.

CMake will not be able to correctly generate this project.
Call Stack (most recent call first):
  CMakeLists.txt:7 (project)

-- Configuring incomplete, errors occurred!
```

## Why Checkpoint 06 changes path layout

The normal GitHub Actions checkout is under a duplicated repository path similar to:

```text
D:\\a\\Twilight-Princess-Randomizer-UWP\\Twilight-Princess-Randomizer-UWP\\...
```

The static feed then adds `work`, `build`, `extern/aurora`, dependency `_deps`, and nested CMake scratch/try-compile directories. `git config core.longpaths=true` only helps Git operations; it does not shorten the filesystem path passed to MSVC/link.exe during nested CMake builds.

Checkpoint 06 avoids carrying that long prefix into the compiler toolchain.

## Checkpoint 06 workflow

The manual workflow now creates:

```powershell
subst S: "$env:GITHUB_WORKSPACE"
```

and uses:

```text
S:\\s      assembled source
S:\\b\\f   randomizer static-feed build
S:\\b\\p   UWP package build
S:\\tmp    TEMP/TMP
```

Both configure stages also receive:

```text
-DCMAKE_OBJECT_PATH_MAX=180
```

The build output is still copied back into `$GITHUB_WORKSPACE` before artifact upload, then `S:` is released.

## Important

Checkpoint 06 requires **both**:

- the Checkpoint 06 ZIP in repository root; and
- replacement of `.github/workflows/build-xbox.yml` with the Checkpoint 06 workflow.

The workflow still selects the numerically highest checkpoint ZIP.

## Next gate

Rerun `Xbox UWP x64` and verify that the static-feed build passes the nested `cmTC` manifest failure and continues beyond ~388/2209. Do not call the static feed compiled until the full build step succeeds.
