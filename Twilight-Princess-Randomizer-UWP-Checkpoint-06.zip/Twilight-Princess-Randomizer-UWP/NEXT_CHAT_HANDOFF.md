# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 06

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 06**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-06.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Goal

Produce a real Xbox Dev Mode installable **separate app**:

- Display name: **Twilight Princess Randomizer**
- Package identity: `TwilightPrincessRandomizer`
- Must install alongside existing Dusklight UWP and keep separate LocalState.
- Preserve the user's exact supplied Twilight Princess HD artwork.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Checkpoint 05 passed source assembly, static verification, and the top-level randomizer static-feed configure. It then reached the actual **Build randomizer static feed** step and compiled to roughly `388 / 2209` objects before a nested CMake compiler/link test failed.

Observed failure:

```text
LINK : fatal error LNK1104: cannot open file
'CMakeFiles\\cmTC_839a6.dir/intermediate.manifest'

CMake will not be able to correctly generate this project.
Call Stack (most recent call first):
  CMakeLists.txt:7 (project)

-- Configuring incomplete, errors occurred!
ninja: build stopped: subcommand failed.
```

The failure occurred inside a nested CMake configure during the Ninja build. The GitHub workspace already has a long duplicated repository path before Aurora `_deps` / CMake scratch directories are added. Git long-path support does not shorten paths seen by MSVC/link.exe.

## Checkpoint 06 change

No randomizer or Aurora source logic was changed.

The manual GitHub workflow now:

1. maps the repository workspace to `S:` with Windows `subst`;
2. assembles the source at `S:\\s`;
3. configures the static feed at `S:\\b\\f`;
4. configures the UWP wrapper at `S:\\b\\p`;
5. moves `TEMP` / `TMP` to `S:\\tmp`;
6. sets `CMAKE_OBJECT_PATH_MAX=180` as an additional nested-object path guard;
7. releases the `S:` mapping before artifact upload.

This directly removes the path-depth pressure that produced the nested `intermediate.manifest` failure and also protects the later Visual Studio UWP package build.

## Required manual action

Checkpoint 06 changes the workflow, so uploading only the ZIP is **not enough**.

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-06.zip` to repository root.
2. Replace `.github/workflows/build-xbox.yml` with `github-manual/build-xbox.yml` from Checkpoint 06 (or the copyable workflow supplied in chat).
3. Run `Xbox UWP x64` again.
4. Inspect the next exact failure or successful artifact.

Old checkpoint ZIPs may remain; the workflow selects the numerically highest checkpoint.

## Remaining gates

1. Static-feed compile past the nested MSVC/CMake manifest test
2. Complete all ~2209 static-feed build actions
3. UWP wrapper configure
4. Certificate creation
5. UWP link/package
6. Artifact upload
7. Xbox Dev Mode install
8. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation

Continue one real failure at a time. Preserve all source pins and fail-fast checks.
