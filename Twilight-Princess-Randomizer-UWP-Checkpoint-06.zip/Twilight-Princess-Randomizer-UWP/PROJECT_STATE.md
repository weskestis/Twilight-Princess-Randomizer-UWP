# Project state — Checkpoint 06

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Existing Dusk/Dusklight identities are not reused, preserving separate Xbox/Windows LocalState.

## Completed

- Fresh package identity/display name and exact user-supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- Randomizer-era UWP link dependencies: TracyClient, yaml-cpp, base64pp.
- UWP static-library mode and entry-point compatibility patches.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Windows runner, MSVC setup, Ninja, freetype and zstd dependency setup proven working in GitHub Actions.
- Checkpoint 02 pre-assembly verifier bug fixed.
- Checkpoint 03 superproject `extern/aurora` gitlink conflict fixed without downgrading Aurora.
- Checkpoint 04 forward-ported the two observed Aurora UWP content conflicts onto the newer randomizer Aurora structures.
- Checkpoint 05 fixed the Aurora runtime-install helper guard mismatch.
- Run 5 proved top-level source assembly, assembled-source verification, and static-feed CMake configure all pass.
- Run 5 entered the real static-feed compile and reached about `388 / 2209` build actions.

## Run 5 result

During **Build randomizer static feed**, a nested CMake configure/try-compile failed in MSVC link manifest generation:

```text
LINK : fatal error LNK1104: cannot open file
'CMakeFiles\\cmTC_839a6.dir/intermediate.manifest'
```

The nested CMake stack reported `CMakeLists.txt:7 (project)` and Ninja stopped.

This is after the top-level static-feed project configured successfully, so the prior source/CMake integration blockers are resolved.

## Checkpoint 06 mitigation

The workflow now runs all source/build work from a shallow `subst` drive:

- source: `S:\\s`
- static feed: `S:\\b\\f`
- UWP package: `S:\\b\\p`
- temp: `S:\\tmp`

`CMAKE_OBJECT_PATH_MAX=180` is also passed to both configure stages.

No gameplay/randomizer/Aurora source behavior changed in Checkpoint 06.

## Not yet certified

The project has not yet passed:

- complete static-feed compilation;
- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Upload Checkpoint 06, replace the GitHub workflow with the Checkpoint 06 workflow, and rerun `Xbox UWP x64`. The next exact failed step/log is the source of truth.
