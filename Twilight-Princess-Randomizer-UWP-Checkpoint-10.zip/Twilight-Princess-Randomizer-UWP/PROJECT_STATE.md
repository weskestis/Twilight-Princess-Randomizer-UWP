# Project state — Checkpoint 10

Goal: a brand-new, side-by-side Xbox/UWP application named **Twilight Princess Randomizer**.

## Pinned upstreams

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Completed compatibility work

- Dedicated UWP package identity and branding.
- Static UWP Dusklight/randomizer feed.
- UWP Aurora forward-port over the newer randomizer Aurora base.
- Short Windows build root (`S:`) to avoid nested MSVC path/manifest failures.
- Stale `settings.cpp` UWP preprocessor conflict repaired.
- New randomizer YAML/base64 static dependencies wired into the old UWP wrapper.
- Tracy archive conditionalized on `TRACY_ENABLE`.
- FileBrowser implementation integration now uses a structural `DUSK_FILES` append rather than a filename-neighbor anchor.

## Current proven build state

Checkpoint 08 completed the entire randomizer static feed, configured the UWP wrapper, created the certificate, and reached the final executable link. Its only observed link failure was unresolved `dusk::ui::FileBrowser` implementation symbols.

Checkpoint 09 did not reach compilation because its first FileBrowser source-list fix used a stale exact anchor in top-level `CMakeLists.txt`. Checkpoint 10 replaces that brittle insertion with a target-adjacent `list(APPEND DUSK_FILES ...)`, preserving the same intended link fix without depending on where the source list is declared.

## Next action

Upload Checkpoint 10 and rerun the existing Checkpoint 06 workflow. The next exact CI failure or successful package artifact becomes the new source of truth.
