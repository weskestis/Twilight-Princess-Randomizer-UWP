# Checkpoint 10 update

Checkpoint 09 did not expose a new compiler problem; its assembler used a stale exact filename anchor while trying to add the UWP FileBrowser implementation to `DUSK_FILES`. Checkpoint 10 appends those sources structurally immediately before target creation, so the fix works even though the pinned randomizer keeps its source list in `files.cmake`.

# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the pinned Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.627`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

This identity is intentionally different from both the old `Dusk` UWP package and SternXD's newer `Dusklight` UWP package, so Windows/Xbox gives it a separate package family and LocalState.

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The assembler keeps the randomizer's newer Aurora base and forward-ports UWP compatibility rather than downgrading the randomizer core.

## App artwork

`branding/Twilight-Princess-Randomizer-original.jpg` is the exact supplied artwork. SHA-256:

`521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff`

## Build status

GitHub Actions has now completed source assembly, static verification, static-feed CMake configuration, and the entire ~2209-action randomizer static build. Checkpoint 08 reached the final UWP link; Checkpoint 10 corrects the FileBrowser source integration discovered there. See `BUILD_STATUS.md` for the exact gate.
