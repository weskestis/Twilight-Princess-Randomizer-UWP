#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess

RANDO_REPO = "https://github.com/TwilitRealm/dusklight.git"
RANDO_SHA = "07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e"
UWP_REPO = "https://github.com/SternXD/dusklight-uwp.git"
UWP_SHA = "48d193dfebe4b20b4984af1d27d0e99f6b6722a7"
AURORA_UWP_REPO = "https://github.com/SternXD/aurora.git"
AURORA_UWP_SHA = "aaf5b8b092ff547a33a9d199dd2c52572bff6682"
EXPECTED_AURORA_BASE = "6c4c27f9e8e40f584d27726655d80ec85a5a7d2c"

PACKAGE_NAME = "TwilightPrincessRandomizer"
DISPLAY_NAME = "Twilight Princess Randomizer"
PUBLISHER = "CN=TwilightPrincessRandomizer"
PUBLISHER_DISPLAY = "Twilight Princess Randomizer"
DESCRIPTION = "Twilight Princess Randomizer for Xbox/UWP"
PHONE_PRODUCT_ID = "e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d"
PACKAGE_VERSION = "1.4.1.627"
TARGET_NAME = "TwilightPrincessRandomizer"

KIT_ROOT = Path(__file__).resolve().parents[1]
BRANDING_ASSETS = KIT_ROOT / "branding" / "Assets"


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess:
    print("+", " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=cwd, check=check, text=True)


def capture(cmd: list[str], cwd: Path) -> str:
    return subprocess.check_output(cmd, cwd=cwd, text=True).strip()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise RuntimeError(f"Required source anchor missing while patching {label}: {old[:120]!r}")
    return text.replace(old, new, 1)


def ensure_main_uwp_cmake(source: Path) -> None:
    path = source / "CMakeLists.txt"
    text = path.read_text(encoding="utf-8")

    if 'option(DUSK_UWP "Enable UWP compat support"' not in text:
        anchor = 'option(DUSK_ENABLE_CODE_MODS "Enable code mods" OFF)\n'
        text = replace_once(
            text,
            anchor,
            anchor
            + 'option(DUSK_UWP "Enable UWP compat support" OFF)\n\n'
            + 'if (MSVC AND DUSK_UWP)\n'
            + '    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL" CACHE STRING "" FORCE)\n'
            + 'endif ()\n',
            "DUSK_UWP option",
        )

    # UWP file browser source list integration.  The pinned randomizer moved its
    # DUSK_FILES definition out to files.cmake, so do not anchor this port on a
    # neighboring filename in that list.  Instead append the UWP-only sources to
    # DUSK_FILES immediately before the target is created.  This remains valid
    # whether the list itself lives in CMakeLists.txt, files.cmake, or another
    # included CMake fragment.
    if "src/dusk/ui/file_browser.cpp" not in text or "src/dusk/ui/file_browser.hpp" not in text:
        target_match = re.search(
            r"(?m)^if\(ANDROID\)\r?$\n[ \t]+add_library\(dusklight SHARED \${DUSK_FILES}\)",
            text,
        )
        if target_match is None:
            raise RuntimeError("Could not locate Dusklight target creation while adding UWP FileBrowser sources")
        addition = (
            "# UWP file browser source list\n"
            "if (DUSK_UWP)\n"
            "    list(APPEND DUSK_FILES\n"
            "        src/dusk/ui/file_browser.cpp\n"
            "        src/dusk/ui/file_browser.hpp\n"
            "    )\n"
            "endif ()\n\n"
        )
        text = text[: target_match.start()] + addition + text[target_match.start() :]

    if "elseif (DUSK_UWP)" not in text:
        old = (
            'if(ANDROID)\n'
            '    add_library(dusklight SHARED ${DUSK_FILES})\n'
            '    set_target_properties(dusklight PROPERTIES OUTPUT_NAME main)\n'
            'else ()\n'
            '    add_executable(dusklight ${DUSK_FILES})\n'
            'endif ()'
        )
        new = (
            'if(ANDROID)\n'
            '    add_library(dusklight SHARED ${DUSK_FILES})\n'
            '    set_target_properties(dusklight PROPERTIES OUTPUT_NAME main)\n'
            'elseif (DUSK_UWP)\n'
            '    add_library(dusklight STATIC ${DUSK_FILES})\n'
            '    target_compile_definitions(dusklight PRIVATE _UWP)\n'
            'else ()\n'
            '    add_executable(dusklight ${DUSK_FILES})\n'
            'endif ()'
        )
        text = replace_once(text, old, new, "static UWP target")

    # UWP wrapper owns runtime deployment and package resources.
    text = text.replace(
        "if (NOT APPLE)\n    add_custom_command(TARGET dusklight POST_BUILD",
        "if (NOT APPLE AND NOT DUSK_UWP)\n    add_custom_command(TARGET dusklight POST_BUILD",
    )
    text = text.replace(
        "if (WIN32)\n    set(DUSK_WINDOWS_RESOURCE_DIR",
        "if (WIN32 AND NOT DUSK_UWP)\n    set(DUSK_WINDOWS_RESOURCE_DIR",
    )
    # The legacy UWP fork deliberately omits Aurora runtime-DLL deployment because
    # the UWP wrapper owns package runtime files. The newer randomizer added a new
    # aurora_install_runtime_dlls() call later in the file. After the source merge
    # that call can survive outside the UWP guard while the helper include remains
    # inside it, causing CMake to fail with "Unknown CMake command". Keep both
    # runtime copy/install paths desktop-only.
    install_call = "aurora_install_runtime_dlls(dusklight ${CMAKE_INSTALL_PREFIX})"
    guarded_install = "if (NOT DUSK_UWP)\n    " + install_call + "\nendif ()"
    if install_call in text and guarded_install not in text:
        text = text.replace(install_call, guarded_install, 1)

    # Psapi is desktop crash/symbol support; do not force it into the Store/UWP link.
    text = text.replace(
        "if (WIN32)\n    target_link_libraries(dusklight PRIVATE Psapi)\nendif ()",
        "if (WIN32 AND NOT DUSK_UWP)\n    target_link_libraries(dusklight PRIVATE Psapi)\nendif ()",
    )

    path.write_text(text, encoding="utf-8")


def ensure_main_cpp_uwp(source: Path) -> None:
    path = source / "src/dusk/main.cpp"
    text = path.read_text(encoding="utf-8")

    text = text.replace(
        '(defined(TARGET_OS_TV) && TARGET_OS_TV)\n    (void)argc;',
        '(defined(TARGET_OS_TV) && TARGET_OS_TV) || defined(_UWP)\n    (void)argc;',
        1,
    )
    # Console allocation is desktop-only even though the static feed is compiled with _WIN32.
    text = text.replace(
        "int DuskMain(int argc, char* argv[]) {\n    WindowsSetupConsole(ShouldShowWindowsConsole(argc, argv));",
        "int DuskMain(int argc, char* argv[]) {\n#if !defined(_UWP)\n    WindowsSetupConsole(ShouldShowWindowsConsole(argc, argv));\n#endif",
        1,
    )
    text = text.replace("#if _WIN32\nint WINAPI wWinMain", "#if _WIN32 && !defined(_UWP)\nint WINAPI wWinMain", 1)

    if "SDL_MAIN_EXPORTED" not in text:
        main_anchor = 'int main(int argc, char* argv[]) {\n    return DuskMain(argc, argv);\n}\n'
        main_repl = (
            '#ifdef _UWP\n'
            '#define SDL_MAIN_EXPORTED\n'
            '#include "SDL3/SDL_main.h"\n'
            '#endif\n'
            + main_anchor
        )
        text = replace_once(text, main_anchor, main_repl, "SDL UWP main export")

    path.write_text(text, encoding="utf-8")



def patch_io_uwp_local_folder(source: Path) -> None:
    """Guarantee the UWP LocalState helper has a linked implementation.

    SternXD's FileBrowser declares dusk::io::uwp_local_folder_path() in io.hpp.
    On the newer randomizer tree the corresponding io.cpp hunk can be lost while
    merging with -X ours, leaving a declaration that compiles but an unresolved
    external at the final UWP link. Install the implementation explicitly in
    io.cpp so the static feed always exports the symbol.
    """
    path = source / "src/dusk/io.cpp"
    text = path.read_text(encoding="utf-8")

    if "uwp_local_folder_path()" in text:
        return

    include_anchor = '#include "dusk/io.hpp"\n'
    include_block = (
        '#include "dusk/io.hpp"\n'
        '#include "dusk/app_info.hpp"\n'
        '\n'
        '#include <SDL3/SDL_filesystem.h>\n'
    )
    text = replace_once(text, include_anchor, include_block, "UWP LocalState includes")

    namespace_close = "\n}  // namespace dusk::io\n"
    if namespace_close not in text:
        raise RuntimeError("Could not locate dusk::io namespace close while adding UWP LocalState helper")

    impl = (
        '\n#if defined(_UWP)\n'
        'std::optional<std::filesystem::path> uwp_local_folder_path() {\n'
        '    char* pref = SDL_GetPrefPath(dusk::OrgName, dusk::AppName);\n'
        '    if (pref == nullptr) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '\n'
        '    const std::filesystem::path p = path_from_utf8(pref);\n'
        '    SDL_free(pref);\n'
        '    if (p.empty()) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '\n'
        '    std::error_code ec;\n'
        '    const std::filesystem::path out = std::filesystem::absolute(p, ec).lexically_normal();\n'
        '    if (ec || out.empty()) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '    if (!std::filesystem::exists(out, ec) || !std::filesystem::is_directory(out, ec)) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '    return out;\n'
        '}\n'
        '#endif\n'
    )
    head, tail = text.rsplit(namespace_close, 1)
    text = head + impl + namespace_close + tail
    path.write_text(text, encoding="utf-8")


def patch_file_browser_current_pane(source: Path) -> None:
    # Forward-port SternXD's UWP FileBrowser to the pinned randomizer Pane API.
    # Keep compatibility local to the browser and use Component::children().
    path = source / "src/dusk/ui/file_browser.cpp"
    if not path.exists():
        raise RuntimeError("UWP FileBrowser source is missing")
    text = path.read_text(encoding="utf-8")

    old_last = '''bool try_focus_file_pane_last(Pane* pane, Rml::Event& event) {
    if (pane != nullptr && pane->focus_last()) {
        mDoAud_seStartMenu(kSoundItemFocus);
        event.StopImmediatePropagation();
        return true;
    }
    return false;
}
'''
    new_last = '''bool try_focus_file_pane_last(Pane* pane, Rml::Event& event) {
    if (pane == nullptr) {
        return false;
    }
    auto& children = pane->children();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        if (*it != nullptr && (*it)->focus()) {
            mDoAud_seStartMenu(kSoundItemFocus);
            event.StopImmediatePropagation();
            return true;
        }
    }
    return false;
}

int file_pane_row_count(Pane* pane) {
    return pane == nullptr ? 0 : static_cast<int>(pane->children().size());
}

int file_pane_child_index_containing(Pane* pane, Rml::Element* target) {
    if (pane == nullptr || target == nullptr) {
        return -1;
    }
    auto& children = pane->children();
    for (int i = 0; i < static_cast<int>(children.size()); ++i) {
        if (children[static_cast<std::size_t>(i)] != nullptr &&
            children[static_cast<std::size_t>(i)]->contains(target))
        {
            return i;
        }
    }
    return -1;
}
'''
    if old_last in text:
        text = text.replace(old_last, new_last, 1)
    elif "int file_pane_row_count(Pane* pane)" not in text:
        raise RuntimeError("Could not locate legacy FileBrowser Pane navigation helper")

    text = text.replace("mFilePane->row_count()", "file_pane_row_count(mFilePane.get())")
    text = text.replace(
        "mFilePane->child_index_containing(target)",
        "file_pane_child_index_containing(mFilePane.get(), target)",
    )

    stale = ("->row_count()", "->child_index_containing(", "->focus_last()")
    for marker in stale:
        if marker in text:
            raise RuntimeError(f"Legacy Pane API still referenced by UWP FileBrowser: {marker}")

    for marker in (
        "int file_pane_row_count(Pane* pane)",
        "int file_pane_child_index_containing(Pane* pane, Rml::Element* target)",
        "pane->children()",
    ):
        if marker not in text:
            raise RuntimeError(f"Current-Pane FileBrowser forward-port marker missing: {marker}")

    path.write_text(text, encoding="utf-8")


def patch_pane_uwp_compat(source: Path) -> None:
    """Restore the small Pane navigation surface used by the UWP FileBrowser.

    The pinned randomizer refactored Pane after SternXD's UWP FileBrowser was
    written, removing focus_last(), child_index_containing(), and row_count().
    FileBrowser still needs those navigation primitives. Re-add them as thin
    compatibility helpers over the current Pane child list without changing
    current Pane behavior or its newer bottom-spacer/focus-closeness logic.
    """
    hpp_path = source / "src/dusk/ui/pane.hpp"
    cpp_path = source / "src/dusk/ui/pane.cpp"
    hpp = hpp_path.read_text(encoding="utf-8")
    cpp = cpp_path.read_text(encoding="utf-8")

    if "bool focus_last();" not in hpp:
        hpp = replace_once(
            hpp,
            "    bool focus() override;\n",
            "    bool focus() override;\n    bool focus_last();\n",
            "Pane UWP focus_last declaration",
        )

    if "child_index_containing(Rml::Element* target) const" not in hpp:
        anchor = "    bool focus_closest_child(float posY);\n\nprivate:\n"
        addition = (
            "    bool focus_closest_child(float posY);\n\n"
            "    // Compatibility helpers used by the UWP in-app FileBrowser.\n"
            "    int child_index_containing(Rml::Element* target) const;\n"
            "    int row_count() const noexcept;\n\n"
            "private:\n"
        )
        hpp = replace_once(hpp, anchor, addition, "Pane UWP navigation declarations")

    if "bool Pane::focus_last()" not in cpp:
        anchor = "Rml::Element* Pane::add_section(const Rml::String& text) {\n"
        impl = (
            "bool Pane::focus_last() {\n"
            "    for (int i = static_cast<int>(mChildren.size()) - 1; i >= 0; --i) {\n"
            "        if (mChildren[static_cast<std::size_t>(i)]->focus()) {\n"
            "            return true;\n"
            "        }\n"
            "    }\n"
            "    return false;\n"
            "}\n\n"
        )
        cpp = replace_once(cpp, anchor, impl + anchor, "Pane UWP focus_last implementation")

    if "int Pane::child_index_containing(Rml::Element* target) const" not in cpp:
        anchor = "float Pane::get_focused_child_y() {\n"
        impl = (
            "int Pane::child_index_containing(Rml::Element* target) const {\n"
            "    if (target == nullptr) {\n"
            "        return -1;\n"
            "    }\n"
            "    for (int i = 0; i < static_cast<int>(mChildren.size()); ++i) {\n"
            "        if (mChildren[static_cast<std::size_t>(i)]->contains(target)) {\n"
            "            return i;\n"
            "        }\n"
            "    }\n"
            "    return -1;\n"
            "}\n\n"
            "int Pane::row_count() const noexcept {\n"
            "    return static_cast<int>(mChildren.size());\n"
            "}\n\n"
        )
        cpp = replace_once(cpp, anchor, impl + anchor, "Pane UWP child navigation implementation")

    hpp_path.write_text(hpp, encoding="utf-8")
    cpp_path.write_text(cpp, encoding="utf-8")

def patch_heart_color_cosmetic(source: Path) -> None:
    """Add a persistent HUD heart-color cosmetic to the pinned randomizer UI.

    The original console Twilight Princess Randomizer recolors the life texture's
    second picture layer and all four partial-heart pictures. Reproduce that
    behavior through the decomp's typed J2DPicture API rather than raw offsets.
    An empty/invalid value restores vanilla vertex color (white), so the stock
    red texture is preserved by default.
    """
    settings_h_path = source / "src/dusk/settings.h"
    settings_cpp_path = source / "src/dusk/settings.cpp"
    cosmetics_cpp_path = source / "src/dusk/ui/cosmetics.cpp"
    meter_path = source / "src/d/d_meter2_draw.cpp"

    settings_h = settings_h_path.read_text(encoding="utf-8")
    if "ConfigVar<std::string> heartColor;" not in settings_h:
        settings_h = replace_once(
            settings_h,
            "        ConfigVar<std::string> eponaColor;\n",
            "        ConfigVar<std::string> eponaColor;\n"
            "        ConfigVar<std::string> heartColor;\n",
            "heart color setting declaration",
        )
    settings_h_path.write_text(settings_h, encoding="utf-8")

    settings_cpp = settings_cpp_path.read_text(encoding="utf-8")
    if '.heartColor = {"cosmetics.heartColor", ""}' not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            '        .eponaColor = {"cosmetics.eponaColor", ""},\n',
            '        .eponaColor = {"cosmetics.eponaColor", ""},\n'
            '        .heartColor = {"cosmetics.heartColor", ""},\n',
            "heart color default",
        )
    if "Register(g_userSettings.cosmetics.heartColor);" not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            "    Register(g_userSettings.cosmetics.eponaColor);\n",
            "    Register(g_userSettings.cosmetics.eponaColor);\n"
            "    Register(g_userSettings.cosmetics.heartColor);\n",
            "heart color registration",
        )
    settings_cpp_path.write_text(settings_cpp, encoding="utf-8")

    cosmetics_cpp = cosmetics_cpp_path.read_text(encoding="utf-8")
    if 'add_cosmetic_option(leftPane, rightPane, "Heart Color", cosmetics.heartColor);' not in cosmetics_cpp:
        anchor = '    add_tab("Misc Colors", [this, &cosmetics](Rml::Element* content) {\n'
        hud_tab = (
            '    add_tab("HUD Colors", [this, &cosmetics](Rml::Element* content) {\n'
            '        auto& leftPane = add_child<Pane>(content, Pane::Type::Controlled);\n'
            '        auto& rightPane = add_child<Pane>(content, Pane::Type::Controlled);\n\n'
            '        add_cosmetic_option(leftPane, rightPane, "Heart Color", cosmetics.heartColor);\n'
            '    });\n\n'
        )
        cosmetics_cpp = replace_once(cosmetics_cpp, anchor, hud_tab + anchor, "HUD heart color cosmetics tab")
    cosmetics_cpp_path.write_text(cosmetics_cpp, encoding="utf-8")

    meter = meter_path.read_text(encoding="utf-8")
    marker = "// TPR UWP: live HUD heart-color cosmetic"
    if marker not in meter:
        anchor = "void dMeter2Draw_c::drawLife(s16 i_maxLife, s16 i_life, f32 i_posX, f32 i_posY) {\n"
        block = r'''void dMeter2Draw_c::drawLife(s16 i_maxLife, s16 i_life, f32 i_posX, f32 i_posY) {
#if TARGET_PC
    // TPR UWP: live HUD heart-color cosmetic. The original console randomizer
    // colors mpLifeTexture[][1] plus the four big/partial-heart pictures.
    JUtility::TColor heartVertexColor(255, 255, 255, 255);
    const auto& heartColorStr = dusk::getSettings().cosmetics.heartColor.getValue();
    if (dusk::cosmetics::is_valid_hex_color_str(heartColorStr)) {
        const GXColor color = dusk::cosmetics::hex_color_str_to_gx_color(heartColorStr);
        heartVertexColor = JUtility::TColor(color.r, color.g, color.b, 255);
    }

    for (int i = 0; i < 20; ++i) {
        if (mpLifeTexture[i][1] != nullptr && mpLifeTexture[i][1]->getPanePtr() != nullptr) {
            static_cast<J2DPicture*>(mpLifeTexture[i][1]->getPanePtr())->setCornerColor(heartVertexColor);
        }
    }

    static u64 const tprHeartQuarterTags[] = {
        MULTI_CHAR('bigh_00'), MULTI_CHAR('bigh_01'), MULTI_CHAR('bigh_02'), MULTI_CHAR('bigh_03')};
    for (u64 tag : tprHeartQuarterTags) {
        if (auto* pane = mpScreen->search(tag)) {
            static_cast<J2DPicture*>(pane)->setCornerColor(heartVertexColor);
        }
    }
#endif
'''
        meter = replace_once(meter, anchor, block, "live HUD heart-color application")
    meter_path.write_text(meter, encoding="utf-8")


def patch_controller_cursor_mode(source: Path) -> None:
    """Add SOH-style controller cursor mode to Dusklight's RmlUi input path.

    Hold L3+R3 for 0.35s while a Dusklight document is visible to toggle.
    Right stick moves the pointer, A is left click, and holding A while moving
    performs drag. The overlay renders a high-contrast cursor and large ON/OFF
    confirmation. Cursor input is isolated to UI mode so gameplay is untouched
    whenever the mode is off.
    """
    input_hpp_path = source / "src/dusk/ui/input.hpp"
    input_cpp_path = source / "src/dusk/ui/input.cpp"
    overlay_hpp_path = source / "src/dusk/ui/overlay.hpp"
    overlay_cpp_path = source / "src/dusk/ui/overlay.cpp"
    overlay_rcss_path = source / "res/rml/overlay.rcss"

    input_hpp = input_hpp_path.read_text(encoding="utf-8")
    if "controller_cursor_active()" not in input_hpp:
        anchor = "void release_input_block() noexcept;\n"
        addition = (
            "void release_input_block() noexcept;\n\n"
            "// SOH-style controller-driven RmlUi pointer.\n"
            "bool controller_cursor_active() noexcept;\n"
            "bool controller_cursor_status_visible() noexcept;\n"
            "bool controller_cursor_pressed() noexcept;\n"
            "float controller_cursor_x() noexcept;\n"
            "float controller_cursor_y() noexcept;\n"
        )
        input_hpp = replace_once(input_hpp, anchor, addition, "controller cursor input API")
    input_hpp_path.write_text(input_hpp, encoding="utf-8")

    input_cpp = input_cpp_path.read_text(encoding="utf-8")

    if "kControllerCursorToggleHold" not in input_cpp:
        anchor = "constexpr double kGamepadMenuChordGraceDuration = 0.12;\n"
        addition = (
            anchor
            + "constexpr double kControllerCursorToggleHold = 0.35;\n"
            + "constexpr double kControllerCursorStatusDuration = 1.35;\n"
            + "constexpr float kControllerCursorDeadzone = 0.18f;\n"
            + "constexpr float kControllerCursorSpeed = 1150.0f;\n"
        )
        input_cpp = replace_once(input_cpp, anchor, addition, "controller cursor constants")

    if "sControllerCursorActive" not in input_cpp:
        anchor = "TouchTapState sTouchMenuTap;\n"
        state = (
            anchor
            + "\n// TPR UWP / SOH-style controller cursor state.\n"
            + "bool sControllerCursorActive = false;\n"
            + "bool sControllerCursorL3Held = false;\n"
            + "bool sControllerCursorR3Held = false;\n"
            + "bool sControllerCursorChordConsumed = false;\n"
            + "bool sControllerCursorClickHeld = false;\n"
            + "bool sControllerCursorPositionInitialized = false;\n"
            + "double sControllerCursorChordStartedAt = 0.0;\n"
            + "double sControllerCursorStatusUntil = 0.0;\n"
            + "double sControllerCursorLastUpdateAt = 0.0;\n"
            + "Sint16 sControllerCursorAxisX = 0;\n"
            + "Sint16 sControllerCursorAxisY = 0;\n"
            + "float sControllerCursorX = 0.0f;\n"
            + "float sControllerCursorY = 0.0f;\n"
        )
        input_cpp = replace_once(input_cpp, anchor, state, "controller cursor state")

    if "void rumble_controller_cursor_toggle()" not in input_cpp:
        anchor = "double now_seconds() noexcept {\n    return static_cast<double>(SDL_GetTicksNS()) / 1000000000.0;\n}\n"
        helpers = r'''double now_seconds() noexcept {
    return static_cast<double>(SDL_GetTicksNS()) / 1000000000.0;
}

bool is_controller_cursor_chord_button(SDL_GamepadButton button) noexcept {
    return button == SDL_GAMEPAD_BUTTON_LEFT_STICK || button == SDL_GAMEPAD_BUTTON_RIGHT_STICK;
}

void set_controller_cursor_chord_button(SDL_GamepadButton button, bool held) noexcept {
    if (button == SDL_GAMEPAD_BUTTON_LEFT_STICK) {
        sControllerCursorL3Held = held;
    } else if (button == SDL_GAMEPAD_BUTTON_RIGHT_STICK) {
        sControllerCursorR3Held = held;
    }

    if (sControllerCursorL3Held && sControllerCursorR3Held) {
        if (sControllerCursorChordStartedAt <= 0.0) {
            sControllerCursorChordStartedAt = now_seconds();
        }
    } else {
        sControllerCursorChordStartedAt = 0.0;
        sControllerCursorChordConsumed = false;
    }
}

void rumble_controller_cursor_toggle() noexcept {
    const s32 index = PADGetIndexForPort(PAD_CHAN0);
    if (index < 0) {
        return;
    }
    if (SDL_Gamepad* gamepad = PADGetSDLGamepadForIndex(static_cast<u32>(index))) {
        SDL_RumbleGamepad(gamepad, 0x3000, 0x6000, 120);
    }
}

float controller_cursor_axis_response(Sint16 raw) noexcept {
    const float normalized = std::clamp(static_cast<float>(raw) / 32767.0f, -1.0f, 1.0f);
    const float magnitude = std::abs(normalized);
    if (magnitude <= kControllerCursorDeadzone) {
        return 0.0f;
    }
    const float scaled = (magnitude - kControllerCursorDeadzone) / (1.0f - kControllerCursorDeadzone);
    // Slightly square the response for precision near center while retaining full-speed travel.
    const float shaped = scaled * scaled;
    return normalized < 0.0f ? -shaped : shaped;
}

void release_controller_cursor_click(Rml::Context& context) noexcept {
    if (!sControllerCursorClickHeld) {
        return;
    }
    context.ProcessMouseButtonUp(0, 0);
    sControllerCursorClickHeld = false;
}

void disable_controller_cursor(Rml::Context& context, bool showStatus) noexcept {
    if (!sControllerCursorActive) {
        return;
    }
    release_controller_cursor_click(context);
    sControllerCursorActive = false;
    sControllerCursorAxisX = 0;
    sControllerCursorAxisY = 0;
    context.ProcessMouseLeave();
    if (showStatus) {
        sControllerCursorStatusUntil = now_seconds() + kControllerCursorStatusDuration;
        rumble_controller_cursor_toggle();
    } else {
        sControllerCursorStatusUntil = 0.0;
    }
}

void update_controller_cursor(Rml::Context& context) noexcept {
    const double now = now_seconds();
    const bool uiVisible = any_document_visible();

    // Cursor mode is deliberately UI-only. Closing the final Dusklight document
    // returns control to the game immediately and clears the toggle chord so a
    // held stick-click pair cannot arm itself across a menu close/reopen.
    if (!uiVisible) {
        if (sControllerCursorActive) {
            disable_controller_cursor(context, false);
        }
        sControllerCursorL3Held = false;
        sControllerCursorR3Held = false;
        sControllerCursorChordConsumed = false;
        sControllerCursorChordStartedAt = 0.0;
    }

    if (sControllerCursorL3Held && sControllerCursorR3Held &&
        !sControllerCursorChordConsumed && sControllerCursorChordStartedAt > 0.0 &&
        now - sControllerCursorChordStartedAt >= kControllerCursorToggleHold &&
        uiVisible)
    {
        sControllerCursorChordConsumed = true;
        if (sControllerCursorActive) {
            disable_controller_cursor(context, true);
        } else {
            sControllerCursorActive = true;
            sControllerCursorStatusUntil = now + kControllerCursorStatusDuration;
            rumble_controller_cursor_toggle();

            const auto dimensions = context.GetDimensions();
            if (!sControllerCursorPositionInitialized) {
                sControllerCursorX = static_cast<float>(dimensions.x) * 0.5f;
                sControllerCursorY = static_cast<float>(dimensions.y) * 0.5f;
                sControllerCursorPositionInitialized = true;
            }
            context.ProcessMouseMove(
                static_cast<int>(sControllerCursorX), static_cast<int>(sControllerCursorY), 0);
        }
    }

    if (!sControllerCursorActive) {
        sControllerCursorLastUpdateAt = now;
        return;
    }

    const auto dimensions = context.GetDimensions();
    const double elapsed = sControllerCursorLastUpdateAt > 0.0 ? now - sControllerCursorLastUpdateAt : 0.0;
    const float dt = static_cast<float>(std::clamp(elapsed, 0.0, 0.05));
    sControllerCursorLastUpdateAt = now;

    const float dx = controller_cursor_axis_response(sControllerCursorAxisX) * kControllerCursorSpeed * dt;
    const float dy = controller_cursor_axis_response(sControllerCursorAxisY) * kControllerCursorSpeed * dt;
    if (dx == 0.0f && dy == 0.0f) {
        return;
    }

    const float maxX = static_cast<float>(std::max(dimensions.x - 1, 0));
    const float maxY = static_cast<float>(std::max(dimensions.y - 1, 0));
    sControllerCursorX = std::clamp(sControllerCursorX + dx, 0.0f, maxX);
    sControllerCursorY = std::clamp(sControllerCursorY + dy, 0.0f, maxY);
    context.ProcessMouseMove(
        static_cast<int>(sControllerCursorX), static_cast<int>(sControllerCursorY), 0);
}
'''
        input_cpp = replace_once(input_cpp, anchor, helpers, "controller cursor helpers")

    if "#include <cmath>" not in input_cpp:
        input_cpp = replace_once(
            input_cpp,
            "#include <array>\n",
            "#include <array>\n#include <cmath>\n",
            "controller cursor cmath include",
        )

    axis_marker = "// TPR UWP: controller cursor right-stick routing"
    if axis_marker not in input_cpp:
        old_axis = '''    if (event.type == SDL_EVENT_GAMEPAD_AXIS_MOTION) {
        process_axis_direction(*context, event.gaxis, AXIS_SIGN_POSITIVE);
        process_axis_direction(*context, event.gaxis, AXIS_SIGN_NEGATIVE);
        sync_input_block();
        return;
    }
'''
        new_axis = '''    if (event.type == SDL_EVENT_GAMEPAD_AXIS_MOTION) {
        // TPR UWP: controller cursor right-stick routing.
        const auto nativeAxis = static_cast<SDL_GamepadAxis>(event.gaxis.axis);
        if (nativeAxis == SDL_GAMEPAD_AXIS_RIGHTX) {
            sControllerCursorAxisX = event.gaxis.value;
            if (sControllerCursorActive) {
                sync_input_block();
                return;
            }
        } else if (nativeAxis == SDL_GAMEPAD_AXIS_RIGHTY) {
            sControllerCursorAxisY = event.gaxis.value;
            if (sControllerCursorActive) {
                sync_input_block();
                return;
            }
        }

        process_axis_direction(*context, event.gaxis, AXIS_SIGN_POSITIVE);
        process_axis_direction(*context, event.gaxis, AXIS_SIGN_NEGATIVE);
        sync_input_block();
        return;
    }
'''
        input_cpp = replace_once(input_cpp, old_axis, new_axis, "controller cursor right-stick event routing")

        button_anchor = '''    auto* repeat = button_repeat_state(static_cast<SDL_GamepadButton>(event.gbutton.button));
    u32 port = 0;
'''
        button_block = '''    const auto nativeCursorButton = static_cast<SDL_GamepadButton>(event.gbutton.button);
    const bool cursorButtonDown = event.type == SDL_EVENT_GAMEPAD_BUTTON_DOWN;

    // L3+R3 is reserved for cursor mode while a Dusklight document is visible.
    if (is_controller_cursor_chord_button(nativeCursorButton) && any_document_visible()) {
        set_controller_cursor_chord_button(nativeCursorButton, cursorButtonDown);
        sync_input_block();
        return;
    }

    // Xbox A is a true pointer left-click while cursor mode is active. Keeping the
    // button held while the right stick moves naturally becomes an RmlUi drag.
    if (sControllerCursorActive && nativeCursorButton == SDL_GAMEPAD_BUTTON_SOUTH) {
        if (cursorButtonDown && !sControllerCursorClickHeld) {
            context->ProcessMouseButtonDown(0, 0);
            sControllerCursorClickHeld = true;
        } else if (!cursorButtonDown && sControllerCursorClickHeld) {
            context->ProcessMouseButtonUp(0, 0);
            sControllerCursorClickHeld = false;
        }
        sync_input_block();
        return;
    }

    auto* repeat = button_repeat_state(static_cast<SDL_GamepadButton>(event.gbutton.button));
    u32 port = 0;
'''
        input_cpp = replace_once(input_cpp, button_anchor, button_block, "controller cursor button routing")

    if "update_controller_cursor(*context);" not in input_cpp:
        update_fn = "void update_input() noexcept {\n    auto* context = aurora::rmlui::get_context();\n    if (context != nullptr) {\n"
        replacement = update_fn + "        update_controller_cursor(*context);\n"
        input_cpp = replace_once(input_cpp, update_fn, replacement, "controller cursor per-frame update")

    reset_marker = "// TPR UWP: reset controller cursor transient state"
    if reset_marker not in input_cpp:
        old_reset = (
            "void reset_input_state() noexcept {\n"
            "    clear_gamepad_repeats();\n"
            "    reset_touch_menu_tap();\n"
            "}\n"
        )
        new_reset = (
            "void reset_input_state() noexcept {\n"
            "    clear_gamepad_repeats();\n"
            "    reset_touch_menu_tap();\n\n"
            "    // TPR UWP: reset controller cursor transient state.\n"
            "    if (auto* context = aurora::rmlui::get_context()) {\n"
            "        release_controller_cursor_click(*context);\n"
            "        if (sControllerCursorActive) {\n"
            "            context->ProcessMouseLeave();\n"
            "        }\n"
            "    }\n"
            "    sControllerCursorActive = false;\n"
            "    sControllerCursorL3Held = false;\n"
            "    sControllerCursorR3Held = false;\n"
            "    sControllerCursorChordConsumed = false;\n"
            "    sControllerCursorChordStartedAt = 0.0;\n"
            "    sControllerCursorStatusUntil = 0.0;\n"
            "    sControllerCursorLastUpdateAt = 0.0;\n"
            "    sControllerCursorAxisX = 0;\n"
            "    sControllerCursorAxisY = 0;\n"
            "    sControllerCursorPositionInitialized = false;\n"
            "}\n"
        )
        input_cpp = replace_once(input_cpp, old_reset, new_reset, "controller cursor reset state")

    if "bool controller_cursor_active() noexcept" not in input_cpp:
        namespace_close = "\n}  // namespace dusk::ui\n"
        accessors = r'''
bool controller_cursor_active() noexcept {
    return sControllerCursorActive;
}

bool controller_cursor_status_visible() noexcept {
    return now_seconds() < sControllerCursorStatusUntil;
}

bool controller_cursor_pressed() noexcept {
    return sControllerCursorClickHeld;
}

float controller_cursor_x() noexcept {
    return sControllerCursorX;
}

float controller_cursor_y() noexcept {
    return sControllerCursorY;
}

}  // namespace dusk::ui
'''
        if not input_cpp.endswith(namespace_close):
            raise RuntimeError("Could not locate dusk::ui input namespace close for controller cursor accessors")
        input_cpp = input_cpp[: -len(namespace_close)] + "\n" + accessors

    input_cpp_path.write_text(input_cpp, encoding="utf-8")

    overlay_hpp = overlay_hpp_path.read_text(encoding="utf-8")
    if "mControllerCursor" not in overlay_hpp:
        anchor = "    Rml::Element* mMenuNotification = nullptr;\n"
        overlay_hpp = replace_once(
            overlay_hpp,
            anchor,
            anchor
            + "    Rml::Element* mControllerCursor = nullptr;\n"
            + "    Rml::Element* mControllerCursorStatus = nullptr;\n",
            "controller cursor overlay members",
        )
    overlay_hpp_path.write_text(overlay_hpp, encoding="utf-8")

    overlay_cpp = overlay_cpp_path.read_text(encoding="utf-8")
    if '#include "input.hpp"' not in overlay_cpp:
        overlay_cpp = replace_once(
            overlay_cpp,
            '#include "fmt/format.h"\n',
            '#include "fmt/format.h"\n#include "input.hpp"\n',
            "controller cursor overlay input include",
        )

    if 'controller-cursor id="controller-cursor"' not in overlay_cpp:
        anchor = '    <speedrun-timer id="speedrun-timer">\n'
        markup = (
            '    <controller-cursor id="controller-cursor" />\n'
            '    <cursor-mode-status id="cursor-mode-status" />\n'
        )
        overlay_cpp = replace_once(overlay_cpp, anchor, markup + anchor, "controller cursor overlay markup")

    if 'GetElementById("controller-cursor")' not in overlay_cpp:
        anchor = '    mSpeedrunTimer = mDocument->GetElementById("speedrun-timer");\n'
        overlay_cpp = replace_once(
            overlay_cpp,
            anchor,
            '    mControllerCursor = mDocument->GetElementById("controller-cursor");\n'
            '    mControllerCursorStatus = mDocument->GetElementById("cursor-mode-status");\n'
            + anchor,
            "controller cursor overlay lookup",
        )

    if "controller_cursor_status_visible()" not in overlay_cpp:
        anchor = '''    if (mFpsCounter != nullptr) {
'''
        update = r'''    if (mControllerCursor != nullptr) {
        if (input::controller_cursor_active()) {
            mControllerCursor->SetAttribute("open", "");
            if (input::controller_cursor_pressed()) {
                mControllerCursor->SetAttribute("pressed", "");
            } else {
                mControllerCursor->RemoveAttribute("pressed");
            }
            mControllerCursor->SetProperty(
                Rml::PropertyId::Left,
                Rml::Property(input::controller_cursor_x() - 10.0f, Rml::Unit::PX));
            mControllerCursor->SetProperty(
                Rml::PropertyId::Top,
                Rml::Property(input::controller_cursor_y() - 10.0f, Rml::Unit::PX));
        } else {
            mControllerCursor->RemoveAttribute("open");
            mControllerCursor->RemoveAttribute("pressed");
        }
    }

    if (mControllerCursorStatus != nullptr) {
        if (input::controller_cursor_status_visible()) {
            mControllerCursorStatus->SetInnerRML(
                input::controller_cursor_active() ? "CURSOR MODE ON" : "CURSOR MODE OFF");
            mControllerCursorStatus->SetAttribute("open", "");
        } else {
            mControllerCursorStatus->RemoveAttribute("open");
        }
    }

    if (mFpsCounter != nullptr) {
'''
        overlay_cpp = replace_once(overlay_cpp, anchor, update, "controller cursor overlay update")
    overlay_cpp_path.write_text(overlay_cpp, encoding="utf-8")

    overlay_rcss = overlay_rcss_path.read_text(encoding="utf-8")
    if "controller-cursor[open]" not in overlay_rcss:
        overlay_rcss += r'''

/* TPR UWP / SOH-style controller cursor. */
controller-cursor {
    display: none;
    position: absolute;
    width: 20dp;
    height: 20dp;
    z-index: 10000;
    pointer-events: none;
    border: 3dp #111111;
    border-radius: 10dp;
    background-color: #ffffff;
    box-shadow: 0 0 6dp 2dp rgba(0, 0, 0, 70%);
}

controller-cursor[open] {
    display: block;
}

controller-cursor[pressed] {
    background-color: #C2A42D;
    transform: scale(0.82);
}

cursor-mode-status {
    display: none;
    position: absolute;
    left: 50%;
    top: 34%;
    z-index: 10001;
    pointer-events: none;
    transform: translateX(-50%);
    padding: 16dp 28dp;
    border: 2dp #C2A42D;
    border-radius: 12dp;
    background-color: rgba(12, 13, 10, 88%);
    color: #ffffff;
    font-family: "Fira Sans Condensed";
    font-size: 34dp;
    font-weight: bold;
    text-align: center;
    white-space: nowrap;
}

cursor-mode-status[open] {
    display: block;
}
'''
    overlay_rcss_path.write_text(overlay_rcss, encoding="utf-8")


def patch_hud_color_cosmetics(source: Path) -> None:
    # Expand CP15 heart color into persistent A/B/X/Y/Z HUD button colors.
    # J2DWindow defaults are cached before override so Default restores vanilla live.
    settings_h_path = source / "src/dusk/settings.h"
    settings_cpp_path = source / "src/dusk/settings.cpp"
    cosmetics_cpp_path = source / "src/dusk/ui/cosmetics.cpp"
    meter_path = source / "src/d/d_meter2_draw.cpp"

    settings_h = settings_h_path.read_text(encoding="utf-8")
    declarations = (
        "        ConfigVar<std::string> aButtonColor;\n"
        "        ConfigVar<std::string> bButtonColor;\n"
        "        ConfigVar<std::string> xButtonColor;\n"
        "        ConfigVar<std::string> yButtonColor;\n"
        "        ConfigVar<std::string> zButtonColor;\n"
    )
    if "ConfigVar<std::string> aButtonColor;" not in settings_h:
        settings_h = replace_once(
            settings_h,
            "        ConfigVar<std::string> heartColor;\n",
            "        ConfigVar<std::string> heartColor;\n" + declarations,
            "HUD button-color setting declarations",
        )
    settings_h_path.write_text(settings_h, encoding="utf-8")

    settings_cpp = settings_cpp_path.read_text(encoding="utf-8")
    defaults = (
        '        .aButtonColor = {"cosmetics.aButtonColor", ""},\n'
        '        .bButtonColor = {"cosmetics.bButtonColor", ""},\n'
        '        .xButtonColor = {"cosmetics.xButtonColor", ""},\n'
        '        .yButtonColor = {"cosmetics.yButtonColor", ""},\n'
        '        .zButtonColor = {"cosmetics.zButtonColor", ""},\n'
    )
    if '.aButtonColor = {"cosmetics.aButtonColor", ""}' not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            '        .heartColor = {"cosmetics.heartColor", ""},\n',
            '        .heartColor = {"cosmetics.heartColor", ""},\n' + defaults,
            "HUD button-color defaults",
        )
    registrations = (
        "    Register(g_userSettings.cosmetics.aButtonColor);\n"
        "    Register(g_userSettings.cosmetics.bButtonColor);\n"
        "    Register(g_userSettings.cosmetics.xButtonColor);\n"
        "    Register(g_userSettings.cosmetics.yButtonColor);\n"
        "    Register(g_userSettings.cosmetics.zButtonColor);\n"
    )
    if "Register(g_userSettings.cosmetics.aButtonColor);" not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            "    Register(g_userSettings.cosmetics.heartColor);\n",
            "    Register(g_userSettings.cosmetics.heartColor);\n" + registrations,
            "HUD button-color registrations",
        )
    settings_cpp_path.write_text(settings_cpp, encoding="utf-8")

    cosmetics_cpp = cosmetics_cpp_path.read_text(encoding="utf-8")
    hud_anchor = '        add_cosmetic_option(leftPane, rightPane, "Heart Color", cosmetics.heartColor);\n'
    hud_options = (
        hud_anchor
        + '        add_cosmetic_option(leftPane, rightPane, "A Button Color", cosmetics.aButtonColor);\n'
        + '        add_cosmetic_option(leftPane, rightPane, "B Button Color", cosmetics.bButtonColor);\n'
        + '        add_cosmetic_option(leftPane, rightPane, "X Button Color", cosmetics.xButtonColor);\n'
        + '        add_cosmetic_option(leftPane, rightPane, "Y Button Color", cosmetics.yButtonColor);\n'
        + '        add_cosmetic_option(leftPane, rightPane, "Z Button Color", cosmetics.zButtonColor);\n'
    )
    if '"A Button Color", cosmetics.aButtonColor' not in cosmetics_cpp:
        cosmetics_cpp = replace_once(
            cosmetics_cpp, hud_anchor, hud_options, "HUD button color cosmetics controls"
        )
    cosmetics_cpp_path.write_text(cosmetics_cpp, encoding="utf-8")

    meter = meter_path.read_text(encoding="utf-8")
    if '#include "JSystem/J2DGraph/J2DWindow.h"' not in meter:
        meter = replace_once(
            meter,
            '#include "JSystem/J2DGraph/J2DTextBox.h"\n',
            '#include "JSystem/J2DGraph/J2DTextBox.h"\n#include "JSystem/J2DGraph/J2DWindow.h"\n',
            "HUD button color J2DWindow include",
        )
    if "#include <unordered_map>" not in meter:
        meter = replace_once(
            meter,
            "#include <algorithm>\n",
            "#include <algorithm>\n#include <unordered_map>\n",
            "HUD button color unordered_map include",
        )

    helper_marker = "// TPR UWP: typed HUD button-color cosmetics"
    if helper_marker not in meter:
        helper_anchor = "// The screen corner each HUD group is anchored to. A pane scales around its own origin,\n"
        helper = r'''// TPR UWP: typed HUD button-color cosmetics.
struct TprHudWindowColors {
    JUtility::TColor c0;
    JUtility::TColor c1;
    JUtility::TColor c2;
    JUtility::TColor c3;
};

std::unordered_map<J2DWindow*, TprHudWindowColors> sTprHudWindowDefaults;

void dApplyHudWindowColor(CPaneMgr* pane, const std::string& colorString) {
    if (pane == nullptr || pane->getPanePtr() == nullptr || pane->getPanePtr()->getTypeID() != 17) {
        return;
    }

    auto* window = static_cast<J2DWindow*>(pane->getPanePtr());
    auto it = sTprHudWindowDefaults.find(window);
    if (it == sTprHudWindowDefaults.end()) {
        J2DWindow::TContentsColor original;
        window->getContentsColor(original);
        it = sTprHudWindowDefaults.emplace(
            window, TprHudWindowColors{original.field_0x0, original.field_0x4,
                                       original.field_0x8, original.field_0xc}).first;
    }

    if (dusk::cosmetics::is_valid_hex_color_str(colorString)) {
        const GXColor color = dusk::cosmetics::hex_color_str_to_gx_color(colorString);
        const JUtility::TColor tint(color.r, color.g, color.b, 255);
        window->setContentsColor(tint);
        return;
    }

    const auto& original = it->second;
    window->setContentsColor(original.c0, original.c1, original.c2, original.c3);
}

'''
        meter = replace_once(meter, helper_anchor, helper + helper_anchor, "typed HUD button-color helper")

    draw_marker = "// TPR UWP: apply live HUD button-color cosmetics"
    if draw_marker not in meter:
        draw_anchor = "void dMeter2Draw_c::draw() {\n    J2DGrafContext* graf_ctx = dComIfGp_getCurrentGrafPort();\n"
        draw_block = r'''void dMeter2Draw_c::draw() {
#if TARGET_PC
    // TPR UWP: apply live HUD button-color cosmetics immediately before the HUD draw.
    const auto& tprHud = dusk::getSettings().cosmetics;
    dApplyHudWindowColor(mpButtonA, tprHud.aButtonColor.getValue());
    dApplyHudWindowColor(mpButtonB, tprHud.bButtonColor.getValue());
    dApplyHudWindowColor(mpButtonXY[0], tprHud.xButtonColor.getValue());
    dApplyHudWindowColor(mpButtonXY[1], tprHud.yButtonColor.getValue());
    dApplyHudWindowColor(mpButtonXY[2], tprHud.zButtonColor.getValue());
#endif
    J2DGrafContext* graf_ctx = dComIfGp_getCurrentGrafPort();
'''
        meter = replace_once(meter, draw_anchor, draw_block, "live HUD button-color application")
    meter_path.write_text(meter, encoding="utf-8")



def patch_seeded_hud_cosmetics(source: Path) -> None:
    '''Make HUD cosmetics deterministic per randomizer seed when enabled.

    The toggle never overwrites the user's manual cosmetic values. While a
    randomizer seed is active, the seed hash selects stable colors for hearts
    and A/B/X/Y/Z. Disabling the toggle immediately restores the manual values.
    '''
    settings_h_path = source / "src/dusk/settings.h"
    settings_cpp_path = source / "src/dusk/settings.cpp"
    cosmetics_cpp_path = source / "src/dusk/ui/cosmetics.cpp"
    meter_path = source / "src/d/d_meter2_draw.cpp"

    settings_h = settings_h_path.read_text(encoding="utf-8")
    if "ConfigVar<bool> randomizeHudColorsWithSeed;" not in settings_h:
        settings_h = replace_once(
            settings_h,
            "        ConfigVar<std::string> zButtonColor;\n",
            "        ConfigVar<std::string> zButtonColor;\n"
            "        ConfigVar<bool> randomizeHudColorsWithSeed;\n",
            "seeded HUD cosmetic setting declaration",
        )
    settings_h_path.write_text(settings_h, encoding="utf-8")

    settings_cpp = settings_cpp_path.read_text(encoding="utf-8")
    if '.randomizeHudColorsWithSeed = {"cosmetics.randomizeHudColorsWithSeed", false}' not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            '        .zButtonColor = {"cosmetics.zButtonColor", ""},\n',
            '        .zButtonColor = {"cosmetics.zButtonColor", ""},\n'
            '        .randomizeHudColorsWithSeed = {"cosmetics.randomizeHudColorsWithSeed", false},\n',
            "seeded HUD cosmetic default",
        )
    if "Register(g_userSettings.cosmetics.randomizeHudColorsWithSeed);" not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            "    Register(g_userSettings.cosmetics.zButtonColor);\n",
            "    Register(g_userSettings.cosmetics.zButtonColor);\n"
            "    Register(g_userSettings.cosmetics.randomizeHudColorsWithSeed);\n",
            "seeded HUD cosmetic registration",
        )
    settings_cpp_path.write_text(settings_cpp, encoding="utf-8")

    cosmetics_cpp = cosmetics_cpp_path.read_text(encoding="utf-8")
    if '#include "bool_button.hpp"' not in cosmetics_cpp:
        cosmetics_cpp = replace_once(
            cosmetics_cpp,
            '#include "pane.hpp"\n',
            '#include "pane.hpp"\n#include "bool_button.hpp"\n',
            "seeded HUD BoolButton include",
        )

    seeded_marker = 'Randomize Cosmetics With Seed'
    if seeded_marker not in cosmetics_cpp:
        anchor = (
            '        auto& rightPane = add_child<Pane>(content, Pane::Type::Controlled);\n\n'
            '        add_cosmetic_option(leftPane, rightPane, "Heart Color", cosmetics.heartColor);\n'
        )
        addition = r'''        auto& rightPane = add_child<Pane>(content, Pane::Type::Controlled);

        auto& seededHudButton = leftPane.add_child<BoolButton>(BoolButton::Props{
            .key = "Randomize Cosmetics With Seed",
            .getValue = [&cosmetics] { return cosmetics.randomizeHudColorsWithSeed.getValue(); },
            .setValue = [&cosmetics](bool value) {
                cosmetics.randomizeHudColorsWithSeed.setValue(value);
                config::save();
            },
            .isModified = [&cosmetics] {
                return cosmetics.randomizeHudColorsWithSeed.getValue() !=
                       cosmetics.randomizeHudColorsWithSeed.getDefaultValue();
            },
        });
        leftPane.register_control(seededHudButton, rightPane, [](Pane& pane) {
            pane.clear();
            pane.add_rml(
                "Deterministically randomizes Heart and A/B/X/Y/Z HUD colors from the active "
                "randomizer seed. The same seed always receives the same HUD colors. Manual "
                "HUD colors are preserved and resume immediately when this is disabled.");
        });

        add_cosmetic_option(leftPane, rightPane, "Heart Color", cosmetics.heartColor);
'''
        cosmetics_cpp = replace_once(
            cosmetics_cpp, anchor, addition, "Randomize Cosmetics With Seed HUD toggle"
        )
    cosmetics_cpp_path.write_text(cosmetics_cpp, encoding="utf-8")

    meter = meter_path.read_text(encoding="utf-8")
    if '#include "dusk/randomizer/game/randomizer_context.hpp"' not in meter:
        meter = replace_once(
            meter,
            '#include "dusk/settings.h"\n',
            '#include "dusk/settings.h"\n#include "dusk/randomizer/game/randomizer_context.hpp"\n',
            "seeded HUD randomizer context include",
        )
    if "#include <string_view>" not in meter:
        meter = replace_once(
            meter,
            "#include <unordered_map>\n",
            "#include <unordered_map>\n#include <string_view>\n",
            "seeded HUD string_view include",
        )

    seeded_helper_marker = "// TPR UWP: deterministic per-seed HUD cosmetics"
    if seeded_helper_marker not in meter:
        anchor = "std::unordered_map<J2DWindow*, TprHudWindowColors> sTprHudWindowDefaults;\n\n"
        helper = r'''std::unordered_map<J2DWindow*, TprHudWindowColors> sTprHudWindowDefaults;

// TPR UWP: deterministic per-seed HUD cosmetics. FNV-1a over the generated
// randomizer hash plus a per-element salt selects from a TV-readable palette.
bool dTprSeededHudColor(std::string_view salt, JUtility::TColor& outColor) {
    const auto& cosmetics = dusk::getSettings().cosmetics;
    if (!cosmetics.randomizeHudColorsWithSeed.getValue() || !randomizer_IsActive()) {
        return false;
    }

    const auto& seedHash = randomizer_GetContext().mHash;
    if (seedHash.empty()) {
        return false;
    }

    u32 hash = 2166136261u;
    auto mix = [&hash](unsigned char value) {
        hash ^= static_cast<u32>(value);
        hash *= 16777619u;
    };
    for (unsigned char value : seedHash) {
        mix(value);
    }
    mix(0xFF);
    for (unsigned char value : salt) {
        mix(value);
    }

    static constexpr u32 kSeedHudPalette[] = {
        0xFF5A5F,  // red
        0xFF8F3D,  // orange
        0xF4D35E,  // yellow
        0x5ED06C,  // green
        0x3EC6C2,  // teal
        0x4DD7FF,  // cyan
        0x4B82F0,  // blue
        0xA66BEA,  // purple
        0xE65CC7,  // magenta
        0xFF70B8,  // pink
        0xE9E9E9,  // white
        0xB58A5A,  // warm brown/gold
    };
    const u32 rgb = kSeedHudPalette[hash % (sizeof(kSeedHudPalette) / sizeof(kSeedHudPalette[0]))];
    outColor = JUtility::TColor(
        static_cast<u8>((rgb >> 16) & 0xFF),
        static_cast<u8>((rgb >> 8) & 0xFF),
        static_cast<u8>(rgb & 0xFF),
        255);
    return true;
}

'''
        meter = replace_once(meter, anchor, helper, "deterministic seeded HUD color helper")

    old_sig = "void dApplyHudWindowColor(CPaneMgr* pane, const std::string& colorString) {"
    new_sig = "void dApplyHudWindowColor(CPaneMgr* pane, const std::string& colorString, std::string_view seedSalt) {"
    if new_sig not in meter:
        meter = replace_once(meter, old_sig, new_sig, "seed-aware HUD window color helper signature")

    seeded_window_anchor = "    if (dusk::cosmetics::is_valid_hex_color_str(colorString)) {\n"
    seeded_window_block = r'''    JUtility::TColor seededTint;
    if (dTprSeededHudColor(seedSalt, seededTint)) {
        window->setContentsColor(seededTint);
        return;
    }

    if (dusk::cosmetics::is_valid_hex_color_str(colorString)) {
'''
    if "if (dTprSeededHudColor(seedSalt, seededTint))" not in meter:
        meter = replace_once(
            meter, seeded_window_anchor, seeded_window_block,
            "seed-aware HUD window color application",
        )

    call_replacements = {
        "dApplyHudWindowColor(mpButtonA, tprHud.aButtonColor.getValue());":
            'dApplyHudWindowColor(mpButtonA, tprHud.aButtonColor.getValue(), "button_a");',
        "dApplyHudWindowColor(mpButtonB, tprHud.bButtonColor.getValue());":
            'dApplyHudWindowColor(mpButtonB, tprHud.bButtonColor.getValue(), "button_b");',
        "dApplyHudWindowColor(mpButtonXY[0], tprHud.xButtonColor.getValue());":
            'dApplyHudWindowColor(mpButtonXY[0], tprHud.xButtonColor.getValue(), "button_x");',
        "dApplyHudWindowColor(mpButtonXY[1], tprHud.yButtonColor.getValue());":
            'dApplyHudWindowColor(mpButtonXY[1], tprHud.yButtonColor.getValue(), "button_y");',
        "dApplyHudWindowColor(mpButtonXY[2], tprHud.zButtonColor.getValue());":
            'dApplyHudWindowColor(mpButtonXY[2], tprHud.zButtonColor.getValue(), "button_z");',
    }
    for old_call, new_call in call_replacements.items():
        if new_call not in meter:
            meter = replace_once(meter, old_call, new_call, "seed-aware HUD button color call")

    old_heart = r'''    JUtility::TColor heartVertexColor(255, 255, 255, 255);
    const auto& heartColorStr = dusk::getSettings().cosmetics.heartColor.getValue();
    if (dusk::cosmetics::is_valid_hex_color_str(heartColorStr)) {
        const GXColor color = dusk::cosmetics::hex_color_str_to_gx_color(heartColorStr);
        heartVertexColor = JUtility::TColor(color.r, color.g, color.b, 255);
    }
'''
    new_heart = r'''    JUtility::TColor heartVertexColor(255, 255, 255, 255);
    const auto& heartColorStr = dusk::getSettings().cosmetics.heartColor.getValue();
    if (!dTprSeededHudColor("heart", heartVertexColor) &&
        dusk::cosmetics::is_valid_hex_color_str(heartColorStr)) {
        const GXColor color = dusk::cosmetics::hex_color_str_to_gx_color(heartColorStr);
        heartVertexColor = JUtility::TColor(color.r, color.g, color.b, 255);
    }
'''
    if 'dTprSeededHudColor("heart", heartVertexColor)' not in meter:
        meter = replace_once(meter, old_heart, new_heart, "seed-aware heart color application")

    meter_path.write_text(meter, encoding="utf-8")

def patch_controller_cursor_polish(source: Path) -> None:
    # Add persistent speed/deadzone/acceleration tuning to CP15's cursor mode.
    settings_h_path = source / "src/dusk/settings.h"
    settings_cpp_path = source / "src/dusk/settings.cpp"
    ui_settings_path = source / "src/dusk/ui/settings.cpp"
    input_cpp_path = source / "src/dusk/ui/input.cpp"
    overlay_cpp_path = source / "src/dusk/ui/overlay.cpp"
    overlay_rcss_path = source / "res/rml/overlay.rcss"

    settings_h = settings_h_path.read_text(encoding="utf-8")
    if "ConfigVar<float> controllerCursorSpeed;" not in settings_h:
        settings_h = replace_once(
            settings_h,
            "        ConfigVar<bool> enableMenuPointer;\n",
            "        ConfigVar<bool> enableMenuPointer;\n"
            "        ConfigVar<float> controllerCursorSpeed;\n"
            "        ConfigVar<float> controllerCursorDeadzone;\n"
            "        ConfigVar<bool> controllerCursorAcceleration;\n",
            "controller cursor tuning declarations",
        )
    settings_h_path.write_text(settings_h, encoding="utf-8")

    settings_cpp = settings_cpp_path.read_text(encoding="utf-8")
    if '.controllerCursorSpeed {"game.controllerCursorSpeed", 1.0f}' not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            '        .enableMenuPointer {"game.enableMenuPointer", true},\n',
            '        .enableMenuPointer {"game.enableMenuPointer", true},\n'
            '        .controllerCursorSpeed {"game.controllerCursorSpeed", 1.0f},\n'
            '        .controllerCursorDeadzone {"game.controllerCursorDeadzone", 0.18f},\n'
            '        .controllerCursorAcceleration {"game.controllerCursorAcceleration", true},\n',
            "controller cursor tuning defaults",
        )
    if "Register(g_userSettings.game.controllerCursorSpeed);" not in settings_cpp:
        settings_cpp = replace_once(
            settings_cpp,
            "    Register(g_userSettings.game.enableMenuPointer);\n",
            "    Register(g_userSettings.game.enableMenuPointer);\n"
            "    Register(g_userSettings.game.controllerCursorSpeed);\n"
            "    Register(g_userSettings.game.controllerCursorDeadzone);\n"
            "    Register(g_userSettings.game.controllerCursorAcceleration);\n",
            "controller cursor tuning registrations",
        )
    settings_cpp_path.write_text(settings_cpp, encoding="utf-8")

    ui_settings = ui_settings_path.read_text(encoding="utf-8")
    if '"Controller Cursor Speed"' not in ui_settings:
        anchor = (
            '        config_percent_select(leftPane, rightPane, getSettings().game.mouseCameraSensitivity,\n'
            '            "Mouse Camera Sensitivity", "Controls mouse camera sensitivity.", 25, 400, 5,\n'
            '            [] { return !getSettings().game.enableMouseCamera; });\n'
        )
        addition = r'''#if defined(_UWP)
        leftPane.add_section("Xbox Controller Cursor");
        config_percent_select(leftPane, rightPane, getSettings().game.controllerCursorSpeed,
            "Controller Cursor Speed",
            "Controls right-stick pointer speed while controller cursor mode is active.", 25, 250, 5);
        config_percent_select(leftPane, rightPane, getSettings().game.controllerCursorDeadzone,
            "Controller Cursor Deadzone",
            "Controls how far the right stick must move before the pointer responds.", 0, 50, 1);
        addOption("Controller Cursor Acceleration", getSettings().game.controllerCursorAcceleration,
            "Uses a precision curve near stick center while preserving full-speed movement at the edge.");
#endif
'''
        ui_settings = replace_once(
            ui_settings, anchor, anchor + addition, "controller cursor Settings controls"
        )
    ui_settings_path.write_text(ui_settings, encoding="utf-8")

    input_cpp = input_cpp_path.read_text(encoding="utf-8")
    if '#include "dusk/settings.h"' not in input_cpp:
        input_cpp = replace_once(
            input_cpp,
            '#include "dusk/action_bindings.h"\n',
            '#include "dusk/action_bindings.h"\n#include "dusk/settings.h"\n',
            "controller cursor settings include",
        )

    old_response = r'''float controller_cursor_axis_response(Sint16 raw) noexcept {
    const float normalized = std::clamp(static_cast<float>(raw) / 32767.0f, -1.0f, 1.0f);
    const float magnitude = std::abs(normalized);
    if (magnitude <= kControllerCursorDeadzone) {
        return 0.0f;
    }
    const float scaled = (magnitude - kControllerCursorDeadzone) / (1.0f - kControllerCursorDeadzone);
    // Slightly square the response for precision near center while retaining full-speed travel.
    const float shaped = scaled * scaled;
    return normalized < 0.0f ? -shaped : shaped;
}
'''
    new_response = r'''float controller_cursor_axis_response(Sint16 raw) noexcept {
    const float normalized = std::clamp(static_cast<float>(raw) / 32767.0f, -1.0f, 1.0f);
    const float magnitude = std::abs(normalized);
    const float deadzone = std::clamp(
        dusk::getSettings().game.controllerCursorDeadzone.getValue(), 0.0f, 0.50f);
    if (magnitude <= deadzone) {
        return 0.0f;
    }
    const float denominator = std::max(1.0f - deadzone, 0.001f);
    const float scaled = std::clamp((magnitude - deadzone) / denominator, 0.0f, 1.0f);
    const float shaped = dusk::getSettings().game.controllerCursorAcceleration.getValue()
                             ? scaled * scaled
                             : scaled;
    return normalized < 0.0f ? -shaped : shaped;
}
'''
    if "controllerCursorDeadzone.getValue()" not in input_cpp:
        input_cpp = replace_once(
            input_cpp, old_response, new_response, "controller cursor live deadzone/acceleration"
        )

    old_speed = (
        "    const float dx = controller_cursor_axis_response(sControllerCursorAxisX) * kControllerCursorSpeed * dt;\n"
        "    const float dy = controller_cursor_axis_response(sControllerCursorAxisY) * kControllerCursorSpeed * dt;\n"
    )
    new_speed = (
        "    const float cursorSpeed = kControllerCursorSpeed * std::clamp(\n"
        "        dusk::getSettings().game.controllerCursorSpeed.getValue(), 0.25f, 2.50f);\n"
        "    const float dx = controller_cursor_axis_response(sControllerCursorAxisX) * cursorSpeed * dt;\n"
        "    const float dy = controller_cursor_axis_response(sControllerCursorAxisY) * cursorSpeed * dt;\n"
    )
    if "controllerCursorSpeed.getValue()" not in input_cpp:
        input_cpp = replace_once(input_cpp, old_speed, new_speed, "controller cursor live speed")
    input_cpp_path.write_text(input_cpp, encoding="utf-8")

    overlay_cpp = overlay_cpp_path.read_text(encoding="utf-8")
    overlay_cpp = overlay_cpp.replace(
        "Rml::Property(input::controller_cursor_x() - 10.0f, Rml::Unit::PX)",
        "Rml::Property(input::controller_cursor_x() - 12.0f, Rml::Unit::PX)",
    )
    overlay_cpp = overlay_cpp.replace(
        "Rml::Property(input::controller_cursor_y() - 10.0f, Rml::Unit::PX)",
        "Rml::Property(input::controller_cursor_y() - 12.0f, Rml::Unit::PX)",
    )
    overlay_cpp_path.write_text(overlay_cpp, encoding="utf-8")

    overlay_rcss = overlay_rcss_path.read_text(encoding="utf-8")
    overlay_rcss = overlay_rcss.replace("    width: 20dp;\n    height: 20dp;", "    width: 24dp;\n    height: 24dp;")
    overlay_rcss = overlay_rcss.replace("    border-radius: 10dp;", "    border-radius: 12dp;")
    overlay_rcss = overlay_rcss.replace(
        "    box-shadow: 0 0 6dp 2dp rgba(0, 0, 0, 70%);",
        "    box-shadow: 0 0 8dp 3dp rgba(0, 0, 0, 85%);",
    )
    overlay_rcss_path.write_text(overlay_rcss, encoding="utf-8")


def patch_uwp_user_directories(source: Path) -> None:
    # Automatically create the two user-managed Xbox content roots in LocalState.
    path = source / "src/m_Do/m_Do_main.cpp"
    text = path.read_text(encoding="utf-8")
    marker = "// TPR UWP: ensure Xbox user-content folders exist"
    if marker in text:
        return

    anchor = (
        "    dusk::ConfigPath = dataPaths.userPath;\n"
        "    dusk::CachePath = dataPaths.cachePath;\n"
        "    dusk::InitializeFileLogging(dusk::CachePath, startupLogLevel);\n"
    )
    addition = r'''    dusk::ConfigPath = dataPaths.userPath;
    dusk::CachePath = dataPaths.cachePath;
    dusk::InitializeFileLogging(dusk::CachePath, startupLogLevel);
#if defined(_UWP)
    // TPR UWP: ensure Xbox user-content folders exist. Device Portal can then
    // upload individual mods/textures without replacing application files.
    for (const char* folderName : {"mods", "texture_replacements"}) {
        std::error_code ec;
        std::filesystem::create_directories(dusk::ConfigPath / folderName, ec);
        if (ec) {
            DuskLog.warn("Could not create UWP user folder '{}': {}", folderName, ec.message());
        }
    }
#endif
'''
    text = replace_once(text, anchor, addition, "automatic UWP user-content directories")
    path.write_text(text, encoding="utf-8")

def patch_uwp_wrapper(source: Path) -> None:
    path = source / "platforms/uwp/CMakeLists.txt"
    if not path.exists():
        raise RuntimeError("UWP project was not imported: platforms/uwp/CMakeLists.txt is missing")
    text = path.read_text(encoding="utf-8")

    # Make the executable/project itself distinct too, not only the package identity.
    text = re.sub(r"project\([^\n]+LANGUAGES CXX\)", f"project({TARGET_NAME} LANGUAGES CXX)", text, count=1)

    helper_marker = "# Randomizer/new-core link compatibility"
    if helper_marker not in text:
        anchor = "set(BinLibs\n"
        helper = r'''# Randomizer/new-core link compatibility
# Later randomizer builds add static libraries that the 1.1.1 UWP wrapper predates.
function(tpr_find_built_lib OUT_VAR REGEX_TEXT)
    file(GLOB_RECURSE _tpr_candidates LIST_DIRECTORIES FALSE "${DUSK_DIR}/*.lib")
    list(FILTER _tpr_candidates INCLUDE REGEX "${REGEX_TEXT}")
    list(LENGTH _tpr_candidates _tpr_count)
    if(_tpr_count EQUAL 0)
        message(FATAL_ERROR "Required randomizer UWP feed library not found: ${REGEX_TEXT} under ${DUSK_DIR}")
    endif()
    list(GET _tpr_candidates 0 _tpr_first)
    set(${OUT_VAR} "${_tpr_first}" PARENT_SCOPE)
endfunction()

# Tracy's CMake target exists even when profiling is disabled, but with
# TRACY_ENABLE=OFF the client instrumentation macros compile out and the main
# static archive may not cause TracyClient.lib to be emitted in a target-only
# build. Only require/link the archive when the static feed was explicitly
# configured with Tracy profiling enabled.
set(TPR_TRACY_LIB "")
set(_tpr_tracy_enabled OFF)
if(EXISTS "${DUSK_DIR}/CMakeCache.txt")
    file(STRINGS "${DUSK_DIR}/CMakeCache.txt" _tpr_tracy_lines REGEX "^TRACY_ENABLE:BOOL=")
    foreach(_tpr_tracy_line IN LISTS _tpr_tracy_lines)
        if(_tpr_tracy_line STREQUAL "TRACY_ENABLE:BOOL=ON")
            set(_tpr_tracy_enabled ON)
        endif()
    endforeach()
endif()
if(_tpr_tracy_enabled)
    tpr_find_built_lib(TPR_TRACY_LIB "/TracyClient[^/]*[.]lib$")
else()
    message(STATUS "Randomizer feed has TRACY_ENABLE=OFF; TracyClient.lib is not required for UWP link")
endif()

tpr_find_built_lib(TPR_YAML_CPP_LIB "/yaml-cpp[.]lib$")
tpr_find_built_lib(TPR_BASE64PP_LIB "/base64pp[.]lib$")

'''
        text = replace_once(text, anchor, helper + anchor, "UWP extra-library resolver")

    if "${TPR_TRACY_LIB}" not in text.split("set(BinLibs", 1)[1]:
        target = "\t${DUSK_DIR}/dusklight.lib\t\n"
        replacement = (
            target
            + "\t${TPR_TRACY_LIB}\n"
            + "\t${TPR_YAML_CPP_LIB}\n"
            + "\t${TPR_BASE64PP_LIB}\n"
            + "\tWs2_32.lib\n"
        )
        text = replace_once(text, target, replacement, "randomizer UWP libraries")

    tile_assets = "\tAssets/Wide310x150Logo.scale-200.png\n\tAssets/Square310x310Logo.scale-200.png\n"
    if "Wide310x150Logo.scale-200.png" not in text:
        anchor = "\tAssets/SplashScreen.scale-200.png\n"
        text = replace_once(text, anchor, anchor + tile_assets, "Xbox tile assets")

    path.write_text(text, encoding="utf-8")


def patch_manifest(source: Path) -> None:
    path = source / "platforms/uwp/Package.appxmanifest"
    text = path.read_text(encoding="utf-8-sig")

    substitutions = [
        (r'Name="[^"]+"\s*\n\s*Publisher="[^"]+"\s*\n\s*Version="[^"]+"',
         f'Name="{PACKAGE_NAME}"\n    Publisher="{PUBLISHER}"\n    Version="{PACKAGE_VERSION}"'),
        (r'PhoneProductId="[^"]+"', f'PhoneProductId="{PHONE_PRODUCT_ID}"'),
        (r'<DisplayName>.*?</DisplayName>', f'<DisplayName>{DISPLAY_NAME}</DisplayName>'),
        (r'<PublisherDisplayName>.*?</PublisherDisplayName>', f'<PublisherDisplayName>{PUBLISHER_DISPLAY}</PublisherDisplayName>'),
        (r'DisplayName="[^"]+"', f'DisplayName="{DISPLAY_NAME}"'),
        (r'Description="[^"]+"', f'Description="{DESCRIPTION}"'),
    ]
    for pattern, repl in substitutions:
        text, count = re.subn(pattern, repl, text, count=1, flags=re.S)
        if count != 1:
            raise RuntimeError(f"Could not patch manifest field: {pattern}")

    # Prefer the user's full 16:9 artwork for wide Xbox presentation when supported.
    if "Wide310x150Logo" not in text:
        text = text.replace("<uap:DefaultTile/>", '<uap:DefaultTile Wide310x150Logo="Assets\\Wide310x150Logo.png" Square310x310Logo="Assets\\Square310x310Logo.png"/>', 1)

    path.write_text(text, encoding="utf-8-sig")


def install_branding(source: Path) -> None:
    dest = source / "platforms/uwp/Assets"
    dest.mkdir(parents=True, exist_ok=True)
    required = [
        "LockScreenLogo.scale-200.png",
        "Square44x44Logo.targetsize-24_altform-unplated.png",
        "Square44x44Logo.scale-200.png",
        "Square150x150Logo.scale-200.png",
        "StoreLogo.png",
        "SplashScreen.scale-200.png",
        "Wide310x150Logo.scale-200.png",
        "Square310x310Logo.scale-200.png",
    ]
    for name in required:
        src = BRANDING_ASSETS / name
        if not src.exists():
            raise RuntimeError(f"Branding asset missing from kit: {src}")
        shutil.copy2(src, dest / name)



def assert_preprocessor_balanced(path: Path) -> None:
    stack: list[tuple[int, str]] = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            stack.append((lineno, stripped))
        elif re.match(r"#\s*endif\b", stripped):
            if not stack:
                raise RuntimeError(f"Unexpected #endif in {path} at line {lineno}")
            stack.pop()
    if stack:
        lineno, directive = stack[-1]
        raise RuntimeError(f"Unclosed preprocessor directive in {path} at line {lineno}: {directive}")


def patch_settings_uwp(source: Path) -> None:
    """Normalize the stale UWP settings guard onto the newer randomizer settings layout.

    SternXD's UWP fork added an outer _UWP guard around the updater/Discord settings
    while its older base also had a nearby conditional that no longer exists in the
    pinned randomizer tree. A whole-branch merge can therefore leave one orphan #endif.
    Rebuild only this small region from the merged content, preserving the current
    updater and Discord bodies while making the _UWP guard structurally balanced.
    """
    path = source / "src/dusk/ui/settings.cpp"
    text = path.read_text(encoding="utf-8")
    check_marker = "        config_bool_select(leftPane, rightPane, getSettings().backend.checkForUpdates,"
    advanced_marker = "        config_bool_select(leftPane, rightPane, getSettings().backend.enableAdvancedSettings,"
    check_pos = text.find(check_marker)
    advanced_pos = text.find(advanced_marker, check_pos if check_pos >= 0 else 0)
    if check_pos < 0 or advanced_pos < 0 or advanced_pos <= check_pos:
        raise RuntimeError("Could not locate updater/advanced settings region for UWP normalization")

    # Remove an already-merged outer _UWP opener immediately before the updater block.
    prefix = text[:check_pos]
    prefix_lines = prefix.splitlines(keepends=True)
    scan = len(prefix_lines) - 1
    while scan >= 0 and prefix_lines[scan].strip() == "":
        scan -= 1
    if scan >= 0 and prefix_lines[scan].strip() in {"#ifndef _UWP", "#if !defined(_UWP)"}:
        del prefix_lines[scan]
    prefix = "".join(prefix_lines)

    # Preserve all current randomizer code in the region, but discard only #endifs
    # that are unmatched within the region. Those are stale closers from the old
    # UWP base; nested directives such as DUSK_DISCORD remain intact.
    region = text[check_pos:advanced_pos]
    depth = 0
    cleaned: list[str] = []
    removed_unmatched = 0
    for line in region.splitlines(keepends=True):
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            depth += 1
            cleaned.append(line)
        elif re.match(r"#\s*endif\b", stripped):
            if depth > 0:
                depth -= 1
                cleaned.append(line)
            else:
                removed_unmatched += 1
        else:
            cleaned.append(line)
    if depth != 0:
        raise RuntimeError("Updater/Discord settings region contains an unclosed nested preprocessor guard")

    body = "".join(cleaned).rstrip() + "\n"
    normalized = prefix + "#ifndef _UWP\n" + body + "#endif\n" + text[advanced_pos:]
    path.write_text(normalized, encoding="utf-8")
    assert_preprocessor_balanced(path)
    print(f"Normalized UWP settings preprocessor guard; removed {removed_unmatched} stale #endif line(s)", flush=True)


def patch_aurora_input_uwp(aurora: Path) -> None:
    path = aurora / "lib/input.cpp"
    text = path.read_text(encoding="utf-8")
    marker = "#ifndef AURORA_WINDOWS_STORE\n  AURORA_ASSERT(SDL_Init"
    if marker not in text:
        old = (
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_HAPTIC | SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD | SDL_INIT_SENSOR),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
        )
        new = (
            '#ifndef AURORA_WINDOWS_STORE\n'
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_HAPTIC | SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD | SDL_INIT_SENSOR),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
            '#else\n'
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora UWP SDL initialization")
    path.write_text(text, encoding="utf-8")


def patch_aurora_gpu_uwp(aurora: Path) -> None:
    path = aurora / "lib/webgpu/gpu.cpp"
    text = path.read_text(encoding="utf-8")

    if '#if !defined(AURORA_WINDOWS_STORE)\n#include "../dawn/TracyPlatform.hpp"' not in text:
        old = (
            '#ifdef WEBGPU_DAWN\n'
            '#include "../dawn/TracyPlatform.hpp"\n'
            '#include <dawn/native/DawnNative.h>\n'
            '#endif\n'
        )
        new = (
            '#ifdef WEBGPU_DAWN\n'
            '#if !defined(AURORA_WINDOWS_STORE)\n'
            '#include "../dawn/TracyPlatform.hpp"\n'
            '#include <dawn/native/DawnNative.h>\n'
            '#endif\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora Dawn UWP includes")

    if 'extern "C" __declspec(dllimport) void* uwp_GetWindowReference();' not in text:
        anchor = 'static std::atomic_bool g_vsyncEnabled = true;\n'
        addition = (
            anchor
            + '\n#if defined(AURORA_WINDOWS_STORE)\n'
            + 'extern "C" __declspec(dllimport) void* uwp_GetWindowReference();\n'
            + '#endif\n'
        )
        text = replace_once(text, anchor, addition, "Aurora UWP CoreWindow import")

    if 'wgpu::SurfaceDescriptorFromWindowsCoreWindow surfaceDesc{};' not in text:
        old = (
            '  window::SurfaceLock surfaceLock;\n'
            '  release_surface_locked();\n'
            '  g_surface = create_window_surface(g_instance, window, "Surface");\n'
        )
        new = (
            '  window::SurfaceLock surfaceLock;\n'
            '  release_surface_locked();\n'
            '#if defined(AURORA_WINDOWS_STORE)\n'
            '  wgpu::SurfaceDescriptorFromWindowsCoreWindow surfaceDesc{};\n'
            '  surfaceDesc.sType = wgpu::SType::SurfaceDescriptorFromWindowsCoreWindow;\n'
            '  surfaceDesc.coreWindow = uwp_GetWindowReference();\n'
            '  const wgpu::SurfaceDescriptor surfaceDescriptor{\n'
            '      .nextInChain = reinterpret_cast<const wgpu::ChainedStruct*>(&surfaceDesc),\n'
            '      .label = "Surface",\n'
            '  };\n'
            '  g_surface = g_instance.CreateSurface(&surfaceDescriptor);\n'
            '#else\n'
            '  g_surface = create_window_surface(g_instance, window, "Surface");\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora UWP CoreWindow surface")

    if '#ifdef WEBGPU_DAWN\n#if !defined(AURORA_WINDOWS_STORE)\n    dawn::native::DawnInstanceDescriptor' not in text:
        old = (
            '#ifdef WEBGPU_DAWN\n'
            '    dawn::native::DawnInstanceDescriptor dawnInstanceDescriptor;\n'
            '    dawnInstanceDescriptor.backendValidationLevel = dawn::native::BackendValidationLevel::Disabled;\n'
            '    dawnInstanceDescriptor.SetLoggingCallback(wgpu_log);\n'
            '#ifdef TRACY_ENABLE\n'
            '    dawnInstanceDescriptor.platform = tracy_dawn_platform();\n'
            '#endif\n'
            '    instanceDescriptor.nextInChain = &dawnInstanceDescriptor;\n'
            '#endif\n'
        )
        new = (
            '#ifdef WEBGPU_DAWN\n'
            '#if !defined(AURORA_WINDOWS_STORE)\n'
            '    dawn::native::DawnInstanceDescriptor dawnInstanceDescriptor;\n'
            '    dawnInstanceDescriptor.backendValidationLevel = dawn::native::BackendValidationLevel::Disabled;\n'
            '    dawnInstanceDescriptor.SetLoggingCallback(wgpu_log);\n'
            '#ifdef TRACY_ENABLE\n'
            '    dawnInstanceDescriptor.platform = tracy_dawn_platform();\n'
            '#endif\n'
            '    instanceDescriptor.nextInChain = &dawnInstanceDescriptor;\n'
            '#endif\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora Dawn UWP instance")

    path.write_text(text, encoding="utf-8")


def resolve_aurora_uwp_cherry_pick(aurora: Path) -> None:
    unmerged = [
        line.strip()
        for line in capture(["git", "diff", "--name-only", "--diff-filter=U"], aurora).splitlines()
        if line.strip()
    ]
    expected = {"lib/input.cpp", "lib/webgpu/gpu.cpp"}
    if set(unmerged) != expected:
        run(["git", "status", "--short"], aurora, check=False)
        run(["git", "cherry-pick", "--abort"], aurora, check=False)
        raise RuntimeError(
            "Aurora UWP cherry-pick has unexpected conflicts: "
            + (", ".join(unmerged) if unmerged else "cherry-pick failed without an unmerged path")
        )

    # The pinned UWP commit predates significant input and WebGPU refactors. Keep the
    # newer randomizer Aurora versions of those two files and port only the UWP
    # semantics from SternXD's patch onto their current structure. Every other file
    # in the UWP commit has already applied cleanly at this point.
    run(["git", "checkout", "--ours", "--", "lib/input.cpp", "lib/webgpu/gpu.cpp"], aurora)
    patch_aurora_input_uwp(aurora)
    patch_aurora_gpu_uwp(aurora)
    run(["git", "add", "lib/input.cpp", "lib/webgpu/gpu.cpp"], aurora)

    remaining = capture(["git", "diff", "--name-only", "--diff-filter=U"], aurora)
    if remaining:
        run(["git", "status", "--short"], aurora, check=False)
        run(["git", "cherry-pick", "--abort"], aurora, check=False)
        raise RuntimeError(f"Aurora UWP cherry-pick still has unresolved paths: {remaining}")

    run([
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "cherry-pick", "--continue",
    ], aurora)

def verify_randomizer_storage(source: Path) -> None:
    # Package identity isolates UWP LocalState. The current UI must still route randomizer data
    # through Dusklight's configured data path rather than an immutable install path.
    candidates = [
        source / "src/dusk/ui/rando_config.cpp",
        source / "src/dusk/ui/rando_config.hpp",
        source / "src/dusk/ui/rando_seed_generation.cpp",
    ]
    joined = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in candidates if p.exists())
    if "GetRandomizer" not in joined:
        raise RuntimeError("Randomizer UI storage helpers were not found; refusing unverified UWP port")


def verify_port(source: Path) -> None:
    required = [
        source / "platforms/uwp/CMakeLists.txt",
        source / "platforms/uwp/Package.appxmanifest",
        source / "src/dusk/randomizer/generator/randomizer.cpp",
        source / "src/dusk/ui/rando_config.cpp",
        source / "src/dusk/ui/file_browser.cpp",
    ]
    missing = [str(p.relative_to(source)) for p in required if not p.exists()]
    if missing:
        raise RuntimeError("Missing required port components: " + ", ".join(missing))

    cmake = (source / "CMakeLists.txt").read_text(encoding="utf-8")
    for marker in (
        "DUSK_UWP",
        "add_library(dusklight STATIC",
        "_UWP",
        "src/dusk/ui/file_browser.cpp",
        "src/dusk/ui/file_browser.hpp",
    ):
        if marker not in cmake:
            raise RuntimeError(f"Top-level CMake missing required UWP marker: {marker}")

    wrapper = (source / "platforms/uwp/CMakeLists.txt").read_text(encoding="utf-8")
    for marker in ("TPR_YAML_CPP_LIB", "TPR_BASE64PP_LIB", "TPR_TRACY_LIB", TARGET_NAME, "Wide310x150Logo"):
        if marker not in wrapper:
            raise RuntimeError(f"UWP wrapper missing marker: {marker}")

    manifest = (source / "platforms/uwp/Package.appxmanifest").read_text(encoding="utf-8-sig")
    for marker in (PACKAGE_NAME, DISPLAY_NAME, PUBLISHER, PACKAGE_VERSION, PHONE_PRODUCT_ID):
        if marker not in manifest:
            raise RuntimeError(f"UWP manifest missing custom identity marker: {marker}")

    aurora_input = (source / "extern/aurora/lib/input.cpp").read_text(encoding="utf-8")
    for marker in ("AURORA_WINDOWS_STORE", "SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD"):
        if marker not in aurora_input:
            raise RuntimeError(f"Aurora input missing UWP marker: {marker}")

    aurora_gpu = (source / "extern/aurora/lib/webgpu/gpu.cpp").read_text(encoding="utf-8")
    for marker in ("uwp_GetWindowReference", "SurfaceDescriptorFromWindowsCoreWindow", "AURORA_WINDOWS_STORE"):
        if marker not in aurora_gpu:
            raise RuntimeError(f"Aurora WebGPU missing UWP marker: {marker}")

    io_cpp = (source / "src/dusk/io.cpp").read_text(encoding="utf-8")
    for marker in (
        "std::optional<std::filesystem::path> uwp_local_folder_path()",
        "SDL_GetPrefPath(dusk::OrgName, dusk::AppName)",
        "#if defined(_UWP)",
    ):
        if marker not in io_cpp:
            raise RuntimeError(f"UWP LocalState implementation missing from io.cpp: {marker}")

    file_browser = (source / "src/dusk/ui/file_browser.cpp").read_text(encoding="utf-8")
    for marker in (
        "int file_pane_row_count(Pane* pane)",
        "int file_pane_child_index_containing(Pane* pane, Rml::Element* target)",
        "pane->children()",
    ):
        if marker not in file_browser:
            raise RuntimeError(f"Current-Pane FileBrowser forward-port missing: {marker}")
    for marker in ("->row_count()", "->child_index_containing(", "->focus_last()"):
        if marker in file_browser:
            raise RuntimeError(f"UWP FileBrowser still references removed Pane API: {marker}")

    # CP15 feature certification: persistent heart-color cosmetic and SOH-style
    # controller cursor mode must both survive assembly.
    settings_h = (source / "src/dusk/settings.h").read_text(encoding="utf-8")
    settings_cpp_core = (source / "src/dusk/settings.cpp").read_text(encoding="utf-8")
    cosmetics_cpp = (source / "src/dusk/ui/cosmetics.cpp").read_text(encoding="utf-8")
    meter_cpp = (source / "src/d/d_meter2_draw.cpp").read_text(encoding="utf-8")
    input_hpp = (source / "src/dusk/ui/input.hpp").read_text(encoding="utf-8")
    input_cpp = (source / "src/dusk/ui/input.cpp").read_text(encoding="utf-8")
    overlay_cpp = (source / "src/dusk/ui/overlay.cpp").read_text(encoding="utf-8")
    overlay_rcss = (source / "res/rml/overlay.rcss").read_text(encoding="utf-8")

    for marker in (
        "ConfigVar<std::string> heartColor;",
        'cosmetics.heartColor", ""',
        "Register(g_userSettings.cosmetics.heartColor);",
        '"Heart Color", cosmetics.heartColor',
        "TPR UWP: live HUD heart-color cosmetic",
        "mpLifeTexture[i][1]",
        "tprHeartQuarterTags",
    ):
        if marker not in "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp)):
            raise RuntimeError(f"Heart-color feature marker missing after assembly: {marker}")

    for marker in (
        "kControllerCursorToggleHold = 0.35",
        "SDL_GAMEPAD_BUTTON_LEFT_STICK",
        "SDL_GAMEPAD_BUTTON_RIGHT_STICK",
        "SDL_GAMEPAD_AXIS_RIGHTX",
        "SDL_GAMEPAD_AXIS_RIGHTY",
        "ProcessMouseMove",
        "ProcessMouseButtonDown(0, 0)",
        "ProcessMouseButtonUp(0, 0)",
        "SDL_RumbleGamepad",
        "controller_cursor_active()",
        'controller-cursor id=\"controller-cursor\"',
        "CURSOR MODE ON",
        "controller-cursor[open]",
        "cursor-mode-status[open]",
    ):
        if marker not in "\n".join((input_hpp, input_cpp, overlay_cpp, overlay_rcss)):
            raise RuntimeError(f"Controller-cursor feature marker missing after assembly: {marker}")

    # CP16 feature certification: HUD buttons, tunable controller cursor and
    # automatic Xbox user-content directories must survive assembly.
    ui_settings_cpp = (source / "src/dusk/ui/settings.cpp").read_text(encoding="utf-8")
    main_cpp = (source / "src/m_Do/m_Do_main.cpp").read_text(encoding="utf-8")
    cp16 = "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp,
                       input_cpp, overlay_cpp, overlay_rcss, ui_settings_cpp, main_cpp))
    for marker in (
        "ConfigVar<std::string> aButtonColor;",
        "ConfigVar<std::string> zButtonColor;",
        '"A Button Color", cosmetics.aButtonColor',
        '"Z Button Color", cosmetics.zButtonColor',
        "TPR UWP: typed HUD button-color cosmetics",
        "dApplyHudWindowColor(mpButtonA",
        "dApplyHudWindowColor(mpButtonXY[2]",
        "controllerCursorSpeed",
        "controllerCursorDeadzone",
        "controllerCursorAcceleration",
        '"Controller Cursor Speed"',
        '"Controller Cursor Deadzone"',
        '"Controller Cursor Acceleration"',
        "controllerCursorSpeed.getValue()",
        "controllerCursorDeadzone.getValue()",
        "controllerCursorAcceleration.getValue()",
        "TPR UWP: ensure Xbox user-content folders exist",
        '"mods", "texture_replacements"',
        "std::filesystem::create_directories(dusk::ConfigPath / folderName",
    ):
        if marker not in cp16:
            raise RuntimeError(f"CP16 feature marker missing after assembly: {marker}")

    cp17 = "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp))
    for marker in (
        "ConfigVar<bool> randomizeHudColorsWithSeed;",
        'cosmetics.randomizeHudColorsWithSeed", false',
        "Register(g_userSettings.cosmetics.randomizeHudColorsWithSeed);",
        'Randomize Cosmetics With Seed',
        "TPR UWP: deterministic per-seed HUD cosmetics",
        "dTprSeededHudColor",
        'dTprSeededHudColor("heart", heartVertexColor)',
        '"button_a"',
        '"button_z"',
        "randomizer_GetContext().mHash",
    ):
        if marker not in cp17:
            raise RuntimeError(f"CP17 seeded-cosmetic marker missing after assembly: {marker}")

    settings_path = source / "src/dusk/ui/settings.cpp"
    settings = settings_path.read_text(encoding="utf-8")
    if "#ifndef _UWP\n        config_bool_select(leftPane, rightPane, getSettings().backend.checkForUpdates," not in settings:
        raise RuntimeError("Settings updater block is not guarded for UWP")
    assert_preprocessor_balanced(settings_path)

    verify_randomizer_storage(source)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("work/TwilightPrincessRandomizer"))
    args = parser.parse_args()
    out = args.output.resolve()
    if out.exists():
        shutil.rmtree(out)
    out.parent.mkdir(parents=True, exist_ok=True)

    run(["git", "clone", "--no-checkout", RANDO_REPO, str(out)])
    run(["git", "checkout", "--detach", RANDO_SHA], out)
    run(["git", "submodule", "update", "--init", "--recursive"], out)
    if capture(["git", "rev-parse", "HEAD"], out) != RANDO_SHA:
        raise RuntimeError("Randomizer pin mismatch")

    run(["git", "remote", "add", "dusklight-uwp", UWP_REPO], out)
    run(["git", "fetch", "--no-tags", "dusklight-uwp", UWP_SHA], out)
    merge_cmd = [
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "merge", "--no-ff", "--no-edit", "-X", "ours", UWP_SHA,
    ]
    merge_result = run(merge_cmd, out, check=False)
    if merge_result.returncode != 0:
        # Git cannot automatically resolve non-trivial submodule gitlink merges, even
        # with -X ours. At the pinned revisions the only expected unresolved path is
        # extern/aurora. Keep the randomizer's newer Aurora base here; the dedicated
        # SternXD UWP Aurora patch is applied immediately afterward inside the
        # submodule. Any other conflict remains a hard failure.
        unmerged = [
            line.strip()
            for line in capture(["git", "diff", "--name-only", "--diff-filter=U"], out).splitlines()
            if line.strip()
        ]
        if set(unmerged) != {"extern/aurora"}:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(
                "UWP reference merge has unexpected conflicts: "
                + (", ".join(unmerged) if unmerged else "merge failed without an unmerged path")
            )

        ours_aurora = capture(["git", "rev-parse", ":2:extern/aurora"], out)
        if ours_aurora != EXPECTED_AURORA_BASE:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(
                f"Unexpected randomizer Aurora side during UWP merge: {ours_aurora}; "
                f"expected {EXPECTED_AURORA_BASE}"
            )

        print(
            "Resolving expected extern/aurora gitlink conflict by keeping the "
            f"randomizer Aurora base {ours_aurora}",
            flush=True,
        )
        run(["git", "-C", "extern/aurora", "checkout", "--detach", ours_aurora], out)
        run(["git", "add", "extern/aurora"], out)

        remaining = capture(["git", "diff", "--name-only", "--diff-filter=U"], out)
        if remaining:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(f"UWP reference merge still has unresolved paths: {remaining}")

        run([
            "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
            "commit", "--no-edit",
        ], out)

    aurora = out / "extern/aurora"
    run(["git", "fetch", "origin"], aurora)
    run(["git", "checkout", "--detach", EXPECTED_AURORA_BASE], aurora)
    run(["git", "remote", "add", "stern-uwp", AURORA_UWP_REPO], aurora)
    run(["git", "fetch", "--no-tags", "stern-uwp", AURORA_UWP_SHA], aurora)
    try:
        run([
            "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
            "cherry-pick", AURORA_UWP_SHA,
        ], aurora)
    except subprocess.CalledProcessError:
        run(["git", "status", "--short"], aurora, check=False)
        resolve_aurora_uwp_cherry_pick(aurora)
    run(["git", "add", "extern/aurora"], out)

    ensure_main_uwp_cmake(out)
    ensure_main_cpp_uwp(out)
    patch_io_uwp_local_folder(out)
    patch_settings_uwp(out)
    patch_file_browser_current_pane(out)
    patch_heart_color_cosmetic(out)
    patch_controller_cursor_mode(out)
    patch_hud_color_cosmetics(out)
    patch_seeded_hud_cosmetics(out)
    patch_controller_cursor_polish(out)
    patch_uwp_user_directories(out)
    patch_uwp_wrapper(out)
    patch_manifest(out)
    install_branding(out)
    verify_port(out)

    run(["git", "add", "-A"], out)
    run([
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "commit", "-m", "Create standalone Twilight Princess Randomizer UWP app",
    ], out)

    print("\nStandalone UWP source assembled successfully:", out)
    print("HEAD:", capture(["git", "rev-parse", "HEAD"], out))
    print("Aurora:", capture(["git", "rev-parse", "HEAD"], aurora))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
