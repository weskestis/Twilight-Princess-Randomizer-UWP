#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_ORIGINAL_SHA256 = "521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff"
EXPECTED_ASSETS = {
    "LockScreenLogo.scale-200.png": (48, 48),
    "Square44x44Logo.targetsize-24_altform-unplated.png": (24, 24),
    "Square44x44Logo.scale-200.png": (88, 88),
    "Square150x150Logo.scale-200.png": (300, 300),
    "StoreLogo.png": (50, 50),
    "SplashScreen.scale-200.png": (1240, 600),
    "Wide310x150Logo.scale-200.png": (620, 300),
    "Square310x310Logo.scale-200.png": (620, 620),
}
APPX_MAX_TILE_BYTES = {
    "Wide310x150Logo.scale-200.png": 204800,
    "Square310x310Logo.scale-200.png": 204800,
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()[:24]
    if len(data) != 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise SystemExit(f"Not a valid PNG: {path}")
    return struct.unpack(">II", data[16:24])


def assert_preprocessor_balanced(path: Path) -> None:
    stack: list[tuple[int, str]] = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            stack.append((lineno, stripped))
        elif re.match(r"#\s*endif\b", stripped):
            if not stack:
                raise SystemExit(f"Unexpected #endif in {path} at line {lineno}")
            stack.pop()
    if stack:
        lineno, directive = stack[-1]
        raise SystemExit(f"Unclosed preprocessor directive in {path} at line {lineno}: {directive}")


def verify_kit() -> None:
    identity = json.loads((ROOT / "APP_IDENTITY.json").read_text(encoding="utf-8"))
    expected = {
        "package_identity": "TwilightPrincessRandomizer",
        "display_name": "Twilight Princess Randomizer",
        "publisher": "CN=TwilightPrincessRandomizer",
        "version": "1.4.1.627",
        "randomizer_commit": "07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e",
        "uwp_commit": "48d193dfebe4b20b4984af1d27d0e99f6b6722a7",
    }
    for key, value in expected.items():
        if identity.get(key) != value:
            raise SystemExit(f"APP_IDENTITY.json mismatch: {key}={identity.get(key)!r}, expected {value!r}")

    original = ROOT / "branding" / "Twilight-Princess-Randomizer-original.jpg"
    if sha256(original) != EXPECTED_ORIGINAL_SHA256:
        raise SystemExit("Original uploaded branding image hash changed")

    for name, dims in EXPECTED_ASSETS.items():
        p = ROOT / "branding" / "Assets" / name
        if not p.exists():
            raise SystemExit(f"Missing branding asset: {name}")
        if png_size(p) != dims:
            raise SystemExit(f"Wrong asset dimensions for {name}: {png_size(p)} != {dims}")
        max_bytes = APPX_MAX_TILE_BYTES.get(name)
        if max_bytes is not None and p.stat().st_size > max_bytes:
            raise SystemExit(
                f"AppX tile asset too large: {name} is {p.stat().st_size} bytes, max {max_bytes}"
            )

    assembler = (ROOT / "scripts" / "assemble_port.py").read_text(encoding="utf-8")
    for marker in (
        'PACKAGE_NAME = "TwilightPrincessRandomizer"',
        'DISPLAY_NAME = "Twilight Princess Randomizer"',
        'TARGET_NAME = "TwilightPrincessRandomizer"',
        'TPR_YAML_CPP_LIB',
        'TPR_BASE64PP_LIB',
        'TPR_TRACY_LIB',
        'TRACY_ENABLE:BOOL=ON',
        'TracyClient.lib is not required for UWP link',
        'UWP file browser source list',
        'Wide310x150Logo.scale-200.png',
        'Square310x310Logo.scale-200.png',
        'set(unmerged) != {"extern/aurora"}',
        'git", "rev-parse", ":2:extern/aurora"',
        'expected = {"lib/input.cpp", "lib/webgpu/gpu.cpp"}',
        'patch_aurora_input_uwp(aurora)',
        'patch_aurora_gpu_uwp(aurora)',
        'guarded_install = "if (NOT DUSK_UWP)\\n    " + install_call',
        'patch_io_uwp_local_folder(out)',
        'SDL_GetPrefPath(dusk::OrgName, dusk::AppName)',
        'patch_settings_uwp(out)',
        'patch_heart_color_cosmetic(out)',
        'patch_controller_cursor_mode(out)',
        'patch_hud_color_cosmetics(out)',
        'patch_seeded_hud_cosmetics(out)',
        'patch_controller_cursor_polish(out)',
        'patch_uwp_user_directories(out)',
        'kControllerCursorToggleHold = 0.35',
        'TPR UWP: live HUD heart-color cosmetic',
        'TPR UWP: typed HUD button-color cosmetics',
        'Controller Cursor Speed',
        'texture_replacements',
        'assert_preprocessor_balanced(settings_path)',
    ):
        if marker not in assembler:
            raise SystemExit(f"Assembler missing marker: {marker}")


def verify_assembled(root: Path) -> None:
    required = [
        "platforms/uwp/CMakeLists.txt",
        "platforms/uwp/Package.appxmanifest",
        "src/dusk/randomizer/generator/randomizer.cpp",
        "src/dusk/ui/rando_config.cpp",
        "src/dusk/ui/file_browser.cpp",
    ]
    missing = [p for p in required if not (root / p).exists()]
    if missing:
        raise SystemExit("Assembled source missing: " + ", ".join(missing))

    manifest = (root / "platforms/uwp/Package.appxmanifest").read_text(encoding="utf-8-sig")
    for marker in (
        'Name="TwilightPrincessRandomizer"',
        'Publisher="CN=TwilightPrincessRandomizer"',
        'Version="1.4.1.627"',
        'Twilight Princess Randomizer',
        'Wide310x150Logo',
    ):
        if marker not in manifest:
            raise SystemExit(f"Manifest missing: {marker}")

    cmake = (root / "CMakeLists.txt").read_text(encoding="utf-8")
    for marker in (
        "DUSK_UWP",
        "add_library(dusklight STATIC",
        "_UWP",
        "src/dusk/ui/file_browser.cpp",
        "src/dusk/ui/file_browser.hpp",
    ):
        if marker not in cmake:
            raise SystemExit(f"Top-level CMake missing: {marker}")
    runtime_install_guard = (
        "if (NOT DUSK_UWP)\n"
        "    aurora_install_runtime_dlls(dusklight ${CMAKE_INSTALL_PREFIX})\n"
        "endif ()"
    )
    if runtime_install_guard not in cmake:
        raise SystemExit("Top-level CMake leaves Aurora runtime install unguarded for UWP")

    wrapper = (root / "platforms/uwp/CMakeLists.txt").read_text(encoding="utf-8")
    for marker in ("project(TwilightPrincessRandomizer", "TPR_YAML_CPP_LIB", "TPR_BASE64PP_LIB", "TPR_TRACY_LIB", "TRACY_ENABLE:BOOL=ON"):
        if marker not in wrapper:
            raise SystemExit(f"UWP wrapper missing: {marker}")

    aurora_input = (root / "extern/aurora/lib/input.cpp").read_text(encoding="utf-8")
    for marker in ("AURORA_WINDOWS_STORE", "SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD"):
        if marker not in aurora_input:
            raise SystemExit(f"Assembled Aurora input missing UWP marker: {marker}")

    aurora_gpu = (root / "extern/aurora/lib/webgpu/gpu.cpp").read_text(encoding="utf-8")
    for marker in ("uwp_GetWindowReference", "SurfaceDescriptorFromWindowsCoreWindow", "AURORA_WINDOWS_STORE"):
        if marker not in aurora_gpu:
            raise SystemExit(f"Assembled Aurora WebGPU missing UWP marker: {marker}")

    io_cpp = (root / "src/dusk/io.cpp").read_text(encoding="utf-8")
    for marker in (
        "std::optional<std::filesystem::path> uwp_local_folder_path()",
        "SDL_GetPrefPath(dusk::OrgName, dusk::AppName)",
    ):
        if marker not in io_cpp:
            raise SystemExit(f"Assembled UWP LocalState helper missing: {marker}")

    settings_h = (root / "src/dusk/settings.h").read_text(encoding="utf-8")
    settings_cpp_core = (root / "src/dusk/settings.cpp").read_text(encoding="utf-8")
    cosmetics_cpp = (root / "src/dusk/ui/cosmetics.cpp").read_text(encoding="utf-8")
    meter_cpp = (root / "src/d/d_meter2_draw.cpp").read_text(encoding="utf-8")
    input_hpp = (root / "src/dusk/ui/input.hpp").read_text(encoding="utf-8")
    input_cpp = (root / "src/dusk/ui/input.cpp").read_text(encoding="utf-8")
    overlay_cpp = (root / "src/dusk/ui/overlay.cpp").read_text(encoding="utf-8")
    overlay_rcss = (root / "res/rml/overlay.rcss").read_text(encoding="utf-8")

    cp15_heart = "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp))
    for marker in (
        "ConfigVar<std::string> heartColor;",
        'cosmetics.heartColor", ""',
        "Register(g_userSettings.cosmetics.heartColor);",
        '"Heart Color", cosmetics.heartColor',
        "TPR UWP: live HUD heart-color cosmetic",
        "mpLifeTexture[i][1]",
        "tprHeartQuarterTags",
    ):
        if marker not in cp15_heart:
            raise SystemExit(f"Assembled CP15 heart-color feature missing: {marker}")

    cp15_cursor = "\n".join((input_hpp, input_cpp, overlay_cpp, overlay_rcss))
    for marker in (
        "kControllerCursorToggleHold = 0.35",
        "SDL_GAMEPAD_BUTTON_LEFT_STICK",
        "SDL_GAMEPAD_BUTTON_RIGHT_STICK",
        "SDL_GAMEPAD_AXIS_RIGHTX",
        "SDL_GAMEPAD_AXIS_RIGHTY",
        "ProcessMouseMove",
        "ProcessMouseButtonDown(0, 0)",
        "ProcessMouseButtonUp(0, 0)",
        "SDL_RumbleGamepad",
        "controller_cursor_active()",
        'controller-cursor id=\"controller-cursor\"',
        "CURSOR MODE ON",
        "controller-cursor[open]",
        "cursor-mode-status[open]",
    ):
        if marker not in cp15_cursor:
            raise SystemExit(f"Assembled CP15 controller-cursor feature missing: {marker}")

    ui_settings_cpp = (root / "src/dusk/ui/settings.cpp").read_text(encoding="utf-8")
    main_cpp = (root / "src/m_Do/m_Do_main.cpp").read_text(encoding="utf-8")
    cp16 = "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp, input_cpp,
                       overlay_cpp, overlay_rcss, ui_settings_cpp, main_cpp))
    for marker in (
        "ConfigVar<std::string> aButtonColor;",
        "ConfigVar<std::string> zButtonColor;",
        '"A Button Color", cosmetics.aButtonColor',
        '"B Button Color", cosmetics.bButtonColor',
        '"X Button Color", cosmetics.xButtonColor',
        '"Y Button Color", cosmetics.yButtonColor',
        '"Z Button Color", cosmetics.zButtonColor',
        "TPR UWP: typed HUD button-color cosmetics",
        "dApplyHudWindowColor(mpButtonA",
        "dApplyHudWindowColor(mpButtonXY[2]",
        "controllerCursorSpeed",
        "controllerCursorDeadzone",
        "controllerCursorAcceleration",
        '"Controller Cursor Speed"',
        '"Controller Cursor Deadzone"',
        '"Controller Cursor Acceleration"',
        "controllerCursorSpeed.getValue()",
        "controllerCursorDeadzone.getValue()",
        "controllerCursorAcceleration.getValue()",
        "TPR UWP: ensure Xbox user-content folders exist",
        '"mods", "texture_replacements"',
        "std::filesystem::create_directories(dusk::ConfigPath / folderName",
    ):
        if marker not in cp16:
            raise SystemExit(f"Assembled CP16 feature missing: {marker}")

    cp17 = "\n".join((settings_h, settings_cpp_core, cosmetics_cpp, meter_cpp))
    for marker in (
        "ConfigVar<bool> randomizeHudColorsWithSeed;",
        'cosmetics.randomizeHudColorsWithSeed", false',
        "Register(g_userSettings.cosmetics.randomizeHudColorsWithSeed);",
        'Randomize Cosmetics With Seed',
        "TPR UWP: deterministic per-seed HUD cosmetics",
        "dTprSeededHudColor",
        'dTprSeededHudColor("heart", heartVertexColor)',
        '"button_a"',
        '"button_z"',
        "randomizer_GetContext().mHash",
    ):
        if marker not in cp17:
            raise SystemExit(f"Assembled CP17 seeded-cosmetic feature missing: {marker}")

    settings_path = root / "src/dusk/ui/settings.cpp"
    settings = settings_path.read_text(encoding="utf-8")
    guard = "#ifndef _UWP\n        config_bool_select(leftPane, rightPane, getSettings().backend.checkForUpdates,"
    if guard not in settings:
        raise SystemExit("Assembled settings updater block is not guarded for UWP")
    assert_preprocessor_balanced(settings_path)

    for name, dims in EXPECTED_ASSETS.items():
        p = root / "platforms/uwp/Assets" / name
        if not p.exists() or png_size(p) != dims:
            raise SystemExit(f"Assembled branding asset invalid: {name}")
        max_bytes = APPX_MAX_TILE_BYTES.get(name)
        if max_bytes is not None and p.stat().st_size > max_bytes:
            raise SystemExit(
                f"Assembled AppX tile asset too large: {name} is {p.stat().st_size} bytes, max {max_bytes}"
            )


if __name__ == "__main__":
    verify_kit()
    if len(sys.argv) > 1:
        candidate = Path(sys.argv[1]).resolve()
        # The checkpoint kit itself is not an assembled Dusklight source tree.
        # This guard makes the verifier tolerant of workflows that pass TPR_KIT
        # while still validating a real assembled source path when supplied.
        if candidate != ROOT.resolve():
            verify_assembled(candidate)
    print("Twilight Princess Randomizer UWP static checks passed.")
