# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 17

Continue **Twilight Princess Randomizer UWP** from **Checkpoint 17**.

Source of truth: `Twilight-Princess-Randomizer-UWP-Checkpoint-17.zip` plus its SHA-256 sidecar.

Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`

Do not restart from the old UWP fork or an older checkpoint.

## Proven baseline

Checkpoint 14 built, signed, packaged, installed and launched successfully on physical Xbox Dev Mode hardware. The user reported the randomizer build working as intended.

## CP15–CP17 feature line

### HUD colors

`Cosmetics → HUD Colors` now includes:

- Heart Color
- A Button Color
- B Button Color
- X Button Color
- Y Button Color
- Z Button Color

Each uses persistent Default/preset/custom-hex/Random Color behavior. Button color overrides use typed `J2DWindow` contents colors and cache vanilla colors for live Default restoration.

### Seeded HUD cosmetics

`Cosmetics → HUD Colors → Randomize Cosmetics With Seed` is optional and defaults Off. When enabled during randomizer play, Heart and A/B/X/Y/Z HUD colors are deterministically derived from the active seed hash. Same seed = same colors. Manual HUD colors are retained and return when the toggle is disabled.

### Controller cursor

- hold L3+R3 ~0.35 s to toggle while Dusklight UI is visible
- right stick moves pointer
- A clicks
- hold A + move right stick drags
- same chord toggles off
- rumble + large ON/OFF confirmation
- automatically disengages when no Dusklight UI document remains

CP16 adds Settings controls:

- Controller Cursor Speed: 25–250%, default 100%
- Controller Cursor Deadzone: 0–50%, default 18%
- Controller Cursor Acceleration: On by default

### Xbox folders

UWP startup now creates, if absent:

`LocalState\\TwilitRealm\\Dusklight\\mods\\`

`LocalState\\TwilitRealm\\Dusklight\\texture_replacements\\`

Existing files are never deleted or replaced by this setup step.

## Constraint

Do not add duplicate performance presets or extra graphics/FPS/resolution performance toggles. Dusklight already has enough performance controls.

## Workflow

Keep the existing successful Xbox signing/build workflow. It selects the highest numbered checkpoint. No CP17 workflow edit is required.

## Next action

Run CP17 through GitHub Actions. If compilation fails, use the exact first compiler/linker diagnostic and change only the relevant CP17 seeded-cosmetic source patch. If it passes, validate seeded HUD colors, cursor tuning and automatic folders on physical Xbox hardware.
