# Project state — Checkpoint 17

Goal: a side-by-side Xbox/UWP application named **Twilight Princess Randomizer** with the full Dusklight randomizer UI and controller-first Xbox usability.

## Pinned upstreams

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Proven Xbox baseline

Checkpoint 14 plus the corrected signing workflow completed GitHub Actions, produced a signed MSIX, installed through Xbox Device Portal, loaded the user's Twilight Princess image from LocalState, and was reported working as intended on physical Xbox Dev Mode hardware.

Established user-data root:

`LocalState\\TwilitRealm\\Dusklight\\`

## CP15 carried forward

- `Cosmetics → HUD Colors → Heart Color` with Default, presets, custom hex and Random Color.
- Full and partial/big-heart states recolor.
- Controller cursor mode: hold **L3 + R3 ~0.35 s**, right stick moves, **A** clicks/holds for drag, same chord toggles off, rumble + large ON/OFF feedback, UI-only automatic disengage.

## Checkpoint 16 additions

### Expanded HUD colors

The existing **HUD Colors** tab now also contains:

- A Button Color
- B Button Color
- X Button Color
- Y Button Color
- Z Button Color

All are persistent and use the same Default/preset/custom-hex/Random Color UI as other Dusklight cosmetics. The implementation uses typed `J2DWindow` APIs. Exact vanilla four-corner colors are cached before the first override so selecting Default restores the original appearance live.

### Controller cursor polish

New Xbox-only controls are added to Settings:

- **Controller Cursor Speed** — 25–250%, default 100%
- **Controller Cursor Deadzone** — 0–50%, default 18%
- **Controller Cursor Acceleration** — default On

The right-stick pointer reads these values live. Acceleration On uses the CP15 precision curve near stick center; Off uses linear response. The cursor is slightly larger with a stronger high-contrast shadow for TV visibility. Activation/click/drag controls are unchanged.

### Automatic Xbox content folders

On UWP startup, after the writable LocalState user path and logging are initialized, the application creates these folders if missing:

- `mods`
- `texture_replacements`

This makes Device Portal mod/texture uploads unambiguous and does not replace or delete existing contents.

## Checkpoint 17 addition — seeded HUD cosmetics

`Cosmetics → HUD Colors` now begins with **Randomize Cosmetics With Seed** (default Off).

When enabled and a randomizer seed is active:

- Heart + A/B/X/Y/Z HUD colors are derived deterministically from the loaded seed hash.
- The same seed always produces the same HUD colors.
- Different seeds normally produce different HUD color combinations.
- Manual HUD color settings are **not overwritten**; they resume immediately when the toggle is turned Off.
- Normal/non-randomizer play continues to use the manual HUD colors.

The deterministic palette intentionally avoids near-black colors so the HUD remains readable on a TV.

## Explicit exclusions

- No new performance presets.
- No new graphics/FPS/resolution performance toggles.
- No source-pin, package-identity, package-version or workflow-contract change.

## Verification state

Local checkpoint verification covers Python syntax, kit-mode static checks, deterministic CP16/CP17 feature markers, and patch idempotence. Actual Windows/MSVC/UWP compile and physical-Xbox runtime validation remain the next gate.
