# GitHub Actions build status — Checkpoint 17

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Proven baseline

Checkpoint 14 remains the last fully certified Xbox package baseline:

- static feed compiled
- UWP executable linked
- MSIX package generated and signed
- artifact uploaded
- installed through Xbox Device Portal
- launched on physical Xbox Dev Mode hardware
- game image loaded from LocalState
- user reported runtime working as intended

## CP16/CP17 delta over the proven baseline

Checkpoint 16 carries forward CP15 and adds:

1. Heart + A/B/X/Y/Z HUD color customization.
2. Persistent controller cursor Speed / Deadzone / Acceleration controls.
3. Improved controller cursor TV visibility.
4. Automatic creation of `mods` and `texture_replacements` under the UWP user-data root.
5. Optional deterministic per-seed Heart + A/B/X/Y/Z HUD colors via **Randomize Cosmetics With Seed**.

No performance presets/toggles were added.

## Local pre-CI validation

- `assemble_port.py`: Python compile PASS
- `verify_static.py`: Python compile PASS
- checkpoint-kit `verify_static.py`: PASS
- CP16 feature-patch fixture: PASS
- CP17 seeded-HUD marker verification: PASS
- patch idempotence: PASS
- assembled-tree marker verification expanded through CP17

## Next gate

Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-17.zip` to the repository root. The existing successful workflow should select it as the highest checkpoint.

Desired Xbox certification:

- compile/link/package PASS
- Heart + A/B/X/Y/Z colors visible and persistent
- enabling Randomize Cosmetics With Seed makes the same seed reproduce the same HUD colors
- different seeds produce deterministic different combinations without overwriting manual choices
- Default restores vanilla HUD colors
- cursor Speed / Deadzone / Acceleration controls persist and affect movement
- L3+R3 activation, A click and A-drag remain correct
- `mods` and `texture_replacements` appear automatically in LocalState
- normal gameplay controls remain unchanged while cursor mode is off
