# Checkpoint 17 update

Checkpoint 14 is the proven Xbox Dev Mode baseline. Checkpoint 17 carries forward CP16 and adds optional deterministic per-seed HUD cosmetics without adding redundant performance presets.

## New in CP17

### Randomize Cosmetics With Seed

At the top of `Cosmetics → HUD Colors`, enable **Randomize Cosmetics With Seed** to make Heart and A/B/X/Y/Z colors deterministic from the active randomizer seed. The same seed always reproduces the same HUD colors. Manual HUD selections are preserved and return immediately when the toggle is disabled.

## Carried forward from CP16

### HUD colors

Under `Cosmetics → HUD Colors`:

- Heart Color
- A Button Color
- B Button Color
- X Button Color
- Y Button Color
- Z Button Color

All support Default, presets, custom six-digit hex and Random Color. Button colors restore their exact cached vanilla values when Default is selected.

### Controller cursor tuning

Open Settings and use the Xbox Controller Cursor controls:

- Speed: 25–250%
- Deadzone: 0–50%
- Acceleration: On/Off

Cursor activation remains:

1. Open a Dusklight UI screen.
2. Hold **L3 + R3** for about **0.35 seconds**.
3. Move with the **right stick**.
4. Press **A** to click; hold **A** and move to drag.
5. Hold **L3 + R3** again to disable.

### Automatic content folders

The UWP build creates `mods` and `texture_replacements` inside its LocalState user-data root when missing, making Xbox Device Portal uploads easier.

# Twilight Princess Randomizer — Xbox/UWP

- Display name: **Twilight Princess Randomizer**
- Package identity: `TwilightPrincessRandomizer`
- Publisher: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
