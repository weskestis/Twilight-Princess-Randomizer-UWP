# Source manifest — Checkpoint 17

## Pinned public sources

- `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Twilight Princess Randomizer cosmetic semantics reference

The HUD cosmetic work also references the public original randomizer implementation:

- `zsrtp/Randomizer@e62760fdc470d07f7a56bd9e87ab911b05c4691a`
- `GameCube/source/user_patch/03_customCosmetics.cpp`

That implementation establishes heart and A/B/X/Y/Z HUD recoloring as randomizer cosmetic features. CP15–CP17 implement the behavior against the Dusklight/decomp types instead of copying raw GameCube memory-offset writes.

## User-provided source/artwork

- Uploaded Twilight Princess artwork retained as `branding/Twilight-Princess-Randomizer-original.jpg`.
- UWP assets are deterministic derivatives and retain the AppX size limits certified in CP14.

## Project-authored integration

- `scripts/assemble_port.py` — deterministic pinned-source UWP assembler/forward-porter.
- CP16 additions in assembler: HUD button colors, cursor tuning, automatic Xbox folders.
- CP17 addition in assembler: optional deterministic per-seed Heart + A/B/X/Y/Z HUD colors that preserve manual selections.
- `scripts/verify_static.py` — kit and assembled-tree static validation including CP16/CP17 markers.
- `github-manual/build-xbox.yml` — successful Xbox workflow baseline retained unchanged.
- `APP_IDENTITY.json` — package identity contract unchanged.

No upstream pin, package identity, package version or workflow contract changed in Checkpoint 17.
