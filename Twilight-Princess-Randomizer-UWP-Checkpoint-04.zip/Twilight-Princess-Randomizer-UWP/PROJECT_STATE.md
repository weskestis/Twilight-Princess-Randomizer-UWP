# Project state — Checkpoint 04

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Existing Dusk/Dusklight identities are not reused, preserving separate Xbox/Windows LocalState.

## Completed

- Fresh package identity/display name and exact user-supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- Randomizer-era UWP link dependencies: TracyClient, yaml-cpp, base64pp.
- UWP static-library mode and entry-point compatibility patches.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Windows runner, MSVC setup, Ninja, freetype and zstd dependency setup proven working in GitHub Actions.
- Checkpoint 02 pre-assembly verifier bug fixed.
- Checkpoint 03 superproject `extern/aurora` gitlink conflict fixed without downgrading Aurora.
- Run 3 proved the assembler reaches the dedicated Aurora UWP patch.
- Checkpoint 04 now forward-ports the only two observed Aurora content conflicts (`lib/input.cpp`, `lib/webgpu/gpu.cpp`) onto the newer randomizer Aurora structures rather than replacing them with older files.

## Run 3 result

The dedicated Aurora UWP cherry-pick applied all non-conflicting UWP changes but stopped on exactly:

- `lib/input.cpp`
- `lib/webgpu/gpu.cpp`

No CMake or compiler failure has occurred yet.

## Local validation for Checkpoint 04

- Kit static verifier passes.
- Python source compiles.
- UWP input/WebGPU forward-port transforms are idempotent.
- Synthetic exact-two-conflict cherry-pick test passes end-to-end.

## Not yet certified

The project has not yet passed:

- full pinned source assembly on the Windows runner;
- assembled-source verification;
- CMake configure;
- static-feed compilation;
- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Upload Checkpoint 04 to the repository root and rerun the existing Checkpoint 03 workflow. Because that workflow selects the numerically highest checkpoint, **no YAML change is needed**. Use the next exact failed step/log as the source of truth.
