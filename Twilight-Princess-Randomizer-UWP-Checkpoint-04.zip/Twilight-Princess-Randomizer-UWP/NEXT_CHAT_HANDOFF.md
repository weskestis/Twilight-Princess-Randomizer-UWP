# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 04

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 04**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-04.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Goal

Produce a real Xbox Dev Mode installable **separate app**:

- Display name: **Twilight Princess Randomizer**
- Package identity: `TwilightPrincessRandomizer`
- Must install alongside existing Dusklight UWP and keep separate LocalState.
- Preserve the user's exact supplied Twilight Princess HD artwork.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Run 3 passed the Checkpoint 03 superproject `extern/aurora` gitlink fix and reached the dedicated SternXD Aurora UWP cherry-pick.

The cherry-pick applied its other UWP changes but conflicted exactly in:

- `lib/input.cpp`
- `lib/webgpu/gpu.cpp`

These files have newer randomizer-era logic and must not be replaced wholesale by the old UWP versions.

Checkpoint 04 resolves only those exact conflicts by retaining the newer files and forward-porting the UWP semantics into them. Any other conflict remains fatal. Static verification now checks the resulting Aurora UWP markers.

## Manual GitHub workflow

Keep the existing Checkpoint 03 `.github/workflows/build-xbox.yml`. It already selects the numerically highest `Checkpoint-XX.zip`.

Therefore the immediate action is only:

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-04.zip` to repository root.
2. Run `Xbox UWP x64` again.
3. Inspect the next exact failure or successful artifact.

Old checkpoint ZIPs may remain; Checkpoint 04 will be selected automatically.

## Remaining gates

1. Full source assembly
2. Assembled-source verification
3. Randomizer static-feed CMake configure
4. Static-feed compile
5. UWP wrapper configure
6. Certificate creation
7. UWP link/package
8. Artifact upload
9. Xbox Dev Mode install
10. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation

Fix one real failure at a time. Preserve pinning and fail-fast behavior.
