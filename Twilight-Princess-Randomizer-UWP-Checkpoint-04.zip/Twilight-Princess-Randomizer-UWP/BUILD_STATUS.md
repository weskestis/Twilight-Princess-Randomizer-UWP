# GitHub Actions build status — Checkpoint 04

## Repository

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

The manual checkpoint workflow remains the current Android bridge. Checkpoint 03 already hardened it to choose the numerically highest checkpoint ZIP, so no workflow edit is required for Checkpoint 04.

## Run 1 — Checkpoint 01 workflow bug

Passed checkout, checkpoint extraction, MSVC setup, Ninja/vcpkg dependencies.

Failed before assembly because the manual workflow incorrectly passed the checkpoint kit itself as an assembled-source argument to `verify_static.py`.

Fixed in Checkpoint 02.

## Run 2 — superproject Aurora gitlink conflict

Reached the real source assembly. The pinned randomizer and UWP reference merged except for the divergent `extern/aurora` submodule gitlink.

Fixed in Checkpoint 03 by explicitly preserving the exact randomizer Aurora base `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`, while retaining fail-fast behavior for any other superproject conflict.

## Run 3 — Aurora UWP forward-port conflict

Checkpoint 03 passed the superproject gitlink resolution and reached the dedicated SternXD Aurora UWP cherry-pick.

Most of `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682` applied cleanly. Git reported exactly two unresolved content conflicts:

```text
lib/input.cpp
lib/webgpu/gpu.cpp
```

The status also showed the rest of the UWP patch staged successfully, including the CMake provider changes and new `cmake/AuroraUwpDep.cmake`.

No CMake configure or compiler step had started.

### Root cause

The UWP patch was authored against an older Aurora layout. The pinned randomizer Aurora has since substantially changed both conflicting files:

- `lib/input.cpp` now contains newer controller persistence/rumble code and uses `AURORA_ASSERT`.
- `lib/webgpu/gpu.cpp` now uses the newer `create_window_surface` path and contains newer WebGPU/resampling/vsync logic.

Taking SternXD's whole conflicted files would therefore downgrade current randomizer Aurora behavior.

## Checkpoint 04 fix

`scripts/assemble_port.py` now treats the observed conflict as an explicit forward-port operation:

1. the pinned Aurora UWP cherry-pick is attempted normally;
2. if it conflicts, the unresolved set must be **exactly** `lib/input.cpp` and `lib/webgpu/gpu.cpp`;
3. every non-conflicting file from the SternXD UWP patch remains staged;
4. the two conflicting files are restored from the newer randomizer Aurora side;
5. only the required UWP semantics are reapplied to the newer structures:
   - UWP SDL input initialization excludes unsupported haptic/sensor startup while preserving `AURORA_ASSERT`;
   - desktop Dawn native/Tracy setup is excluded from Windows Store builds;
   - the UWP CoreWindow import/surface path is added without replacing the newer non-UWP surface path;
6. the cherry-pick is continued;
7. any different conflict still aborts.

Both the kit verifier and assembled-source verifier now assert these Aurora UWP markers.

## Local validation for Checkpoint 04

- Python source compilation passes.
- Kit static verification passes.
- The two forward-port transforms pass exact-anchor and idempotence tests.
- A synthetic Git repository was used to reproduce exactly two cherry-pick conflicts at `lib/input.cpp` and `lib/webgpu/gpu.cpp`; the Checkpoint 04 resolver preserved the newer side, applied the UWP transforms, retained a clean non-conflicting UWP change, and completed `cherry-pick --continue` successfully.

## Next gate

Upload Checkpoint 04 to the repository root and rerun the existing `Xbox UWP x64` workflow.

The next meaningful gate is **full assembled-source verification / randomizer static-feed CMake configure**. Do not call this compiled until the later build steps actually run.
