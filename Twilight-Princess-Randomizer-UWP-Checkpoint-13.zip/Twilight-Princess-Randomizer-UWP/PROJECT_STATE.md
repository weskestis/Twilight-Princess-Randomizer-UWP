# Project state — Checkpoint 13

Goal: a brand-new, side-by-side Xbox/UWP application named **Twilight Princess Randomizer**.

## Pinned upstreams

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Completed compatibility work

- Dedicated UWP package identity and branding.
- Static UWP Dusklight/randomizer feed.
- UWP Aurora forward-port over the newer randomizer Aurora base.
- Short Windows build root (`S:`) to avoid nested MSVC path/manifest failures.
- Stale `settings.cpp` UWP preprocessor conflict repaired.
- New randomizer YAML/base64 static dependencies wired into the UWP wrapper.
- Tracy archive conditionalized on `TRACY_ENABLE`.
- UWP FileBrowser sources structurally appended to `DUSK_FILES`.
- FileBrowser navigation forward-ported directly to the current Pane/Component API.
- UWP LocalState helper implementation now explicitly installed into `src/dusk/io.cpp`.

## Current proven build state

Checkpoint 12 completed the entire randomizer static-feed build, configured the fresh UWP package project, created the sideload certificate, and reached the final Xbox/UWP link.

The final link had exactly one unresolved symbol:

`dusk::io::uwp_local_folder_path()`

The declaration survived the old-UWP/new-randomizer merge, but the corresponding `io.cpp` implementation did not. Checkpoint 13 makes that implementation deterministic in the assembler and verifies it before CI reaches the linker.

## Next action

Upload Checkpoint 13 to the repository root. Keep the current workflow unchanged; it selects the numerically highest checkpoint automatically and should proceed directly through the same build path.
