# Source manifest — Checkpoint 13

## Pinned public sources

- `TwilitRealm/dusklight`
  - randomizer development commit: `07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
  - observed development label: `v1.4.1-627`
- `SternXD/dusklight-uwp`
  - UWP compatibility reference commit: `48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- `encounter/aurora`
  - submodule revision at pinned randomizer commit: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- `SternXD/aurora`
  - UWP compatibility patch source: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- `wolfpld/tracy`
  - version pulled by pinned Aurora: `6789e7d6f9a65ec98926b602097a33a9676d2606`

## User-provided source/artwork

- Exact uploaded Twilight Princess HD artwork retained as `branding/Twilight-Princess-Randomizer-original.jpg`.
- UWP assets are deterministic resizes/padded derivatives.

## Project-authored integration

- `scripts/assemble_port.py` — deterministic pinned-source assembler/forward-porter. Checkpoint 13 explicitly restores the UWP LocalState filesystem helper in `src/dusk/io.cpp` when the legacy merge does not carry its implementation forward.
- `scripts/verify_static.py` — kit and assembled-tree validation, including LocalState implementation checks.
- `.github/workflows/build.yml` — source-tree GitHub Actions workflow.
- `github-manual/build-xbox.yml` — checkpoint-repo Xbox/UWP workflow.
- `APP_IDENTITY.json` — standalone package identity contract.
- `BUILD_STATUS.md` / `PROJECT_STATE.md` / `NEXT_CHAT_HANDOFF.md` — exact continuation state.

No upstream source pins changed in Checkpoint 13.
