# Checkpoint 13 update

Checkpoint 12 reached the final Xbox/UWP linker. The only unresolved symbol was `dusk::io::uwp_local_folder_path()`, used by the in-app UWP FileBrowser.

Checkpoint 13 guarantees that LocalState helper is implemented in `src/dusk/io.cpp` after the old UWP source is merged onto the newer randomizer tree. The assembler and static verifier now require the exact implementation before a build can continue.

# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the pinned Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.627`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

This identity is intentionally separate from the older `Dusk`/`Dusklight` UWP packages.

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The current CI has already proven the randomizer static feed and UWP package configuration. Checkpoint 13 addresses the single unresolved LocalState linker symbol found at the final executable link.
