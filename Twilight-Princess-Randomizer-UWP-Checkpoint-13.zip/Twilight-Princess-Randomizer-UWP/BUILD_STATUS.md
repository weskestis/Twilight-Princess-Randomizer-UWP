# GitHub Actions build status — Checkpoint 13

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Checkpoint 12 result

Checkpoint 12 passed all of these gates:

- checkpoint extraction
- port-kit static verification
- integrated source assembly
- integrated source verification
- integrated source snapshot/upload
- randomizer static-feed configure
- full randomizer static-feed build
- fresh UWP package configure
- sideload certificate creation

The build then reached the final UWP executable link and failed with one unresolved external:

`dusk::io::uwp_local_folder_path()`

The reference came from the compiled UWP FileBrowser (`on_local_state_pressed`).

## Root cause

SternXD's FileBrowser patch adds both a declaration in `io.hpp` and an implementation in `io.cpp`. On the newer pinned randomizer tree, the source merge preserved the declaration but the `io.cpp` implementation can be lost under the superproject merge strategy. That creates a source tree that compiles cleanly but fails only at final link.

## Checkpoint 13 fix

`scripts/assemble_port.py` now explicitly guarantees the UWP LocalState implementation in `src/dusk/io.cpp`:

- adds `dusk/app_info.hpp` and `SDL3/SDL_filesystem.h` when needed;
- implements `uwp_local_folder_path()` behind `_UWP`;
- uses `SDL_GetPrefPath(dusk::OrgName, dusk::AppName)`;
- validates the resulting path before returning it;
- verifies the implementation is present in the assembled source before completing.

This directly satisfies the exact unresolved symbol from the Checkpoint 12 final link.

## Workflow

No workflow change is required.

## Next gate

Upload Checkpoint 13 and let `Xbox UWP x64` run. The expected next gate is either a successful signed Xbox package or a new final-link/package diagnostic beyond the now-fixed LocalState symbol.
