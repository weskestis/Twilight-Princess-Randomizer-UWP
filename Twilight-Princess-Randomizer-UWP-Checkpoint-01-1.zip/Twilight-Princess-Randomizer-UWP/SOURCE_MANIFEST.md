# Source manifest

## Core
- TwilitRealm/dusklight randomizer development branch
- Pinned commit: `07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- Build label: `v1.4.1-627`

## UWP compatibility
- SternXD/dusklight-uwp
- Pinned commit: `48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Lineage: UWP 1.1.1

## Aurora UWP forward-port
- SternXD/aurora UWP patch commit: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Expected newer randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`

## UWP dependency bundle
- SternXD/uwp-dep: `ae39aa004ae127bd00f8262d28b401f8e4ed8728`

## User-supplied branding
- Original file stored as `branding/Twilight-Princess-Randomizer-original.jpg`
- SHA-256: `521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff`
- UWP assets are resize/pad derivatives only; the original is retained unchanged.
