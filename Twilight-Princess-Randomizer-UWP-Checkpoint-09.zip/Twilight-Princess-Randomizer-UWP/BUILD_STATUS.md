# GitHub Actions build status — Checkpoint 09

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Confirmed progress through Checkpoint 08

- Source assembly passes.
- Assembled-source static verification passes.
- Randomizer static-feed CMake configure passes.
- Randomizer static-feed build passes completely (~2209 actions).
- Fresh UWP package-project configure passes.
- Sideload certificate creation passes.
- UWP executable reaches the final link step.

## Checkpoint 08 failure

The UWP link failed with unresolved `dusk::ui::FileBrowser` constructor/destructor symbols referenced by `prelaunch.cpp` and `settings.cpp`.

This is not a missing UWP wrapper library. The imported SternXD UWP tree contains:

- `src/dusk/ui/file_browser.cpp`
- `src/dusk/ui/file_browser.hpp`

but the newer pinned randomizer's `DUSK_FILES` list won the superproject CMake merge and did not include those UWP-only source files. The header was visible, so callers compiled, but the implementation never entered `dusklight.lib`.

## Checkpoint 09 fix

`scripts/assemble_port.py` now explicitly inserts both FileBrowser files into the top-level `DUSK_FILES` list after `controller_config.hpp`.

Both `verify_port()` and `verify_static.py` now require the implementation/header to be present in the assembled top-level CMake source list, so this link omission is caught before a long CI build.

## Workflow

No workflow change is required. Keep the Checkpoint 06 short-path `S:` workflow already in the repository.

## Next gate

Upload Checkpoint 09 and rerun `Xbox UWP x64`.

Expected next stages:

1. full static-feed build including `file_browser.cpp`;
2. UWP wrapper configure;
3. certificate creation;
4. final UWP link;
5. AppX/MSIX packaging and artifact upload.
