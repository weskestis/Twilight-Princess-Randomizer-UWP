#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess

RANDO_REPO = "https://github.com/TwilitRealm/dusklight.git"
RANDO_SHA = "07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e"
UWP_REPO = "https://github.com/SternXD/dusklight-uwp.git"
UWP_SHA = "48d193dfebe4b20b4984af1d27d0e99f6b6722a7"
AURORA_UWP_REPO = "https://github.com/SternXD/aurora.git"
AURORA_UWP_SHA = "aaf5b8b092ff547a33a9d199dd2c52572bff6682"
EXPECTED_AURORA_BASE = "6c4c27f9e8e40f584d27726655d80ec85a5a7d2c"

PACKAGE_NAME = "TwilightPrincessRandomizer"
DISPLAY_NAME = "Twilight Princess Randomizer"
PUBLISHER = "CN=TwilightPrincessRandomizer"
PUBLISHER_DISPLAY = "Twilight Princess Randomizer"
DESCRIPTION = "Twilight Princess Randomizer for Xbox/UWP"
PHONE_PRODUCT_ID = "e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d"
PACKAGE_VERSION = "1.4.1.627"
TARGET_NAME = "TwilightPrincessRandomizer"

KIT_ROOT = Path(__file__).resolve().parents[1]
BRANDING_ASSETS = KIT_ROOT / "branding" / "Assets"


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess:
    print("+", " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=cwd, check=check, text=True)


def capture(cmd: list[str], cwd: Path) -> str:
    return subprocess.check_output(cmd, cwd=cwd, text=True).strip()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if old not in text:
        raise RuntimeError(f"Required source anchor missing while patching {label}: {old[:120]!r}")
    return text.replace(old, new, 1)


def ensure_main_uwp_cmake(source: Path) -> None:
    path = source / "CMakeLists.txt"
    text = path.read_text(encoding="utf-8")

    if 'option(DUSK_UWP "Enable UWP compat support"' not in text:
        anchor = 'option(DUSK_ENABLE_CODE_MODS "Enable code mods" OFF)\n'
        text = replace_once(
            text,
            anchor,
            anchor
            + 'option(DUSK_UWP "Enable UWP compat support" OFF)\n\n'
            + 'if (MSVC AND DUSK_UWP)\n'
            + '    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL" CACHE STRING "" FORCE)\n'
            + 'endif ()\n',
            "DUSK_UWP option",
        )

    # UWP file browser source list integration.  The pinned randomizer moved its
    # DUSK_FILES definition out to files.cmake, so do not anchor this port on a
    # neighboring filename in that list.  Instead append the UWP-only sources to
    # DUSK_FILES immediately before the target is created.  This remains valid
    # whether the list itself lives in CMakeLists.txt, files.cmake, or another
    # included CMake fragment.
    if "src/dusk/ui/file_browser.cpp" not in text or "src/dusk/ui/file_browser.hpp" not in text:
        target_match = re.search(
            r"(?m)^if\(ANDROID\)\r?$\n[ \t]+add_library\(dusklight SHARED \${DUSK_FILES}\)",
            text,
        )
        if target_match is None:
            raise RuntimeError("Could not locate Dusklight target creation while adding UWP FileBrowser sources")
        addition = (
            "# UWP file browser source list\n"
            "if (DUSK_UWP)\n"
            "    list(APPEND DUSK_FILES\n"
            "        src/dusk/ui/file_browser.cpp\n"
            "        src/dusk/ui/file_browser.hpp\n"
            "    )\n"
            "endif ()\n\n"
        )
        text = text[: target_match.start()] + addition + text[target_match.start() :]

    if "elseif (DUSK_UWP)" not in text:
        old = (
            'if(ANDROID)\n'
            '    add_library(dusklight SHARED ${DUSK_FILES})\n'
            '    set_target_properties(dusklight PROPERTIES OUTPUT_NAME main)\n'
            'else ()\n'
            '    add_executable(dusklight ${DUSK_FILES})\n'
            'endif ()'
        )
        new = (
            'if(ANDROID)\n'
            '    add_library(dusklight SHARED ${DUSK_FILES})\n'
            '    set_target_properties(dusklight PROPERTIES OUTPUT_NAME main)\n'
            'elseif (DUSK_UWP)\n'
            '    add_library(dusklight STATIC ${DUSK_FILES})\n'
            '    target_compile_definitions(dusklight PRIVATE _UWP)\n'
            'else ()\n'
            '    add_executable(dusklight ${DUSK_FILES})\n'
            'endif ()'
        )
        text = replace_once(text, old, new, "static UWP target")

    # UWP wrapper owns runtime deployment and package resources.
    text = text.replace(
        "if (NOT APPLE)\n    add_custom_command(TARGET dusklight POST_BUILD",
        "if (NOT APPLE AND NOT DUSK_UWP)\n    add_custom_command(TARGET dusklight POST_BUILD",
    )
    text = text.replace(
        "if (WIN32)\n    set(DUSK_WINDOWS_RESOURCE_DIR",
        "if (WIN32 AND NOT DUSK_UWP)\n    set(DUSK_WINDOWS_RESOURCE_DIR",
    )
    # The legacy UWP fork deliberately omits Aurora runtime-DLL deployment because
    # the UWP wrapper owns package runtime files. The newer randomizer added a new
    # aurora_install_runtime_dlls() call later in the file. After the source merge
    # that call can survive outside the UWP guard while the helper include remains
    # inside it, causing CMake to fail with "Unknown CMake command". Keep both
    # runtime copy/install paths desktop-only.
    install_call = "aurora_install_runtime_dlls(dusklight ${CMAKE_INSTALL_PREFIX})"
    guarded_install = "if (NOT DUSK_UWP)\n    " + install_call + "\nendif ()"
    if install_call in text and guarded_install not in text:
        text = text.replace(install_call, guarded_install, 1)

    # Psapi is desktop crash/symbol support; do not force it into the Store/UWP link.
    text = text.replace(
        "if (WIN32)\n    target_link_libraries(dusklight PRIVATE Psapi)\nendif ()",
        "if (WIN32 AND NOT DUSK_UWP)\n    target_link_libraries(dusklight PRIVATE Psapi)\nendif ()",
    )

    path.write_text(text, encoding="utf-8")


def ensure_main_cpp_uwp(source: Path) -> None:
    path = source / "src/dusk/main.cpp"
    text = path.read_text(encoding="utf-8")

    text = text.replace(
        '(defined(TARGET_OS_TV) && TARGET_OS_TV)\n    (void)argc;',
        '(defined(TARGET_OS_TV) && TARGET_OS_TV) || defined(_UWP)\n    (void)argc;',
        1,
    )
    # Console allocation is desktop-only even though the static feed is compiled with _WIN32.
    text = text.replace(
        "int DuskMain(int argc, char* argv[]) {\n    WindowsSetupConsole(ShouldShowWindowsConsole(argc, argv));",
        "int DuskMain(int argc, char* argv[]) {\n#if !defined(_UWP)\n    WindowsSetupConsole(ShouldShowWindowsConsole(argc, argv));\n#endif",
        1,
    )
    text = text.replace("#if _WIN32\nint WINAPI wWinMain", "#if _WIN32 && !defined(_UWP)\nint WINAPI wWinMain", 1)

    if "SDL_MAIN_EXPORTED" not in text:
        main_anchor = 'int main(int argc, char* argv[]) {\n    return DuskMain(argc, argv);\n}\n'
        main_repl = (
            '#ifdef _UWP\n'
            '#define SDL_MAIN_EXPORTED\n'
            '#include "SDL3/SDL_main.h"\n'
            '#endif\n'
            + main_anchor
        )
        text = replace_once(text, main_anchor, main_repl, "SDL UWP main export")

    path.write_text(text, encoding="utf-8")



def patch_io_uwp_local_folder(source: Path) -> None:
    """Guarantee the UWP LocalState helper has a linked implementation.

    SternXD's FileBrowser declares dusk::io::uwp_local_folder_path() in io.hpp.
    On the newer randomizer tree the corresponding io.cpp hunk can be lost while
    merging with -X ours, leaving a declaration that compiles but an unresolved
    external at the final UWP link. Install the implementation explicitly in
    io.cpp so the static feed always exports the symbol.
    """
    path = source / "src/dusk/io.cpp"
    text = path.read_text(encoding="utf-8")

    if "uwp_local_folder_path()" in text:
        return

    include_anchor = '#include "dusk/io.hpp"\n'
    include_block = (
        '#include "dusk/io.hpp"\n'
        '#include "dusk/app_info.hpp"\n'
        '\n'
        '#include <SDL3/SDL_filesystem.h>\n'
    )
    text = replace_once(text, include_anchor, include_block, "UWP LocalState includes")

    namespace_close = "\n}  // namespace dusk::io\n"
    if namespace_close not in text:
        raise RuntimeError("Could not locate dusk::io namespace close while adding UWP LocalState helper")

    impl = (
        '\n#if defined(_UWP)\n'
        'std::optional<std::filesystem::path> uwp_local_folder_path() {\n'
        '    char* pref = SDL_GetPrefPath(dusk::OrgName, dusk::AppName);\n'
        '    if (pref == nullptr) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '\n'
        '    const std::filesystem::path p = path_from_utf8(pref);\n'
        '    SDL_free(pref);\n'
        '    if (p.empty()) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '\n'
        '    std::error_code ec;\n'
        '    const std::filesystem::path out = std::filesystem::absolute(p, ec).lexically_normal();\n'
        '    if (ec || out.empty()) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '    if (!std::filesystem::exists(out, ec) || !std::filesystem::is_directory(out, ec)) {\n'
        '        return std::nullopt;\n'
        '    }\n'
        '    return out;\n'
        '}\n'
        '#endif\n'
    )
    head, tail = text.rsplit(namespace_close, 1)
    text = head + impl + namespace_close + tail
    path.write_text(text, encoding="utf-8")


def patch_file_browser_current_pane(source: Path) -> None:
    # Forward-port SternXD's UWP FileBrowser to the pinned randomizer Pane API.
    # Keep compatibility local to the browser and use Component::children().
    path = source / "src/dusk/ui/file_browser.cpp"
    if not path.exists():
        raise RuntimeError("UWP FileBrowser source is missing")
    text = path.read_text(encoding="utf-8")

    old_last = '''bool try_focus_file_pane_last(Pane* pane, Rml::Event& event) {
    if (pane != nullptr && pane->focus_last()) {
        mDoAud_seStartMenu(kSoundItemFocus);
        event.StopImmediatePropagation();
        return true;
    }
    return false;
}
'''
    new_last = '''bool try_focus_file_pane_last(Pane* pane, Rml::Event& event) {
    if (pane == nullptr) {
        return false;
    }
    auto& children = pane->children();
    for (auto it = children.rbegin(); it != children.rend(); ++it) {
        if (*it != nullptr && (*it)->focus()) {
            mDoAud_seStartMenu(kSoundItemFocus);
            event.StopImmediatePropagation();
            return true;
        }
    }
    return false;
}

int file_pane_row_count(Pane* pane) {
    return pane == nullptr ? 0 : static_cast<int>(pane->children().size());
}

int file_pane_child_index_containing(Pane* pane, Rml::Element* target) {
    if (pane == nullptr || target == nullptr) {
        return -1;
    }
    auto& children = pane->children();
    for (int i = 0; i < static_cast<int>(children.size()); ++i) {
        if (children[static_cast<std::size_t>(i)] != nullptr &&
            children[static_cast<std::size_t>(i)]->contains(target))
        {
            return i;
        }
    }
    return -1;
}
'''
    if old_last in text:
        text = text.replace(old_last, new_last, 1)
    elif "int file_pane_row_count(Pane* pane)" not in text:
        raise RuntimeError("Could not locate legacy FileBrowser Pane navigation helper")

    text = text.replace("mFilePane->row_count()", "file_pane_row_count(mFilePane.get())")
    text = text.replace(
        "mFilePane->child_index_containing(target)",
        "file_pane_child_index_containing(mFilePane.get(), target)",
    )

    stale = ("->row_count()", "->child_index_containing(", "->focus_last()")
    for marker in stale:
        if marker in text:
            raise RuntimeError(f"Legacy Pane API still referenced by UWP FileBrowser: {marker}")

    for marker in (
        "int file_pane_row_count(Pane* pane)",
        "int file_pane_child_index_containing(Pane* pane, Rml::Element* target)",
        "pane->children()",
    ):
        if marker not in text:
            raise RuntimeError(f"Current-Pane FileBrowser forward-port marker missing: {marker}")

    path.write_text(text, encoding="utf-8")


def patch_pane_uwp_compat(source: Path) -> None:
    """Restore the small Pane navigation surface used by the UWP FileBrowser.

    The pinned randomizer refactored Pane after SternXD's UWP FileBrowser was
    written, removing focus_last(), child_index_containing(), and row_count().
    FileBrowser still needs those navigation primitives. Re-add them as thin
    compatibility helpers over the current Pane child list without changing
    current Pane behavior or its newer bottom-spacer/focus-closeness logic.
    """
    hpp_path = source / "src/dusk/ui/pane.hpp"
    cpp_path = source / "src/dusk/ui/pane.cpp"
    hpp = hpp_path.read_text(encoding="utf-8")
    cpp = cpp_path.read_text(encoding="utf-8")

    if "bool focus_last();" not in hpp:
        hpp = replace_once(
            hpp,
            "    bool focus() override;\n",
            "    bool focus() override;\n    bool focus_last();\n",
            "Pane UWP focus_last declaration",
        )

    if "child_index_containing(Rml::Element* target) const" not in hpp:
        anchor = "    bool focus_closest_child(float posY);\n\nprivate:\n"
        addition = (
            "    bool focus_closest_child(float posY);\n\n"
            "    // Compatibility helpers used by the UWP in-app FileBrowser.\n"
            "    int child_index_containing(Rml::Element* target) const;\n"
            "    int row_count() const noexcept;\n\n"
            "private:\n"
        )
        hpp = replace_once(hpp, anchor, addition, "Pane UWP navigation declarations")

    if "bool Pane::focus_last()" not in cpp:
        anchor = "Rml::Element* Pane::add_section(const Rml::String& text) {\n"
        impl = (
            "bool Pane::focus_last() {\n"
            "    for (int i = static_cast<int>(mChildren.size()) - 1; i >= 0; --i) {\n"
            "        if (mChildren[static_cast<std::size_t>(i)]->focus()) {\n"
            "            return true;\n"
            "        }\n"
            "    }\n"
            "    return false;\n"
            "}\n\n"
        )
        cpp = replace_once(cpp, anchor, impl + anchor, "Pane UWP focus_last implementation")

    if "int Pane::child_index_containing(Rml::Element* target) const" not in cpp:
        anchor = "float Pane::get_focused_child_y() {\n"
        impl = (
            "int Pane::child_index_containing(Rml::Element* target) const {\n"
            "    if (target == nullptr) {\n"
            "        return -1;\n"
            "    }\n"
            "    for (int i = 0; i < static_cast<int>(mChildren.size()); ++i) {\n"
            "        if (mChildren[static_cast<std::size_t>(i)]->contains(target)) {\n"
            "            return i;\n"
            "        }\n"
            "    }\n"
            "    return -1;\n"
            "}\n\n"
            "int Pane::row_count() const noexcept {\n"
            "    return static_cast<int>(mChildren.size());\n"
            "}\n\n"
        )
        cpp = replace_once(cpp, anchor, impl + anchor, "Pane UWP child navigation implementation")

    hpp_path.write_text(hpp, encoding="utf-8")
    cpp_path.write_text(cpp, encoding="utf-8")

def patch_uwp_wrapper(source: Path) -> None:
    path = source / "platforms/uwp/CMakeLists.txt"
    if not path.exists():
        raise RuntimeError("UWP project was not imported: platforms/uwp/CMakeLists.txt is missing")
    text = path.read_text(encoding="utf-8")

    # Make the executable/project itself distinct too, not only the package identity.
    text = re.sub(r"project\([^\n]+LANGUAGES CXX\)", f"project({TARGET_NAME} LANGUAGES CXX)", text, count=1)

    helper_marker = "# Randomizer/new-core link compatibility"
    if helper_marker not in text:
        anchor = "set(BinLibs\n"
        helper = r'''# Randomizer/new-core link compatibility
# Later randomizer builds add static libraries that the 1.1.1 UWP wrapper predates.
function(tpr_find_built_lib OUT_VAR REGEX_TEXT)
    file(GLOB_RECURSE _tpr_candidates LIST_DIRECTORIES FALSE "${DUSK_DIR}/*.lib")
    list(FILTER _tpr_candidates INCLUDE REGEX "${REGEX_TEXT}")
    list(LENGTH _tpr_candidates _tpr_count)
    if(_tpr_count EQUAL 0)
        message(FATAL_ERROR "Required randomizer UWP feed library not found: ${REGEX_TEXT} under ${DUSK_DIR}")
    endif()
    list(GET _tpr_candidates 0 _tpr_first)
    set(${OUT_VAR} "${_tpr_first}" PARENT_SCOPE)
endfunction()

# Tracy's CMake target exists even when profiling is disabled, but with
# TRACY_ENABLE=OFF the client instrumentation macros compile out and the main
# static archive may not cause TracyClient.lib to be emitted in a target-only
# build. Only require/link the archive when the static feed was explicitly
# configured with Tracy profiling enabled.
set(TPR_TRACY_LIB "")
set(_tpr_tracy_enabled OFF)
if(EXISTS "${DUSK_DIR}/CMakeCache.txt")
    file(STRINGS "${DUSK_DIR}/CMakeCache.txt" _tpr_tracy_lines REGEX "^TRACY_ENABLE:BOOL=")
    foreach(_tpr_tracy_line IN LISTS _tpr_tracy_lines)
        if(_tpr_tracy_line STREQUAL "TRACY_ENABLE:BOOL=ON")
            set(_tpr_tracy_enabled ON)
        endif()
    endforeach()
endif()
if(_tpr_tracy_enabled)
    tpr_find_built_lib(TPR_TRACY_LIB "/TracyClient[^/]*[.]lib$")
else()
    message(STATUS "Randomizer feed has TRACY_ENABLE=OFF; TracyClient.lib is not required for UWP link")
endif()

tpr_find_built_lib(TPR_YAML_CPP_LIB "/yaml-cpp[.]lib$")
tpr_find_built_lib(TPR_BASE64PP_LIB "/base64pp[.]lib$")

'''
        text = replace_once(text, anchor, helper + anchor, "UWP extra-library resolver")

    if "${TPR_TRACY_LIB}" not in text.split("set(BinLibs", 1)[1]:
        target = "\t${DUSK_DIR}/dusklight.lib\t\n"
        replacement = (
            target
            + "\t${TPR_TRACY_LIB}\n"
            + "\t${TPR_YAML_CPP_LIB}\n"
            + "\t${TPR_BASE64PP_LIB}\n"
            + "\tWs2_32.lib\n"
        )
        text = replace_once(text, target, replacement, "randomizer UWP libraries")

    tile_assets = "\tAssets/Wide310x150Logo.scale-200.png\n\tAssets/Square310x310Logo.scale-200.png\n"
    if "Wide310x150Logo.scale-200.png" not in text:
        anchor = "\tAssets/SplashScreen.scale-200.png\n"
        text = replace_once(text, anchor, anchor + tile_assets, "Xbox tile assets")

    path.write_text(text, encoding="utf-8")


def patch_manifest(source: Path) -> None:
    path = source / "platforms/uwp/Package.appxmanifest"
    text = path.read_text(encoding="utf-8-sig")

    substitutions = [
        (r'Name="[^"]+"\s*\n\s*Publisher="[^"]+"\s*\n\s*Version="[^"]+"',
         f'Name="{PACKAGE_NAME}"\n    Publisher="{PUBLISHER}"\n    Version="{PACKAGE_VERSION}"'),
        (r'PhoneProductId="[^"]+"', f'PhoneProductId="{PHONE_PRODUCT_ID}"'),
        (r'<DisplayName>.*?</DisplayName>', f'<DisplayName>{DISPLAY_NAME}</DisplayName>'),
        (r'<PublisherDisplayName>.*?</PublisherDisplayName>', f'<PublisherDisplayName>{PUBLISHER_DISPLAY}</PublisherDisplayName>'),
        (r'DisplayName="[^"]+"', f'DisplayName="{DISPLAY_NAME}"'),
        (r'Description="[^"]+"', f'Description="{DESCRIPTION}"'),
    ]
    for pattern, repl in substitutions:
        text, count = re.subn(pattern, repl, text, count=1, flags=re.S)
        if count != 1:
            raise RuntimeError(f"Could not patch manifest field: {pattern}")

    # Prefer the user's full 16:9 artwork for wide Xbox presentation when supported.
    if "Wide310x150Logo" not in text:
        text = text.replace("<uap:DefaultTile/>", '<uap:DefaultTile Wide310x150Logo="Assets\\Wide310x150Logo.png" Square310x310Logo="Assets\\Square310x310Logo.png"/>', 1)

    path.write_text(text, encoding="utf-8-sig")


def install_branding(source: Path) -> None:
    dest = source / "platforms/uwp/Assets"
    dest.mkdir(parents=True, exist_ok=True)
    required = [
        "LockScreenLogo.scale-200.png",
        "Square44x44Logo.targetsize-24_altform-unplated.png",
        "Square44x44Logo.scale-200.png",
        "Square150x150Logo.scale-200.png",
        "StoreLogo.png",
        "SplashScreen.scale-200.png",
        "Wide310x150Logo.scale-200.png",
        "Square310x310Logo.scale-200.png",
    ]
    for name in required:
        src = BRANDING_ASSETS / name
        if not src.exists():
            raise RuntimeError(f"Branding asset missing from kit: {src}")
        shutil.copy2(src, dest / name)



def assert_preprocessor_balanced(path: Path) -> None:
    stack: list[tuple[int, str]] = []
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            stack.append((lineno, stripped))
        elif re.match(r"#\s*endif\b", stripped):
            if not stack:
                raise RuntimeError(f"Unexpected #endif in {path} at line {lineno}")
            stack.pop()
    if stack:
        lineno, directive = stack[-1]
        raise RuntimeError(f"Unclosed preprocessor directive in {path} at line {lineno}: {directive}")


def patch_settings_uwp(source: Path) -> None:
    """Normalize the stale UWP settings guard onto the newer randomizer settings layout.

    SternXD's UWP fork added an outer _UWP guard around the updater/Discord settings
    while its older base also had a nearby conditional that no longer exists in the
    pinned randomizer tree. A whole-branch merge can therefore leave one orphan #endif.
    Rebuild only this small region from the merged content, preserving the current
    updater and Discord bodies while making the _UWP guard structurally balanced.
    """
    path = source / "src/dusk/ui/settings.cpp"
    text = path.read_text(encoding="utf-8")
    check_marker = "        config_bool_select(leftPane, rightPane, getSettings().backend.checkForUpdates,"
    advanced_marker = "        config_bool_select(leftPane, rightPane, getSettings().backend.enableAdvancedSettings,"
    check_pos = text.find(check_marker)
    advanced_pos = text.find(advanced_marker, check_pos if check_pos >= 0 else 0)
    if check_pos < 0 or advanced_pos < 0 or advanced_pos <= check_pos:
        raise RuntimeError("Could not locate updater/advanced settings region for UWP normalization")

    # Remove an already-merged outer _UWP opener immediately before the updater block.
    prefix = text[:check_pos]
    prefix_lines = prefix.splitlines(keepends=True)
    scan = len(prefix_lines) - 1
    while scan >= 0 and prefix_lines[scan].strip() == "":
        scan -= 1
    if scan >= 0 and prefix_lines[scan].strip() in {"#ifndef _UWP", "#if !defined(_UWP)"}:
        del prefix_lines[scan]
    prefix = "".join(prefix_lines)

    # Preserve all current randomizer code in the region, but discard only #endifs
    # that are unmatched within the region. Those are stale closers from the old
    # UWP base; nested directives such as DUSK_DISCORD remain intact.
    region = text[check_pos:advanced_pos]
    depth = 0
    cleaned: list[str] = []
    removed_unmatched = 0
    for line in region.splitlines(keepends=True):
        stripped = line.lstrip()
        if re.match(r"#\s*(if|ifdef|ifndef)\b", stripped):
            depth += 1
            cleaned.append(line)
        elif re.match(r"#\s*endif\b", stripped):
            if depth > 0:
                depth -= 1
                cleaned.append(line)
            else:
                removed_unmatched += 1
        else:
            cleaned.append(line)
    if depth != 0:
        raise RuntimeError("Updater/Discord settings region contains an unclosed nested preprocessor guard")

    body = "".join(cleaned).rstrip() + "\n"
    normalized = prefix + "#ifndef _UWP\n" + body + "#endif\n" + text[advanced_pos:]
    path.write_text(normalized, encoding="utf-8")
    assert_preprocessor_balanced(path)
    print(f"Normalized UWP settings preprocessor guard; removed {removed_unmatched} stale #endif line(s)", flush=True)


def patch_aurora_input_uwp(aurora: Path) -> None:
    path = aurora / "lib/input.cpp"
    text = path.read_text(encoding="utf-8")
    marker = "#ifndef AURORA_WINDOWS_STORE\n  AURORA_ASSERT(SDL_Init"
    if marker not in text:
        old = (
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_HAPTIC | SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD | SDL_INIT_SENSOR),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
        )
        new = (
            '#ifndef AURORA_WINDOWS_STORE\n'
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_HAPTIC | SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD | SDL_INIT_SENSOR),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
            '#else\n'
            '  AURORA_ASSERT(SDL_Init(SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD),\n'
            '         "Failed to initialize SDL subsystems: {}", SDL_GetError());\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora UWP SDL initialization")
    path.write_text(text, encoding="utf-8")


def patch_aurora_gpu_uwp(aurora: Path) -> None:
    path = aurora / "lib/webgpu/gpu.cpp"
    text = path.read_text(encoding="utf-8")

    if '#if !defined(AURORA_WINDOWS_STORE)\n#include "../dawn/TracyPlatform.hpp"' not in text:
        old = (
            '#ifdef WEBGPU_DAWN\n'
            '#include "../dawn/TracyPlatform.hpp"\n'
            '#include <dawn/native/DawnNative.h>\n'
            '#endif\n'
        )
        new = (
            '#ifdef WEBGPU_DAWN\n'
            '#if !defined(AURORA_WINDOWS_STORE)\n'
            '#include "../dawn/TracyPlatform.hpp"\n'
            '#include <dawn/native/DawnNative.h>\n'
            '#endif\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora Dawn UWP includes")

    if 'extern "C" __declspec(dllimport) void* uwp_GetWindowReference();' not in text:
        anchor = 'static std::atomic_bool g_vsyncEnabled = true;\n'
        addition = (
            anchor
            + '\n#if defined(AURORA_WINDOWS_STORE)\n'
            + 'extern "C" __declspec(dllimport) void* uwp_GetWindowReference();\n'
            + '#endif\n'
        )
        text = replace_once(text, anchor, addition, "Aurora UWP CoreWindow import")

    if 'wgpu::SurfaceDescriptorFromWindowsCoreWindow surfaceDesc{};' not in text:
        old = (
            '  window::SurfaceLock surfaceLock;\n'
            '  release_surface_locked();\n'
            '  g_surface = create_window_surface(g_instance, window, "Surface");\n'
        )
        new = (
            '  window::SurfaceLock surfaceLock;\n'
            '  release_surface_locked();\n'
            '#if defined(AURORA_WINDOWS_STORE)\n'
            '  wgpu::SurfaceDescriptorFromWindowsCoreWindow surfaceDesc{};\n'
            '  surfaceDesc.sType = wgpu::SType::SurfaceDescriptorFromWindowsCoreWindow;\n'
            '  surfaceDesc.coreWindow = uwp_GetWindowReference();\n'
            '  const wgpu::SurfaceDescriptor surfaceDescriptor{\n'
            '      .nextInChain = reinterpret_cast<const wgpu::ChainedStruct*>(&surfaceDesc),\n'
            '      .label = "Surface",\n'
            '  };\n'
            '  g_surface = g_instance.CreateSurface(&surfaceDescriptor);\n'
            '#else\n'
            '  g_surface = create_window_surface(g_instance, window, "Surface");\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora UWP CoreWindow surface")

    if '#ifdef WEBGPU_DAWN\n#if !defined(AURORA_WINDOWS_STORE)\n    dawn::native::DawnInstanceDescriptor' not in text:
        old = (
            '#ifdef WEBGPU_DAWN\n'
            '    dawn::native::DawnInstanceDescriptor dawnInstanceDescriptor;\n'
            '    dawnInstanceDescriptor.backendValidationLevel = dawn::native::BackendValidationLevel::Disabled;\n'
            '    dawnInstanceDescriptor.SetLoggingCallback(wgpu_log);\n'
            '#ifdef TRACY_ENABLE\n'
            '    dawnInstanceDescriptor.platform = tracy_dawn_platform();\n'
            '#endif\n'
            '    instanceDescriptor.nextInChain = &dawnInstanceDescriptor;\n'
            '#endif\n'
        )
        new = (
            '#ifdef WEBGPU_DAWN\n'
            '#if !defined(AURORA_WINDOWS_STORE)\n'
            '    dawn::native::DawnInstanceDescriptor dawnInstanceDescriptor;\n'
            '    dawnInstanceDescriptor.backendValidationLevel = dawn::native::BackendValidationLevel::Disabled;\n'
            '    dawnInstanceDescriptor.SetLoggingCallback(wgpu_log);\n'
            '#ifdef TRACY_ENABLE\n'
            '    dawnInstanceDescriptor.platform = tracy_dawn_platform();\n'
            '#endif\n'
            '    instanceDescriptor.nextInChain = &dawnInstanceDescriptor;\n'
            '#endif\n'
            '#endif\n'
        )
        text = replace_once(text, old, new, "Aurora Dawn UWP instance")

    path.write_text(text, encoding="utf-8")


def resolve_aurora_uwp_cherry_pick(aurora: Path) -> None:
    unmerged = [
        line.strip()
        for line in capture(["git", "diff", "--name-only", "--diff-filter=U"], aurora).splitlines()
        if line.strip()
    ]
    expected = {"lib/input.cpp", "lib/webgpu/gpu.cpp"}
    if set(unmerged) != expected:
        run(["git", "status", "--short"], aurora, check=False)
        run(["git", "cherry-pick", "--abort"], aurora, check=False)
        raise RuntimeError(
            "Aurora UWP cherry-pick has unexpected conflicts: "
            + (", ".join(unmerged) if unmerged else "cherry-pick failed without an unmerged path")
        )

    # The pinned UWP commit predates significant input and WebGPU refactors. Keep the
    # newer randomizer Aurora versions of those two files and port only the UWP
    # semantics from SternXD's patch onto their current structure. Every other file
    # in the UWP commit has already applied cleanly at this point.
    run(["git", "checkout", "--ours", "--", "lib/input.cpp", "lib/webgpu/gpu.cpp"], aurora)
    patch_aurora_input_uwp(aurora)
    patch_aurora_gpu_uwp(aurora)
    run(["git", "add", "lib/input.cpp", "lib/webgpu/gpu.cpp"], aurora)

    remaining = capture(["git", "diff", "--name-only", "--diff-filter=U"], aurora)
    if remaining:
        run(["git", "status", "--short"], aurora, check=False)
        run(["git", "cherry-pick", "--abort"], aurora, check=False)
        raise RuntimeError(f"Aurora UWP cherry-pick still has unresolved paths: {remaining}")

    run([
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "cherry-pick", "--continue",
    ], aurora)

def verify_randomizer_storage(source: Path) -> None:
    # Package identity isolates UWP LocalState. The current UI must still route randomizer data
    # through Dusklight's configured data path rather than an immutable install path.
    candidates = [
        source / "src/dusk/ui/rando_config.cpp",
        source / "src/dusk/ui/rando_config.hpp",
        source / "src/dusk/ui/rando_seed_generation.cpp",
    ]
    joined = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in candidates if p.exists())
    if "GetRandomizer" not in joined:
        raise RuntimeError("Randomizer UI storage helpers were not found; refusing unverified UWP port")


def verify_port(source: Path) -> None:
    required = [
        source / "platforms/uwp/CMakeLists.txt",
        source / "platforms/uwp/Package.appxmanifest",
        source / "src/dusk/randomizer/generator/randomizer.cpp",
        source / "src/dusk/ui/rando_config.cpp",
        source / "src/dusk/ui/file_browser.cpp",
    ]
    missing = [str(p.relative_to(source)) for p in required if not p.exists()]
    if missing:
        raise RuntimeError("Missing required port components: " + ", ".join(missing))

    cmake = (source / "CMakeLists.txt").read_text(encoding="utf-8")
    for marker in (
        "DUSK_UWP",
        "add_library(dusklight STATIC",
        "_UWP",
        "src/dusk/ui/file_browser.cpp",
        "src/dusk/ui/file_browser.hpp",
    ):
        if marker not in cmake:
            raise RuntimeError(f"Top-level CMake missing required UWP marker: {marker}")

    wrapper = (source / "platforms/uwp/CMakeLists.txt").read_text(encoding="utf-8")
    for marker in ("TPR_YAML_CPP_LIB", "TPR_BASE64PP_LIB", "TPR_TRACY_LIB", TARGET_NAME, "Wide310x150Logo"):
        if marker not in wrapper:
            raise RuntimeError(f"UWP wrapper missing marker: {marker}")

    manifest = (source / "platforms/uwp/Package.appxmanifest").read_text(encoding="utf-8-sig")
    for marker in (PACKAGE_NAME, DISPLAY_NAME, PUBLISHER, PACKAGE_VERSION, PHONE_PRODUCT_ID):
        if marker not in manifest:
            raise RuntimeError(f"UWP manifest missing custom identity marker: {marker}")

    aurora_input = (source / "extern/aurora/lib/input.cpp").read_text(encoding="utf-8")
    for marker in ("AURORA_WINDOWS_STORE", "SDL_INIT_JOYSTICK | SDL_INIT_GAMEPAD"):
        if marker not in aurora_input:
            raise RuntimeError(f"Aurora input missing UWP marker: {marker}")

    aurora_gpu = (source / "extern/aurora/lib/webgpu/gpu.cpp").read_text(encoding="utf-8")
    for marker in ("uwp_GetWindowReference", "SurfaceDescriptorFromWindowsCoreWindow", "AURORA_WINDOWS_STORE"):
        if marker not in aurora_gpu:
            raise RuntimeError(f"Aurora WebGPU missing UWP marker: {marker}")

    io_cpp = (source / "src/dusk/io.cpp").read_text(encoding="utf-8")
    for marker in (
        "std::optional<std::filesystem::path> uwp_local_folder_path()",
        "SDL_GetPrefPath(dusk::OrgName, dusk::AppName)",
        "#if defined(_UWP)",
    ):
        if marker not in io_cpp:
            raise RuntimeError(f"UWP LocalState implementation missing from io.cpp: {marker}")

    file_browser = (source / "src/dusk/ui/file_browser.cpp").read_text(encoding="utf-8")
    for marker in (
        "int file_pane_row_count(Pane* pane)",
        "int file_pane_child_index_containing(Pane* pane, Rml::Element* target)",
        "pane->children()",
    ):
        if marker not in file_browser:
            raise RuntimeError(f"Current-Pane FileBrowser forward-port missing: {marker}")
    for marker in ("->row_count()", "->child_index_containing(", "->focus_last()"):
        if marker in file_browser:
            raise RuntimeError(f"UWP FileBrowser still references removed Pane API: {marker}")

    settings_path = source / "src/dusk/ui/settings.cpp"
    settings = settings_path.read_text(encoding="utf-8")
    if "#ifndef _UWP\n        config_bool_select(leftPane, rightPane, getSettings().backend.checkForUpdates," not in settings:
        raise RuntimeError("Settings updater block is not guarded for UWP")
    assert_preprocessor_balanced(settings_path)

    verify_randomizer_storage(source)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("work/TwilightPrincessRandomizer"))
    args = parser.parse_args()
    out = args.output.resolve()
    if out.exists():
        shutil.rmtree(out)
    out.parent.mkdir(parents=True, exist_ok=True)

    run(["git", "clone", "--no-checkout", RANDO_REPO, str(out)])
    run(["git", "checkout", "--detach", RANDO_SHA], out)
    run(["git", "submodule", "update", "--init", "--recursive"], out)
    if capture(["git", "rev-parse", "HEAD"], out) != RANDO_SHA:
        raise RuntimeError("Randomizer pin mismatch")

    run(["git", "remote", "add", "dusklight-uwp", UWP_REPO], out)
    run(["git", "fetch", "--no-tags", "dusklight-uwp", UWP_SHA], out)
    merge_cmd = [
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "merge", "--no-ff", "--no-edit", "-X", "ours", UWP_SHA,
    ]
    merge_result = run(merge_cmd, out, check=False)
    if merge_result.returncode != 0:
        # Git cannot automatically resolve non-trivial submodule gitlink merges, even
        # with -X ours. At the pinned revisions the only expected unresolved path is
        # extern/aurora. Keep the randomizer's newer Aurora base here; the dedicated
        # SternXD UWP Aurora patch is applied immediately afterward inside the
        # submodule. Any other conflict remains a hard failure.
        unmerged = [
            line.strip()
            for line in capture(["git", "diff", "--name-only", "--diff-filter=U"], out).splitlines()
            if line.strip()
        ]
        if set(unmerged) != {"extern/aurora"}:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(
                "UWP reference merge has unexpected conflicts: "
                + (", ".join(unmerged) if unmerged else "merge failed without an unmerged path")
            )

        ours_aurora = capture(["git", "rev-parse", ":2:extern/aurora"], out)
        if ours_aurora != EXPECTED_AURORA_BASE:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(
                f"Unexpected randomizer Aurora side during UWP merge: {ours_aurora}; "
                f"expected {EXPECTED_AURORA_BASE}"
            )

        print(
            "Resolving expected extern/aurora gitlink conflict by keeping the "
            f"randomizer Aurora base {ours_aurora}",
            flush=True,
        )
        run(["git", "-C", "extern/aurora", "checkout", "--detach", ours_aurora], out)
        run(["git", "add", "extern/aurora"], out)

        remaining = capture(["git", "diff", "--name-only", "--diff-filter=U"], out)
        if remaining:
            run(["git", "status", "--short"], out, check=False)
            run(["git", "merge", "--abort"], out, check=False)
            raise RuntimeError(f"UWP reference merge still has unresolved paths: {remaining}")

        run([
            "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
            "commit", "--no-edit",
        ], out)

    aurora = out / "extern/aurora"
    run(["git", "fetch", "origin"], aurora)
    run(["git", "checkout", "--detach", EXPECTED_AURORA_BASE], aurora)
    run(["git", "remote", "add", "stern-uwp", AURORA_UWP_REPO], aurora)
    run(["git", "fetch", "--no-tags", "stern-uwp", AURORA_UWP_SHA], aurora)
    try:
        run([
            "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
            "cherry-pick", AURORA_UWP_SHA,
        ], aurora)
    except subprocess.CalledProcessError:
        run(["git", "status", "--short"], aurora, check=False)
        resolve_aurora_uwp_cherry_pick(aurora)
    run(["git", "add", "extern/aurora"], out)

    ensure_main_uwp_cmake(out)
    ensure_main_cpp_uwp(out)
    patch_io_uwp_local_folder(out)
    patch_settings_uwp(out)
    patch_file_browser_current_pane(out)
    patch_uwp_wrapper(out)
    patch_manifest(out)
    install_branding(out)
    verify_port(out)

    run(["git", "add", "-A"], out)
    run([
        "git", "-c", "user.name=TPR UWP Port Bot", "-c", "user.email=tpr-uwp@example.invalid",
        "commit", "-m", "Create standalone Twilight Princess Randomizer UWP app",
    ], out)

    print("\nStandalone UWP source assembled successfully:", out)
    print("HEAD:", capture(["git", "rev-parse", "HEAD"], out))
    print("Aurora:", capture(["git", "rev-parse", "HEAD"], aurora))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
