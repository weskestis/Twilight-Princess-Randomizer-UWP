# Checkpoint 14 update

Checkpoint 13 successfully reached and completed the final UWP executable link. The remaining failure was Microsoft AppX validation (`APPX3207`) because the wide and square Xbox tile PNGs were larger than 204,800 bytes.

Checkpoint 14 re-encodes only those two tile assets below the AppX limit while preserving their required dimensions. The static verifier now checks both dimensions and byte size before CI reaches package generation.

# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the pinned Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.627`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The current CI has already proven the full randomizer static build, UWP configuration, and final executable link. Checkpoint 14 addresses the AppX tile-size packaging gate.
