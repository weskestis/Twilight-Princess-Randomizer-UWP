# GitHub Actions build status — Checkpoint 14

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Checkpoint 13 result

Checkpoint 13 passed all source/build gates through creation of the UWP executable:

- checkpoint extraction
- port-kit static verification
- integrated source assembly and verification
- integrated source snapshot/upload
- randomizer static-feed configure and full build
- fresh UWP package configure
- sideload certificate creation
- final UWP executable link

The signed-package step then failed in Microsoft AppX manifest validation with `APPX3207` because two branding tile PNGs exceeded the 204,800-byte maximum:

- `Assets/Wide310x150Logo.scale-200.png` — 284,606 bytes
- `Assets/Square310x310Logo.scale-200.png` — 364,791 bytes

This is a packaging-asset failure only. The executable linked successfully.

## Checkpoint 14 fix

The two failing PNGs were re-encoded as indexed PNGs without changing required dimensions:

- `Wide310x150Logo.scale-200.png` — 620x300, 113,013 bytes
- `Square310x310Logo.scale-200.png` — 620x620, 147,005 bytes

`scripts/verify_static.py` now enforces the 204,800-byte AppX tile limit in both the checkpoint kit and assembled UWP source tree.

## Workflow

No workflow change is required.

## Next gate

Upload Checkpoint 14 and let `Xbox UWP x64` run. The expected next gate is successful AppX/MSIX packaging and artifact collection, or a packaging/signing diagnostic beyond the fixed APPX3207 tile-size failure.
