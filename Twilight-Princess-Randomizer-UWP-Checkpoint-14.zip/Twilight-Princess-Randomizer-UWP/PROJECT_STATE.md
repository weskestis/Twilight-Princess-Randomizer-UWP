# Project state — Checkpoint 14

Goal: a side-by-side Xbox/UWP application named **Twilight Princess Randomizer**.

## Pinned upstreams

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Completed compatibility work

- Dedicated package identity and branding.
- Static UWP Dusklight/randomizer feed.
- Aurora UWP forward-port over the newer randomizer Aurora base.
- Short Windows build root to avoid MSVC path failures.
- UWP settings/preprocessor fixes.
- YAML/base64/Tracy UWP link integration.
- UWP FileBrowser source and current Pane/Component API integration.
- UWP LocalState helper restored deterministically.
- Randomizer static feed fully builds.
- Fresh UWP wrapper configures.
- Final UWP executable links successfully.
- AppX tile assets now satisfy Microsoft package-size limits.

## Current proven build state

Checkpoint 13 reached the signed-package stage. The executable was already linked; AppX validation rejected only two oversized tile PNGs with `APPX3207`.

Checkpoint 14 re-encodes those two assets below 204,800 bytes while preserving their required 620x300 and 620x620 dimensions. Static verification now enforces those size limits before CI.

## Next action

Upload Checkpoint 14 to the repository root. Keep the current workflow unchanged; it selects the numerically highest checkpoint automatically.
