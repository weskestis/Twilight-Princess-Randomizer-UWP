# Xbox Dev Mode install

This package is designed to install **beside** an existing Dusk/Dusklight installation.

1. Open the Xbox Device Portal for the console.
2. Add/deploy the generated `.appx`, `.msix`, `.appxbundle`, or `.msixbundle` from the build artifact.
3. If the portal requests the signing certificate, use `TwilightPrincessRandomizer.cer` from the same artifact.
4. Add any dependency packages emitted in the artifact if the console reports a missing dependency.
5. Launch **Twilight Princess Randomizer**. The existing Dusklight app and its LocalState are separate and should remain unchanged.

Do not uninstall the existing Dusklight app as part of this installation.
