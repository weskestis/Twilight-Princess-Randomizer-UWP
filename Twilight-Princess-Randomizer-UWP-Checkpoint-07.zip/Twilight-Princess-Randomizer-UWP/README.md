# Checkpoint 07 update

Checkpoint 07 preserves all source pins and the Checkpoint 06 short-path workflow. Run 6 reached `2060 / 2209` static-feed actions, proving the path-depth fix worked, then exposed a stale preprocessor closer in the old UWP settings patch. The assembler now normalizes the updater/Discord `_UWP` guard on the newer randomizer settings layout and verifies directive balance before building.

# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the pinned Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.627`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

This identity is intentionally different from both the old `Dusk` UWP package and SternXD's newer `Dusklight` UWP package, so Windows/Xbox gives it a separate package family and LocalState.

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The assembler keeps the randomizer's newer Aurora base and forward-ports UWP compatibility rather than downgrading the randomizer core.

## App artwork

`branding/Twilight-Princess-Randomizer-original.jpg` is the exact supplied artwork. SHA-256:

`521496b108c8f26e811cae511af04b2a33c82b70e9b0cac8d33d8ec303f170ff`

## Build status

GitHub Actions has passed source assembly, static verification, static-feed CMake configuration, the former nested manifest failure, and more than 90% of the static-feed compile. Checkpoint 07 addresses the first compiler-level source merge error. See `BUILD_STATUS.md` for the exact gate.
