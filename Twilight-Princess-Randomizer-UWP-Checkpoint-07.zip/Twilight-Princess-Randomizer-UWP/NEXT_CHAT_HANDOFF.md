# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 07

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 07**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-07.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Checkpoint 06's short `S:` build paths fixed the prior nested CMake/MSVC manifest failure. The static feed then compiled to approximately:

```text
[2060/2209]
```

before MSVC reported:

```text
S:\s\src\dusk\ui\settings.cpp(1494): fatal error C1020: unexpected #endif
```

## Checkpoint 07 fix

The older SternXD UWP lineage includes commit `bdcc0bbb917093d21690309b09f9fc8a5bf5e2fa`, which hides desktop-only settings with `_UWP` preprocessor guards. The newer pinned randomizer changed the surrounding settings layout; the merged tree therefore retained an orphan closing `#endif`.

Checkpoint 07 adds `patch_settings_uwp()` to the deterministic assembler. It reconstructs only the updater/Discord UWP guard, preserves current randomizer content, removes only unmatched stale closers in that region, and runs a preprocessor-balance check. `verify_static.py` independently rejects an assembled `settings.cpp` with an unbalanced directive stack.

## Workflow action

No workflow replacement is needed for Checkpoint 07. Keep the current Checkpoint 06 short-path workflow.

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-07.zip` to repository root.
2. Run `Xbox UWP x64` again.
3. Inspect the next exact failure or successful artifact.

Old checkpoint ZIPs may remain; the workflow selects the numerically highest checkpoint.

## Remaining gates

1. Complete all ~2209 static-feed build actions
2. UWP wrapper configure
3. Certificate creation
4. UWP link/package
5. Artifact upload
6. Xbox Dev Mode install
7. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation
