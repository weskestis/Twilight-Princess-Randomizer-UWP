# Project state — Checkpoint 07

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Existing Dusk/Dusklight identities are not reused, preserving separate Xbox/Windows LocalState.

## Completed

- Fresh package identity/display name and exact user-supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- Randomizer-era UWP link dependencies: TracyClient, yaml-cpp, base64pp.
- UWP static-library mode and entry-point compatibility patches.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Checkpoints 02–05 resolved verifier, Aurora merge, Aurora content, and runtime-install CMake blockers.
- Checkpoint 06 short-path build layout eliminated the nested MSVC `intermediate.manifest` failure.
- Run 6 compiled the static feed through `2060 / 2209` actions before the first source compiler error.

## Run 6 result

MSVC stopped on:

```text
src/dusk/ui/settings.cpp(1494): fatal error C1020: unexpected #endif
```

The stale directive came from forward-merging the older UWP "hide settings" patch onto the newer randomizer settings layout.

## Checkpoint 07 change

The assembler now normalizes the updater/Discord `_UWP` preprocessor region in `settings.cpp` and verifies that file's preprocessor directives are balanced before accepting the assembled tree. Static verification independently repeats the balance check.

No source pins and no workflow paths changed in Checkpoint 07.

## Not yet certified

The project has not yet passed:

- complete static-feed compilation;
- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Upload Checkpoint 07 and rerun the existing Checkpoint 06 workflow. The next exact failed step/log is the source of truth.
