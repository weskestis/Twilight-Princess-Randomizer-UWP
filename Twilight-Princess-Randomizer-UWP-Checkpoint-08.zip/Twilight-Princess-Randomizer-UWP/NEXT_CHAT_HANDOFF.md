# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 08

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 08**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-08.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Checkpoint 07 completed the entire randomizer static-feed build (~2209 actions). The run then reached `Configure fresh UWP package project` and stopped with:

```text
Required randomizer UWP feed library not found: [/\\]TracyClient\.lib$
under S:/b/f
```

## Checkpoint 08 fix

Aurora defines a `TracyClient` target even when its default `TRACY_ENABLE=OFF`. With profiling disabled, Tracy instrumentation compiles out and a separately emitted Tracy archive is not required by the UWP link. The early compatibility wrapper incorrectly treated the archive as mandatory.

Checkpoint 08 changes the generated UWP wrapper to inspect `${DUSK_DIR}/CMakeCache.txt`:

- if `TRACY_ENABLE:BOOL=ON`, find and link `TracyClient*.lib`;
- otherwise leave `TPR_TRACY_LIB` empty and continue;
- continue to require `yaml-cpp.lib` and `base64pp.lib`;
- use forward-slash regexes with `[.]lib` to avoid CMake escape ambiguity.

Static verification checks the Tracy cache gate.

## Workflow action

No workflow replacement is needed. Keep the existing Checkpoint 06 short-path workflow.

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-08.zip` to repository root.
2. Run `Xbox UWP x64` again.
3. Inspect the next exact failure or successful artifact.

Old checkpoint ZIPs may remain; the workflow selects the numerically highest checkpoint.

## Remaining gates

1. UWP wrapper configure
2. Certificate creation
3. UWP link/package
4. Artifact upload
5. Xbox Dev Mode install
6. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation
