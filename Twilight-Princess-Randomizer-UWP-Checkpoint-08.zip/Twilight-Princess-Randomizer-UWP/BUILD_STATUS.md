# GitHub Actions build status — Checkpoint 08

## Repository

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Prior resolved gates

- Checkpoint 02: corrected pre-assembly verifier invocation.
- Checkpoint 03: resolved the superproject `extern/aurora` gitlink conflict while preserving the randomizer Aurora base.
- Checkpoint 04: forward-ported the real Aurora UWP content conflicts onto the newer randomizer Aurora structures.
- Checkpoint 05: guarded `aurora_install_runtime_dlls` for non-UWP builds.
- Checkpoint 06: moved source/build/temp roots onto short `S:` paths, eliminating the nested MSVC manifest failure.
- Checkpoint 07: repaired the stale UWP `settings.cpp` preprocessor closer and added balance verification.

## Run 7 — static feed completed

Checkpoint 07 passed the entire `Build randomizer static feed` step. The run completed all ~2209 static-feed build actions and advanced to:

`Configure fresh UWP package project`

The new first failure was:

```text
Required randomizer UWP feed library not found: [/\\]TracyClient\.lib$
under S:/b/f
```

## Root cause

The pinned Aurora creates a `TracyClient` target unconditionally, but its cache default is `TRACY_ENABLE=OFF`. With profiling disabled, Tracy instrumentation macros compile out of the randomizer code. The UWP wrapper compatibility shim added in the early checkpoints was nevertheless requiring a physical `TracyClient.lib` archive unconditionally.

The successful static-feed build proves the randomizer itself does not require a separately emitted Tracy archive in this configuration. The wrapper should only require that archive when `TRACY_ENABLE:BOOL=ON` in the feed's `CMakeCache.txt`.

## Checkpoint 08 fix

`scripts/assemble_port.py` now:

- reads `${DUSK_DIR}/CMakeCache.txt` during UWP wrapper configure;
- requires/links `TracyClient*.lib` only when `TRACY_ENABLE=ON`;
- leaves `TPR_TRACY_LIB` empty when Tracy profiling is off;
- keeps `yaml-cpp.lib` and `base64pp.lib` mandatory because the randomizer generator uses those libraries;
- uses forward-slash CMake regexes (`/name[.]lib$`) to avoid fragile Windows/CMake backslash escaping.

`verify_static.py` now checks that the Tracy cache gate is present in both the checkpoint kit and assembled UWP wrapper.

## Workflow

No workflow change from Checkpoint 06 is required. Keep the short-path `S:` workflow.

## Next gate

Upload Checkpoint 08 and rerun `Xbox UWP x64`.

The next target is successful UWP wrapper configuration, followed by certificate creation and the actual UWP link/package step.
