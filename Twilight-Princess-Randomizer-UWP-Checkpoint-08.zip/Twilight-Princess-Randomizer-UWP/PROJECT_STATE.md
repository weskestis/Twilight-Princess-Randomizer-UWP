# Project state — Checkpoint 08

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Completed

- Fresh package identity/display name and exact supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- UWP static-library mode and entry-point compatibility patches.
- New randomizer static dependencies `yaml-cpp` and `base64pp` wired into the older UWP wrapper.
- Tracy dependency made conditional on the static feed's actual `TRACY_ENABLE` state.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Deterministic Aurora forward-port without downgrading the randomizer's newer Aurora base.
- Short-path `S:` build layout for Windows/MSVC.
- Static `settings.cpp` preprocessor-balance verification.
- **Checkpoint 07 completed the full randomizer static-feed build (~2209 actions).**

## Latest run result

The first failure is now UWP wrapper configure, not randomizer compile:

```text
Required randomizer UWP feed library not found: [/\\]TracyClient\.lib$
```

This was caused by the compatibility wrapper requiring `TracyClient.lib` even though the feed is configured with `TRACY_ENABLE=OFF`.

## Checkpoint 08 change

The wrapper now reads the feed `CMakeCache.txt` and only resolves/links a Tracy client archive when profiling is enabled. `yaml-cpp.lib` and `base64pp.lib` remain required. CMake library regexes now use forward-slash paths and `[.]lib` for predictable parsing.

## Not yet certified

The project has not yet passed:

- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Upload Checkpoint 08 and rerun the existing Checkpoint 06 short-path workflow. The next exact failed step/log is the source of truth.
