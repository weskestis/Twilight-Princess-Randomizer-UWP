# Source manifest — Checkpoint 08

## Pinned public sources

- `TwilitRealm/dusklight`
  - randomizer development commit: `07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
  - observed development label: `v1.4.1-627`
- `SternXD/dusklight-uwp`
  - UWP compatibility reference commit: `48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
  - relevant older settings guard commit: `bdcc0bbb917093d21690309b09f9fc8a5bf5e2fa`
- `encounter/aurora`
  - submodule revision at pinned randomizer commit: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- `SternXD/aurora`
  - UWP compatibility patch source: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
  - parent of that patch: `509021de0a45f3318769a0f15265b432747bc103`
- `wolfpld/tracy`
  - version pulled by the pinned Aurora: commit archive `6789e7d6f9a65ec98926b602097a33a9676d2606`
  - Aurora sets `TRACY_ENABLE` default OFF and `TRACY_STATIC` ON.

## User-provided source/artwork

- Exact uploaded Twilight Princess HD artwork retained as `branding/Twilight-Princess-Randomizer-original.jpg`.
- UWP assets are deterministic resizes/padded derivatives, not generated replacement art.

## Project-authored integration

- `scripts/assemble_port.py` — deterministic pinned-source assembler/patcher. It preserves the newer Aurora input/WebGPU structures, forward-ports UWP behavior, guards desktop runtime installation, normalizes the stale UWP settings preprocessor region, and in Checkpoint 08 gates the physical Tracy client archive on the feed's actual `TRACY_ENABLE` cache state.
- `scripts/verify_static.py` — kit and assembled-tree validation, including settings preprocessor balance and the Checkpoint 08 Tracy cache gate.
- `.github/workflows/build.yml` — source-tree GitHub Actions workflow.
- `github-manual/build-xbox.yml` — private checkpoint-repo workflow using the Checkpoint 06 short `S:` source/build/temp paths and highest-checkpoint selection.
- `APP_IDENTITY.json` — standalone package identity contract.
- `BUILD_STATUS.md` / `PROJECT_STATE.md` / `NEXT_CHAT_HANDOFF.md` — exact continuation state.

No source pins changed in Checkpoint 08.
