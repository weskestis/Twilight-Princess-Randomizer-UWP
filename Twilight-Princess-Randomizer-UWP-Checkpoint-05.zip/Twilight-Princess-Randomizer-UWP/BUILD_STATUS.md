# GitHub Actions build status — Checkpoint 05

## Repository

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

The existing manual workflow remains the Android bridge. It already chooses the numerically highest checkpoint ZIP, so no workflow edit is required for Checkpoint 05.

## Prior resolved gates

- Checkpoint 02 fixed the pre-assembly verifier invocation.
- Checkpoint 03 resolved the superproject `extern/aurora` gitlink conflict while preserving the randomizer's exact Aurora base.
- Checkpoint 04 forward-ported the two real Aurora UWP content conflicts (`lib/input.cpp`, `lib/webgpu/gpu.cpp`) onto the newer randomizer Aurora structures.

## Run 4 — first real CMake configure failure

Checkpoint 04 passed:

1. source assembly;
2. the dedicated Aurora UWP cherry-pick/forward-port;
3. assembled-source verification.

The workflow then entered **Configure randomizer static feed** and reached the end of top-level configure before failing with:

```text
CMake Error at CMakeLists.txt:783 (aurora_install_runtime_dlls):
  Unknown CMake command "aurora_install_runtime_dlls".

-- Configuring incomplete, errors occurred!
```

This proves the previous Git/Aurora merge blockers are resolved.

### Root cause

The old UWP fork intentionally wraps both Aurora runtime-DLL deployment paths in `if (NOT DUSK_UWP)` because the UWP wrapper owns package runtime files.

The newer pinned randomizer later added `aurora_install_runtime_dlls(dusklight ${CMAKE_INSTALL_PREFIX})` to its packaging logic. During the source merge, the older UWP guard around the Aurora helper include/copy path survived, while the newer install-helper call survived outside that guard.

Result when `DUSK_UWP=ON`:

- `AuroraCopyRuntimeDLLs.cmake` is not included;
- `aurora_install_runtime_dlls` is therefore undefined;
- the still-unconditional call aborts CMake configure.

## Checkpoint 05 fix

`scripts/assemble_port.py` now explicitly keeps the newer Aurora runtime-install call desktop-only:

```cmake
if (NOT DUSK_UWP)
    aurora_install_runtime_dlls(dusklight ${CMAKE_INSTALL_PREFIX})
endif ()
```

This matches the existing UWP architecture: the UWP wrapper, not the static randomizer feed, owns packaged runtime DLL deployment.

The transform is idempotent and preserves desktop behavior.

`verify_static.py` now requires the assembled source to contain this exact guard so the same CMake mismatch cannot silently regress.

## Local validation for Checkpoint 05

- Python source compilation passes.
- Kit static verification passes.
- Exact merged-CMake fixture transforms correctly.
- Reapplying `ensure_main_uwp_cmake()` is idempotent.
- A minimal CMake configure with `DUSK_UWP=ON` and the guarded undefined helper passes configure/generate, proving the bad call is skipped in the UWP path.

## Next gate

Upload Checkpoint 05 to the repository root and rerun the existing `Xbox UWP x64` workflow.

The next meaningful gate is **randomizer static-feed CMake configure past line 783**, followed by actual static-feed compilation. Do not call this compiled until the build step itself succeeds.
