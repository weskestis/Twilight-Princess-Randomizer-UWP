# NEXT CHAT HANDOFF — Twilight Princess Randomizer UWP — Checkpoint 05

Continue **Twilight Princess Randomizer UWP** development from **Checkpoint 05**.

## Source of truth

Use `Twilight-Princess-Randomizer-UWP-Checkpoint-05.zip` and verify its SHA-256 first. Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`
4. `UPSTREAM_LOCK.md`
5. `SOURCE_MANIFEST.md`

Do not restart from Dusklight 1.4.1 or from the user's old UWP binary.

## Goal

Produce a real Xbox Dev Mode installable **separate app**:

- Display name: **Twilight Princess Randomizer**
- Package identity: `TwilightPrincessRandomizer`
- Must install alongside existing Dusklight UWP and keep separate LocalState.
- Preserve the user's exact supplied Twilight Princess HD artwork.

## Pins — do not move while debugging

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Latest GitHub Actions state

Checkpoint 04 passed the previous Git/Aurora blockers, completed source assembly, passed assembled-source verification, and entered **Configure randomizer static feed**.

The first real CMake error was:

```text
CMake Error at CMakeLists.txt:783 (aurora_install_runtime_dlls):
  Unknown CMake command "aurora_install_runtime_dlls".
```

The old UWP merge leaves the Aurora helper include/copy path inside `if (NOT DUSK_UWP)`, while the newer randomizer's install-helper call survived unguarded later in the file. Therefore UWP skips the helper definition but still calls it.

Checkpoint 05 updates the assembler so the install-helper call is also wrapped in `if (NOT DUSK_UWP)`. This preserves desktop behavior and leaves runtime DLL packaging to the UWP wrapper.

Static verification now checks that exact assembled CMake guard.

## Manual GitHub workflow

Keep the existing `.github/workflows/build-xbox.yml`. It already selects the numerically highest `Checkpoint-XX.zip`.

Immediate action:

1. Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-05.zip` to repository root.
2. Run `Xbox UWP x64` again.
3. Inspect the next exact failure or successful artifact.

Old checkpoint ZIPs may remain; Checkpoint 05 will be selected automatically.

## Remaining gates

1. Randomizer static-feed CMake configure past the runtime-install guard
2. Static-feed compile
3. UWP wrapper configure
4. Certificate creation
5. UWP link/package
6. Artifact upload
7. Xbox Dev Mode install
8. Runtime smoke tests: app launch, isolated storage, disc/data selection, randomizer UI, seed generation, save behavior, suspend/resume, controller navigation

Fix one real failure at a time. Preserve pinning and fail-fast behavior.
