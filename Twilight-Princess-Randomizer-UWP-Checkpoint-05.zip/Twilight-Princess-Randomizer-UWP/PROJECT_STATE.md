# Project state — Checkpoint 05

## Current target

A brand-new, side-by-side Xbox UWP application named **Twilight Princess Randomizer**.

- Package identity: `TwilightPrincessRandomizer`
- Publisher subject: `CN=TwilightPrincessRandomizer`
- Package version: `1.4.1.627`
- Core source: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Existing Dusk/Dusklight identities are not reused, preserving separate Xbox/Windows LocalState.

## Completed

- Fresh package identity/display name and exact user-supplied Twilight Princess HD branding.
- UWP tile/splash assets, including wide and large-square Xbox presentation assets.
- Randomizer-era UWP link dependencies: TracyClient, yaml-cpp, base64pp.
- UWP static-library mode and entry-point compatibility patches.
- Desktop-only updater, Discord RPC, Sentry, code-mod and process-restart paths disabled for UWP as applicable.
- Sideload certificate generation and package artifact collection workflow.
- Windows runner, MSVC setup, Ninja, freetype and zstd dependency setup proven working in GitHub Actions.
- Checkpoint 02 pre-assembly verifier bug fixed.
- Checkpoint 03 superproject `extern/aurora` gitlink conflict fixed without downgrading Aurora.
- Checkpoint 04 successfully forward-ports the only two observed Aurora content conflicts onto the newer randomizer Aurora structures.
- Run 4 proved **full source assembly and assembled-source verification now pass** and reached the real randomizer static-feed CMake configure.
- Checkpoint 05 fixes the first CMake integration mismatch: the newer `aurora_install_runtime_dlls` call is now disabled for `DUSK_UWP`, matching the legacy UWP runtime-packaging architecture.

## Run 4 result

The first configure error is:

```text
CMake Error at CMakeLists.txt:783 (aurora_install_runtime_dlls):
  Unknown CMake command "aurora_install_runtime_dlls".
```

Root cause is a merged guard mismatch, not missing source or a compiler failure.

## Local validation for Checkpoint 05

- Kit static verifier passes.
- Python source compiles.
- The top-level CMake runtime-install transform is idempotent.
- Synthetic merged-CMake fixture produces the exact required `if (NOT DUSK_UWP)` guard.
- Minimal CMake UWP-path configure passes with the helper intentionally undefined, proving the call is not executed.

## Not yet certified

The project has not yet passed:

- complete randomizer static-feed CMake configure after the Checkpoint 05 fix;
- static-feed compilation;
- UWP wrapper configure/link;
- AppX/MSIX packaging;
- Xbox Dev Mode installation/runtime smoke testing.

## Immediate next action

Upload `Twilight-Princess-Randomizer-UWP-Checkpoint-05.zip` to repository root and rerun the existing workflow. Because the workflow selects the numerically highest checkpoint, **no YAML change is needed**. Use the next exact failed step/log as the source of truth.
