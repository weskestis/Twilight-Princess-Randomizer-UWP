# Source manifest — Checkpoint 05

## Pinned public sources

- `TwilitRealm/dusklight`
  - randomizer development commit: `07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
  - observed development label: `v1.4.1-627`
- `SternXD/dusklight-uwp`
  - UWP compatibility reference commit: `48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- `encounter/aurora`
  - submodule revision at pinned randomizer commit: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- `SternXD/aurora`
  - UWP compatibility patch source: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`
  - parent of that patch: `509021de0a45f3318769a0f15265b432747bc103`

## User-provided source/artwork

- Exact uploaded Twilight Princess HD artwork retained as `branding/Twilight-Princess-Randomizer-original.jpg`.
- UWP assets are deterministic resizes/padded derivatives, not generated replacement art.

## Project-authored files

- `scripts/assemble_port.py` — deterministic pinned-source assembler/patcher. It preserves the newer Aurora versions of `lib/input.cpp` and `lib/webgpu/gpu.cpp`, forward-ports only the UWP behavior for the exact observed two-file conflict, and in Checkpoint 05 also guards the newer Aurora runtime-install helper from the UWP static-feed path.
- `scripts/verify_static.py` — kit and assembled-tree validation, including Aurora UWP conflict-resolution markers and the required top-level CMake runtime-install guard.
- `.github/workflows/build.yml` — source-tree GitHub Actions workflow.
- `github-manual/build-xbox.yml` — private checkpoint-repo workflow; selects highest checkpoint number deterministically.
- `APP_IDENTITY.json` — standalone package identity contract.
- `BUILD_STATUS.md` — exact GitHub Actions gate and fix state.
- `NEXT_CHAT_HANDOFF.md` — continuation instructions.
