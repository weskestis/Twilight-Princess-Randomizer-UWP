# Build status — working `.627` seed-safety hotfix

Private repository: `weskestis/Twilight-Princess-Randomizer-UWP`

## Proven base

The user physically tested `TwilightPrincessRandomizer_1.4.1.627_x64_RelWithDebInfo.msix`
(SHA-256 `03c8012c36c6cd6bdb28d6b16b358d3139ae22c651196456af847333c14c0005`)
on Xbox: disc selection/loading and game launch work. Later `.628` through `.630`
packages crash at Play and are intentionally excluded from this hotfix.

## Isolated delta

Against the exact assembled `.627` baseline, only these runtime outputs change:

- `src/dusk/texture_replacements.cpp` — file-backed ZIP/ZIP64 texture reader.
- `src/dusk/settings.h` / `settings.cpp` — persistent `cosmetics.heartColor` setting.
- `src/dusk/ui/cosmetics.cpp` — `Cosmetics → HUD Colors → Heart Color` control.
- `src/dusk/ui/cosmetics.cpp` — Green preset, four live menu palette selectors,
  master `Randomize All Per Seed`, and individual per-color seed randomization.
- `src/dusk/settings.h` / `settings.cpp` — persistent menu palette and seed-randomization choices.
- `src/dusk/ui/ui.cpp` — reapplies the saved menu palette at startup.
- `src/d/d_meter2_draw.cpp` — live full/partial-heart recoloring with vanilla default.
- `src/dusk/ui/input.cpp` / `overlay.cpp` — L3+R3 controller cursor with visible state feedback.
- `src/dusk/ui/settings.cpp` — persistent cursor speed, deadzone, and acceleration controls.
- `src/dusk/imgui/ImGuiMenuRandomizer.cpp` — movable/resizable native item and check tracker.
- `src/dusk/ui/rando_config.cpp` — controller-accessible tracker toggle.
- `src/dusk/randomizer/game/randomizer_context.cpp` — checked temporary write,
  byte-for-byte readback, committed-file verification, and non-fatal corrupt-seed loading.
- `src/dusk/ui/rando_seed_generation.cpp` — generation-thread exception boundary.
- Tracker/cursor access is disabled during pre-save creation.
- `platforms/uwp/Package.appxmanifest` — version `1.4.1.634`.

The workflow does not download texture packs, build optional mods, or run the
CP20 texture/mod/randomizer audit suites. A native compile is still required for
the changed C++ file; no 40-minute CP20 audit is repeated.

## Next gate

Build the signed `.634` MSIX and install it directly over `.633`. Confirm Menu
Colors, Green hearts, and both per-seed randomization modes. Delete only the
broken `Mantis Poe Plumm` seed directory, regenerate it from its saved permalink,
select it, and continue through name entry and game launch.
