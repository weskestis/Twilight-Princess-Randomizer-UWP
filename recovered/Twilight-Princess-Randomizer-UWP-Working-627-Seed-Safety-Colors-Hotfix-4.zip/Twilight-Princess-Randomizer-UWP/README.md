# Working `.627` ZIP + heart + cursor + tracker + seed-safety hotfix

This source intentionally returns to the physically tested working `1.4.1.627`
baseline and keeps the isolated direct texture-ZIP and heart-color patches. This
revision keeps the controller cursor and movable/resizable native tracker, then
adds live menu palettes and deterministic per-seed color randomization, and fixes
the confirmed zero-byte `seed.dat` crash without changing the game core.
The discarded `.628` through `.630` launch-path, bundled-texture, and optional-mod
changes are not present.

# Twilight Princess Randomizer — Xbox/UWP

Fresh, side-by-side Xbox/UWP application built around the pinned Dusklight randomizer development branch.

## Identity

- **Display name:** Twilight Princess Randomizer
- **Package identity:** `TwilightPrincessRandomizer`
- **Executable/UWP target:** `TwilightPrincessRandomizer`
- **Publisher subject:** `CN=TwilightPrincessRandomizer`
- **Package version:** `1.4.1.634` (required for an in-place update over `.633`)
- **Restored option:** `Cosmetics → HUD Colors → Heart Color`
- **Green hearts:** Green is now a named Heart Color preset.
- **Menu palette:** `Cosmetics → Menu Colors` controls accent, background, text, and border.
- **Seed colors:** `Cosmetics → Randomize Colors → Randomize All Per Seed`, or
  choose `Randomize This Color Per Seed` inside any individual color selector.
- **Controller cursor:** hold `L3 + R3` for 0.35 seconds; right stick moves; `A` clicks/drags
- **Tracker:** `Randomizer → In-Game → Toggle Item & Check Tracker`
- **Unique PhoneProductId:** `e3b5e8e8-c7e7-5c3d-affa-0500675ffa0d`

## Source foundation

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP compatibility source: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Aurora UWP compatibility patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`

The game/runtime source pin remains `v1.4.1-627`. ZIP files are opened through
SDL and miniz using random access; only an individual requested `.dds` or `.png`
member is decompressed. Loose texture files continue to work unchanged.

Cursor speed, deadzone, and acceleration are under
`Settings → Input → Xbox Controller Cursor`. Tracker opacity, content scale,
position/size lock, and layout reset are inside the tracker window.

Generated `seed.dat` files are written through checked UWP I/O, read back and
verified before commit. Empty or malformed seed files now produce an error toast
and leave the seed unselected instead of terminating Dusklight.

Per-seed colors are deterministic across all 27 color targets: the same selected
seed hash always produces the same colors. Menu backgrounds are kept dark and
menu text bright enough to remain readable when the full palette is randomized.

See `INSTALL_TEXTURE_ZIPS_XBOX.md` for the exact Device Portal layout.
