# Direct texture ZIP installation — Xbox

## Accepted files

- Outer archive: `.zip` (standard ZIP or ZIP64).
- Texture members inside it: `.dds` or `.png` using Dusklight/Aurora `tex1_...` names.
- Not accepted directly: `.rar`, `.partNN.rar`, `.7z`, or a ZIP that contains only another archive.

If the download is a 13-part RAR set, join/extract that set once on a computer
to obtain the real texture folder or single texture ZIP. Do not upload the 13
RAR pieces to the Xbox.

## Device Portal placement

1. Launch `.634` once, then close it.
2. In Xbox Device Portal, open File Explorer for **Twilight Princess Randomizer**.
3. Open `LocalState/TwilitRealm/Dusklight/texture_replacements`.
4. Upload the original HD texture ZIP **without selecting Extract**.
5. For layering, name the files so the overlay sorts later, for example:
   - `01-TP-Definitive-HD.zip`
   - `02-Henriko-4K.zip`
6. Launch the app and enable **Texture Replacements** in graphics settings.

The loader reads only the requested texture member from disk. Alphabetically
later ZIP filenames override earlier ZIPs when both contain the same texture key.
