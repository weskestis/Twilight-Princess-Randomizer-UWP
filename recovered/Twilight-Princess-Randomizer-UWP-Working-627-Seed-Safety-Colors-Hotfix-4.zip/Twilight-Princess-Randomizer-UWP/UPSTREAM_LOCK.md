# Upstream lock

Do not silently move these revisions while debugging a build.

- Randomizer: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e` (`v1.4.1-627`, 2026-08-04)
- UWP compatibility: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7` (UWP 1.1.1 lineage)
- Aurora UWP patch: `SternXD/aurora@aaf5b8b092ff547a33a9d199dd2c52572bff6682`
- Randomizer Aurora base expected: `6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- UWP dependency bundle: `SternXD/uwp-dep@ae39aa004ae127bd00f8262d28b401f8e4ed8728`

Custom package version: `1.4.1.634` (exact `v1.4.1-627` source baseline plus the isolated direct texture-ZIP loader, tested CP15 heart-color patch, Green/menu/per-seed color controls, controller cursor, resizable native tracker, and checked/non-fatal seed I/O fix).
