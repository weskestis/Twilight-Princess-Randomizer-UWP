# Project state — working `.627` seed-safety hotfix

Goal: a side-by-side Xbox/UWP application named **Twilight Princess Randomizer**.

## Pinned upstreams

- Randomizer core: `TwilitRealm/dusklight@07a4d1ec6c7d80794f6ea865774ff9f45bd7da0e`
- UWP reference: `SternXD/dusklight-uwp@48d193dfebe4b20b4984af1d27d0e99f6b6722a7`
- Randomizer Aurora base: `encounter/aurora@6c4c27f9e8e40f584d27726655d80ec85a5a7d2c`
- SternXD Aurora UWP patch: `aaf5b8b092ff547a33a9d199dd2c52572bff6682`

## Completed compatibility work

- Dedicated package identity and branding.
- Static UWP Dusklight/randomizer feed.
- Aurora UWP forward-port over the newer randomizer Aurora base.
- Short Windows build root to avoid MSVC path failures.
- UWP settings/preprocessor fixes.
- YAML/base64/Tracy UWP link integration.
- UWP FileBrowser source and current Pane/Component API integration.
- UWP LocalState helper restored deterministically.
- Randomizer static feed fully builds.
- Fresh UWP wrapper configures.
- Final UWP executable links successfully.
- AppX tile assets now satisfy Microsoft package-size limits.
- Direct file-backed `.zip`/ZIP64 texture replacement loading.
- Persistent `Cosmetics → HUD Colors → Heart Color` with vanilla default.
- Named Green preset for Heart Color and the shared hex-color palette.
- Live menu accent/background/text/border selectors with saved startup application.
- Deterministic master and per-color seed randomization across all 27 color targets.
- SOH-style controller cursor for Dusklight documents and the native tracker.
- Movable/resizable native randomizer item-and-check tracker with persistent display controls.
- Checked UWP `seed.dat` staging, readback, commit, and final verification.
- Empty/malformed seed selection is contained and reported instead of escaping
  through Dusklight's `noexcept` UI event path.
- Tracker/cursor activation is gated out of the pre-save creation transition.

## Current proven build state

The exact `.627` package is the user-tested working baseline. The `.628`–`.630`
branch is rejected because it crashes when Play launches the game. This hotfix
does not merge any code from that branch.

The direct ZIP loader scans the existing `texture_replacements` directory for
`.zip` files. It registers contained `.dds`/`.png` textures by Aurora key and
reads individual members lazily. Alphabetically later ZIP filenames override
earlier ZIPs, enabling `01-HD.zip` plus `02-4K.zip` layering.

## Next action

Run the dedicated short workflow. Install `.634` over `.633`; do not uninstall
first. Delete only the zero-byte `Mantis Poe Plumm` seed directory, regenerate it
from its permalink, select it, and continue through name entry and launch. Also
verify Green hearts, Menu Colors, Randomize All Per Seed, and one individual
Randomize This Color Per Seed choice.
