# NEXT CHAT HANDOFF — working `.627` seed-safety hotfix

Continue from the physically working `.627` source baseline plus the isolated
direct texture-ZIP loader and tested CP15 heart-color feature. The only new
runtime/UI additions are the controller cursor and native resizable tracker. The
`.634` delta fixes checked seed persistence and safe loading only. Do not
reintroduce the rejected `.628`–`.630`/CP20 texture or launch-path runtime changes.

Source of truth: the working-627 ZIP-hotfix source archive plus its SHA-256 sidecar.

Read in order:

1. `NEXT_CHAT_HANDOFF.md`
2. `PROJECT_STATE.md`
3. `BUILD_STATUS.md`

Do not restart source assembly or merge the rejected CP20 runtime branch.

## Proven base and exact delta

- Working Xbox MSIX: `.627`, SHA-256 `03c8012c36c6cd6bdb28d6b16b358d3139ae22c651196456af847333c14c0005`.
- Proven loader delta: `src/dusk/texture_replacements.cpp` only.
- Packaging delta: manifest version `1.4.1.634`.
- Targeted UI/runtime delta: `Cosmetics → HUD Colors → Heart Color`, persistent
  `cosmetics.heartColor`, and live full/partial-heart recoloring.
- Controller UI delta: hold `L3 + R3` for 0.35 seconds, right-stick movement,
  `A` click/drag, visible status, and persistent speed/deadzone/acceleration.
- Tracker delta: Dusklight's existing automatic tracker is movable/resizable and
  exposes opacity, scale, lock, and reset controls without replacing its logic.
- ZIP members are read individually through SDL/miniz; the whole archive is never buffered.
- Loose textures are unchanged; later alphabetic ZIP names overlay earlier ones.
- Confirmed failure: generation created a zero-byte `Mantis Poe Plumm/seed.dat`,
  and its YAML exception escaped a `noexcept` input callback.
- `.634` stages seed data to `.tmp`, verifies it byte-for-byte, commits it, verifies
  the final file, catches malformed loads, and blocks tracker/cursor pre-save.
- `.634` also adds Green to Heart Color, four live Menu Colors, master Randomize
  All Per Seed, and Randomize This Color Per Seed on every selector. All 27 color
  targets derive stable values from the selected seed hash.
- Exact recovery permalink for `Mantis Poe Plumm`:
  `djEAMTAxNzM3NTAxMABDcmF6eUJhc2hmdWxCb21iZmlzaAAAgwBVFXQAAAQAAGBAI1GMu7s0FgBQEUTIQgAIAAAAABAAAgAAAEAIAAAAAAQEAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==`

## Workflow

Use only the dedicated working-627 ZIP-hotfix workflow. It intentionally omits
the CP20 texture, optional-mod, and randomizer audit jobs.

## Next action

Build `.634`, install it over `.633`, delete only the broken `Mantis Poe Plumm`
seed folder, regenerate it from the saved permalink, and test selection through
name entry and launch. Verify both seed-color modes and the live menu palette.
Keep the existing textures and `.dusk` mods in LocalState.
