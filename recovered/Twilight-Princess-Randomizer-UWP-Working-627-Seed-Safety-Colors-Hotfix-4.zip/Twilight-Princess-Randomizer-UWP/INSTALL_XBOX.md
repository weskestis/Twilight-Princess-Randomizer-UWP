# Xbox Dev Mode install

This package is designed to update the working Twilight Princess Randomizer `.627`
installation in place while remaining separate from any ordinary Dusklight app.

1. Open the Xbox Device Portal for the console.
2. Add/deploy the generated `.appx`, `.msix`, `.appxbundle`, or `.msixbundle` from the build artifact.
3. If the portal requests the signing certificate, use `TwilightPrincessRandomizer.cer` from the same artifact.
4. Add any dependency packages emitted in the artifact if the console reports a missing dependency.
5. Do **not** uninstall `.633`. Deploy `.634` over it so its LocalState is retained.
6. Launch **Twilight Princess Randomizer** once with no texture ZIP present and confirm the game starts.
7. Follow `INSTALL_TEXTURE_ZIPS_XBOX.md` to add the HD/4K ZIP files.

After updating, delete only the broken
`LocalState/TwilitRealm/Dusklight/randomizer/seeds/Mantis Poe Plumm` directory.
Do not delete the complete `randomizer`, `texture_replacements`, or `mods`
directories. Regenerate that seed from the saved permalink before selecting it.

Do not uninstall the working Twilight Princess Randomizer app or the existing
Dusklight app as part of this installation.
